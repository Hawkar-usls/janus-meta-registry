# JANUS A18.44 V0.1 Window 01 Hash-Bound Dry Run

This additive package validates only synthetic, non-executing bindings for a
future Window 01 authorization, per-attempt consent, and fresh physical-safety
snapshot. It creates no real authorization or consent and contains no execution
phrase. It cannot start ordinal 1, launch a miner, contact a pool, create the
campaign output root, consume an identity, inspect an outcome, or compute a
scientific endpoint.

All environment observations in this package are labelled
`NOT_FUTURE_EXECUTION_EVIDENCE` and cannot be reused as future safety evidence.
The next stage requires separate authorization and remains non-executing.
