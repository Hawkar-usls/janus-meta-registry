"""Side-effect-free validators for the Window 01 hash-bound dry run.

This module validates synthetic metadata only. It performs no file writes,
network calls, subprocess calls, process launches, authorization consumption,
identity consumption, state transitions, or scientific calculations.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import PurePosixPath, PureWindowsPath
from typing import Any, Callable, Mapping


Decision = dict[str, Any]
Validator = Callable[[Mapping[str, Any]], Decision]

FREEZE_PAYLOAD_ROOT_SHA256 = (
    "a560a539b4b1bc433d5dff88820c46cc530dcd80ba1bf517098d926c1491d596"
)
FREEZE_MANIFEST_SHA256 = (
    "882af148dc029ee1bce8fafb928d8b92236907661fdea16a618e0e78e24af484"
)
IMMUTABLE_ROSTER_SHA256 = (
    "fc56462e156c9814d433e66a4c761eb7f11444260a14953c19c25669837e0aed"
)
APPROVED_MINER_SHA256 = (
    "c46feec0dd936a65bb8e6e074aaa952a0cd57b6925cfb4dd37aad2140d22e1d2"
)
SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT = (
    "SYNTHETIC_DRY_RUN_WINDOW_01_AUTHORIZATION_SAMPLE_NO_EXECUTION_AUTHORITY"
)
HISTORICAL_OBSERVATION_LABEL = "NOT_FUTURE_EXECUTION_EVIDENCE"


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical_sha256(value: Any) -> str:
    return sha256_bytes(canonical_bytes(value))


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and value == value.lower()
        and all(character in "0123456789abcdef" for character in value)
    )


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _reject(reason: str) -> Decision:
    return {"decision": "REJECT", "reason": reason}


def _allow(reason: str) -> Decision:
    return {"decision": "ALLOW_DRY_RUN_VALIDATION_ONLY", "reason": reason}


def validate_whole_window_authorization_sample(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_WHOLE_WINDOW_AUTHORIZATION":
        return _reject("WINDOW_AUTHORIZATION_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_WINDOW_AUTHORIZATION_FORBIDDEN")
    if data.get("real_authorization_artifact_created") is not False:
        return _reject("REAL_WINDOW_AUTHORIZATION_ARTIFACT_FORBIDDEN")
    if data.get("execution_authority") is not False:
        return _reject("WINDOW_EXECUTION_AUTHORITY_FORBIDDEN")
    if data.get("authorization_consumed") is not False:
        return _reject("WINDOW_AUTHORIZATION_CONSUMPTION_FORBIDDEN")
    payload = data.get("binding_payload")
    if not isinstance(payload, Mapping):
        return _reject("WINDOW_AUTHORIZATION_PAYLOAD_MALFORMED")
    if canonical_sha256(payload) != data.get("binding_payload_sha256"):
        return _reject("WINDOW_AUTHORIZATION_PAYLOAD_HASH_MISMATCH")
    if payload.get("freeze_payload_root_sha256") != FREEZE_PAYLOAD_ROOT_SHA256:
        return _reject("WINDOW_FREEZE_PAYLOAD_ROOT_MISMATCH")
    if payload.get("freeze_manifest_sha256") != FREEZE_MANIFEST_SHA256:
        return _reject("WINDOW_FREEZE_MANIFEST_MISMATCH")
    if payload.get("immutable_roster_sha256") != IMMUTABLE_ROSTER_SHA256:
        return _reject("WINDOW_IMMUTABLE_ROSTER_MISMATCH")
    if payload.get("window_number") != 1:
        return _reject("WINDOW_NUMBER_MISMATCH")
    if payload.get("ordinals") != list(range(1, 11)):
        return _reject("WINDOW_ORDINAL_SCOPE_MISMATCH")
    if payload.get("first_ordinal") != 1 or payload.get("last_ordinal") != 10:
        return _reject("WINDOW_ORDINAL_BOUNDARY_MISMATCH")
    if payload.get("attempt_count") != 10:
        return _reject("WINDOW_ATTEMPT_COUNT_MISMATCH")
    issued = payload.get("issued_monotonic_ns")
    expires = payload.get("expires_monotonic_ns")
    observed = data.get("observed_monotonic_ns")
    if not all(_is_int(value) for value in (issued, expires, observed)):
        return _reject("WINDOW_AUTHORIZATION_TIME_MALFORMED")
    if issued < 0 or expires <= issued:
        return _reject("WINDOW_AUTHORIZATION_EXPIRY_INVALID")
    if observed < issued or observed >= expires:
        return _reject("WINDOW_AUTHORIZATION_STALE_OR_EXPIRED")
    operator_text = payload.get("synthetic_operator_authorization_utf8")
    if operator_text != SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT:
        return _reject("WINDOW_OPERATOR_AUTHORIZATION_BYTES_MISMATCH")
    if payload.get("synthetic_operator_authorization_sha256") != sha256_bytes(
        SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT.encode("utf-8")
    ):
        return _reject("WINDOW_OPERATOR_AUTHORIZATION_HASH_MISMATCH")
    snapshot_hash = payload.get("fresh_pre_authorization_safety_snapshot_sha256")
    if not _is_sha256(snapshot_hash):
        return _reject("WINDOW_FRESH_SAFETY_SNAPSHOT_HASH_MISSING")
    if snapshot_hash != data.get("current_fresh_safety_snapshot_sha256"):
        return _reject("WINDOW_FRESH_SAFETY_SNAPSHOT_MISMATCH")
    if data.get("attempt_start_phrase_created") is not False:
        return _reject("ATTEMPT_START_PHRASE_FORBIDDEN")
    if data.get("attempts_authorized") != 0:
        return _reject("INDIVIDUAL_ATTEMPT_PREAUTHORIZATION_FORBIDDEN")
    return _allow("SYNTHETIC_WHOLE_WINDOW_AUTHORIZATION_BINDING_VALID")


def validate_per_attempt_consent_sample(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_PER_ATTEMPT_CONSENT":
        return _reject("CONSENT_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_PER_ATTEMPT_CONSENT_FORBIDDEN")
    if data.get("real_consent_artifact_created") is not False:
        return _reject("REAL_CONSENT_ARTIFACT_FORBIDDEN")
    if data.get("consent_is_execution_authority") is not False:
        return _reject("CONSENT_EXECUTION_AUTHORITY_FORBIDDEN")
    payload = data.get("consent_payload")
    if not isinstance(payload, Mapping):
        return _reject("CONSENT_PAYLOAD_MALFORMED")
    if canonical_sha256(payload) != data.get("consent_payload_sha256"):
        return _reject("CONSENT_PAYLOAD_HASH_MISMATCH")
    if payload.get("session_id") != data.get("expected_session_id"):
        return _reject("CONSENT_SESSION_ID_MISMATCH")
    if payload.get("independent_reset_instance_id") != data.get("expected_reset_id"):
        return _reject("CONSENT_RESET_ID_MISMATCH")
    if payload.get("campaign_ordinal") != data.get("expected_ordinal"):
        return _reject("CONSENT_ORDINAL_MISMATCH")
    ordinal = payload.get("campaign_ordinal")
    if not _is_int(ordinal) or ordinal < 1 or ordinal > 10:
        return _reject("CONSENT_ORDINAL_OUT_OF_SCOPE")
    window_hash = payload.get("whole_window_authorization_sha256")
    if not _is_sha256(window_hash):
        return _reject("CONSENT_WINDOW_AUTHORIZATION_HASH_MISSING")
    if window_hash != data.get("current_whole_window_authorization_sha256"):
        return _reject("CONSENT_WINDOW_AUTHORIZATION_MISMATCH")
    snapshot_hash = payload.get("fresh_physical_safety_snapshot_sha256")
    if not _is_sha256(snapshot_hash):
        return _reject("CONSENT_SAFETY_SNAPSHOT_HASH_MISSING")
    if snapshot_hash != data.get("current_fresh_safety_snapshot_sha256"):
        return _reject("CONSENT_SAFETY_SNAPSHOT_MISMATCH")
    issued = payload.get("issued_monotonic_ns")
    expires = payload.get("expires_monotonic_ns")
    observed = data.get("observed_monotonic_ns")
    if not all(_is_int(value) for value in (issued, expires, observed)):
        return _reject("CONSENT_TIME_MALFORMED")
    if issued < 0 or expires <= issued:
        return _reject("CONSENT_EXPIRY_INVALID")
    if observed < issued or observed >= expires:
        return _reject("CONSENT_STALE_OR_EXPIRED")
    if payload.get("one_time_use") is not True:
        return _reject("CONSENT_ONE_TIME_BINDING_MISSING")
    if data.get("consent_consumed") is not False:
        return _reject("CONSENT_ALREADY_CONSUMED")
    if data.get("consent_reused") is not False:
        return _reject("CONSENT_REUSE_FORBIDDEN")
    if data.get("any_safety_gate_changed_after_consent") is not False:
        return _reject("CONSENT_INVALIDATED_BY_SAFETY_CHANGE")
    if data.get("safety_snapshot_generation") != data.get(
        "current_safety_snapshot_generation"
    ):
        return _reject("CONSENT_SAFETY_GENERATION_MISMATCH")
    if data.get("attempt_authorized") is not False:
        return _reject("INDIVIDUAL_ATTEMPT_AUTHORIZATION_FORBIDDEN")
    if data.get("start_requested") is not False:
        return _reject("CONSENT_IS_NOT_START_AUTHORITY")
    return _allow("SYNTHETIC_PER_ATTEMPT_CONSENT_BINDING_VALID")


SAFETY_EXPECTATIONS: tuple[tuple[str, bool, str], ...] = (
    ("power_state_known", True, "POWER_STATE_INDETERMINATE"),
    ("stable_external_power", True, "STABLE_EXTERNAL_POWER_REQUIRED"),
    ("critical_battery_warning", False, "CRITICAL_BATTERY_WARNING"),
    ("pending_restart_or_shutdown", False, "RESTART_OR_SHUTDOWN_PENDING"),
    ("free_space_known", True, "FREE_SPACE_INDETERMINATE"),
    ("free_space_sufficient", True, "FREE_SPACE_INSUFFICIENT"),
    ("all_required_files_fully_local", True, "REQUIRED_FILES_NOT_FULLY_LOCAL"),
    ("files_on_demand_placeholders_absent", True, "FILES_ON_DEMAND_PLACEHOLDER"),
    ("onedrive_sync_paused", True, "ONEDRIVE_SYNC_NOT_PAUSED"),
    ("second_device_writer_absent", True, "SECOND_DEVICE_WRITER_PRESENT"),
    ("second_process_writer_absent", True, "SECOND_PROCESS_WRITER_PRESENT"),
    ("campaign_process_inactive", True, "CAMPAIGN_PROCESS_ACTIVE"),
    ("miner_process_inactive", True, "MINER_PROCESS_ACTIVE"),
    ("approved_miner_hash_exact", True, "APPROVED_MINER_HASH_MISMATCH"),
    ("protected_nas_services_untouched", True, "PROTECTED_NAS_SERVICE_CHANGE"),
)


def validate_fresh_safety_snapshot_sample(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_FRESH_SAFETY_SNAPSHOT":
        return _reject("SAFETY_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_SAFETY_ATTESTATION_FORBIDDEN")
    if data.get("real_safety_attestation_created") is not False:
        return _reject("REAL_SAFETY_ATTESTATION_ARTIFACT_FORBIDDEN")
    if data.get("evidence_class") != HISTORICAL_OBSERVATION_LABEL:
        return _reject("SAFETY_EVIDENCE_CLASS_INVALID")
    if data.get("historical_observation_label") != HISTORICAL_OBSERVATION_LABEL:
        return _reject("HISTORICAL_OBSERVATION_LABEL_MISSING")
    if data.get("physical_readiness_assessed") is not False:
        return _reject("DRY_RUN_CANNOT_ASSERT_PHYSICAL_READINESS")
    payload = data.get("snapshot_payload")
    if not isinstance(payload, Mapping):
        return _reject("SAFETY_SNAPSHOT_PAYLOAD_MALFORMED")
    if canonical_sha256(payload) != data.get("snapshot_payload_sha256"):
        return _reject("SAFETY_SNAPSHOT_PAYLOAD_HASH_MISMATCH")
    if payload.get("window_number") != 1:
        return _reject("SAFETY_WINDOW_MISMATCH")
    ordinal = payload.get("campaign_ordinal")
    if not _is_int(ordinal) or ordinal < 1 or ordinal > 10:
        return _reject("SAFETY_ORDINAL_OUT_OF_SCOPE")
    if payload.get("session_id") != data.get("expected_session_id"):
        return _reject("SAFETY_SESSION_ID_MISMATCH")
    if payload.get("independent_reset_instance_id") != data.get("expected_reset_id"):
        return _reject("SAFETY_RESET_ID_MISMATCH")
    if ordinal != data.get("expected_ordinal"):
        return _reject("SAFETY_ORDINAL_MISMATCH")
    issued = payload.get("captured_monotonic_ns")
    expires = payload.get("expires_monotonic_ns")
    observed = data.get("observed_monotonic_ns")
    if not all(_is_int(value) for value in (issued, expires, observed)):
        return _reject("SAFETY_TIME_MALFORMED")
    if issued < 0 or expires <= issued:
        return _reject("SAFETY_EXPIRY_INVALID")
    if observed < issued or observed >= expires:
        return _reject("SAFETY_SNAPSHOT_STALE_OR_EXPIRED")
    if payload.get("approved_miner_sha256") != APPROVED_MINER_SHA256:
        return _reject("APPROVED_MINER_BINDING_MISMATCH")
    for field, expected, reason in SAFETY_EXPECTATIONS:
        if payload.get(field) is not expected:
            return _reject(reason)
    if data.get("snapshot_consumed") is not False:
        return _reject("SAFETY_SNAPSHOT_CONSUMPTION_FORBIDDEN")
    return _allow("SYNTHETIC_FRESH_SAFETY_SNAPSHOT_CONTRACT_VALID")


ALLOWED_GOVERNANCE_ACTION = "VALIDATE_SYNTHETIC_DRY_RUN_ONLY"
FORBIDDEN_ACTIONS = {
    "AUTHORIZE_WINDOW_01_EXECUTION",
    "AUTHORIZE_INDIVIDUAL_ATTEMPT",
    "CONSUME_AUTHORIZATION",
    "CONSUME_IDENTITY",
    "PLANNED_TO_STARTED",
    "CREATE_CAMPAIGN_OUTPUT_ROOT",
    "CREATE_ATTEMPT_DIRECTORY",
    "CREATE_ATTEMPT_START_PHRASE",
    "CREATE_EXECUTION_PHRASE",
    "AUTO_START_ORDINAL_1",
    "AUTO_START_NEXT_ATTEMPT",
    "RETRY",
    "RESUME",
    "REPLACE_IDENTITY",
    "REUSE_IDENTITY",
    "CONTINUE_AFTER_INTERRUPTION",
    "CONTINUE_AFTER_OUTCOME_INSPECTION",
    "OPTIONAL_STOPPING",
    "TRANSITION_TO_WINDOW_02",
    "LAUNCH_MINER",
    "CONTACT_POOL",
    "START_LIVE",
    "INSPECT_OUTCOME",
    "COMPUTE_SCIENTIFIC_ENDPOINT",
}


def validate_execution_block(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_GOVERNANCE_ACTION":
        return _reject("GOVERNANCE_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_GOVERNANCE_ACTION_FORBIDDEN")
    action = data.get("action")
    if action in FORBIDDEN_ACTIONS:
        return _reject(f"GOVERNANCE_ACTION_FORBIDDEN:{action}")
    if action != ALLOWED_GOVERNANCE_ACTION:
        return _reject("UNKNOWN_GOVERNANCE_ACTION")
    if data.get("execution_count_delta") != 0:
        return _reject("EXECUTION_DELTA_MUST_REMAIN_ZERO")
    if data.get("authorization_consumption_delta") != 0:
        return _reject("AUTHORIZATION_CONSUMPTION_DELTA_MUST_REMAIN_ZERO")
    if data.get("identity_consumption_delta") != 0:
        return _reject("IDENTITY_CONSUMPTION_DELTA_MUST_REMAIN_ZERO")
    return _allow("EXECUTION_BLOCK_CONTRACT_VALID")


def validate_path_confinement(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_PATH_REFERENCE":
        return _reject("PATH_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_PATH_OPERATION_FORBIDDEN")
    path_value = data.get("relative_path")
    if not isinstance(path_value, str) or not path_value:
        return _reject("PATH_MISSING_OR_MALFORMED")
    if PureWindowsPath(path_value).is_absolute() or PurePosixPath(path_value).is_absolute():
        return _reject("ABSOLUTE_PATH_FORBIDDEN")
    if "\\" in path_value or ":" in path_value:
        return _reject("NON_CANONICAL_PATH_SEPARATOR_OR_DRIVE_FORBIDDEN")
    path = PurePosixPath(path_value)
    if ".." in path.parts:
        return _reject("PARENT_TRAVERSAL_FORBIDDEN")
    if data.get("symlink_component_present") is not False:
        return _reject("SYMLINK_ESCAPE_FORBIDDEN")
    if data.get("reparse_component_present") is not False:
        return _reject("REPARSE_ESCAPE_FORBIDDEN")
    if data.get("target_class") != "DRY_RUN_PACKAGE_ONLY":
        return _reject("PATH_TARGET_CLASS_FORBIDDEN")
    if data.get("create_path_requested") is not False:
        return _reject("PATH_CREATION_FORBIDDEN")
    return _allow("SYNTHETIC_PATH_REFERENCE_VALID")


def validate_secret_scan_sample(data: Mapping[str, Any]) -> Decision:
    if data.get("sample_class") != "SYNTHETIC_DRY_RUN_SECRET_SCAN":
        return _reject("SECRET_SCAN_SAMPLE_CLASS_INVALID")
    if data.get("synthetic_fixture_only") is not True:
        return _reject("REAL_SECRET_MATERIAL_FORBIDDEN")
    if data.get("high_confidence_secret_findings") != 0:
        return _reject("SECRET_FINDING")
    if data.get("credential_material_present") is not False:
        return _reject("CREDENTIAL_MATERIAL_FORBIDDEN")
    if data.get("private_key_material_present") is not False:
        return _reject("PRIVATE_KEY_MATERIAL_FORBIDDEN")
    if data.get("unrelated_personal_data_present") is not False:
        return _reject("UNRELATED_PERSONAL_DATA_FORBIDDEN")
    return _allow("SYNTHETIC_SECRET_SCAN_CONTRACT_VALID")


VALIDATORS: dict[str, Validator] = {
    "validate_whole_window_authorization_sample": validate_whole_window_authorization_sample,
    "validate_per_attempt_consent_sample": validate_per_attempt_consent_sample,
    "validate_fresh_safety_snapshot_sample": validate_fresh_safety_snapshot_sample,
    "validate_execution_block": validate_execution_block,
    "validate_path_confinement": validate_path_confinement,
    "validate_secret_scan_sample": validate_secret_scan_sample,
}


def invoke_validator(name: str, data: Mapping[str, Any]) -> Decision:
    validator = VALIDATORS.get(name)
    if validator is None:
        return _reject("UNKNOWN_VALIDATOR")
    return validator(data)
