"""Build the additive Window 01 hash-bound enablement dry-run package.

This builder creates only synthetic metadata, validation reports, manifests,
checksums, and a deterministic audit archive inside this package directory.
It cannot create campaign evidence, authorization authority, consent authority,
attempt directories, lifecycle transitions, network traffic, or processes.
"""

from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import json
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
I0_ROOT = ROOT.parent
SRC_ROOT = ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from window01_hash_bound_dry_run.validators import (  # noqa: E402
    ALLOWED_GOVERNANCE_ACTION,
    APPROVED_MINER_SHA256,
    FREEZE_MANIFEST_SHA256,
    FREEZE_PAYLOAD_ROOT_SHA256,
    HISTORICAL_OBSERVATION_LABEL,
    IMMUTABLE_ROSTER_SHA256,
    SAFETY_EXPECTATIONS,
    SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT,
    canonical_bytes,
    canonical_sha256,
    invoke_validator,
    sha256_bytes,
)


CREATED_AT_UTC = "2026-07-17T00:00:00Z"
SCHEMA_PREFIX = "JANUS/A18.44/v0.1/window-01-authorization-safety-hash-bound-dry-run"
ZIP_NAME = "JANUS_A18_44_V0_1_WINDOW_01_AUTHORIZATION_SAFETY_HASH_BOUND_DRY_RUN_AUDIT_EXPORT.zip"
NEXT_STAGE = (
    "A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_"
    "WHOLE_WINDOW_AUTHORIZATION_ARTIFACT_FREEZE_ONLY"
)

FREEZE_ROOT = (
    I0_ROOT
    / "JANUS_A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_ATTESTATION_FREEZE"
)
REPAIR_ROOT = (
    I0_ROOT
    / "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_"
    "HASH_BOUND_EXECUTION_PACKAGE_DRY_RUN_FIXTURE_COVERAGE_REPAIR"
)
CAMPAIGN_OUTPUT_ROOT = (
    I0_ROOT / "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_OUTPUT"
)
DOWNLOADS = Path.home() / "Downloads"

EXPECTED = {
    "current_audit_json": "b534ea611a0278173503f87e5ac3984fa65f729e8a4dfee9029cd07cdf8c1dca",
    "current_audit_text": "f9a3dd24d71aaa7156954aaa1883a0638c01837a236253b200f532618e84f819",
    "freeze_archive": "7df6d74f0cb764c4ed3acf3c858430037beb8bf0a7ed8452b48ca5e1e6a6fdda",
    "freeze_manifest": FREEZE_MANIFEST_SHA256,
    "freeze_sums": "5f2dcd12b28f7423154feb35810cadd06feb739b9a848f5592350c91adb43783",
    "freeze_payload_root": FREEZE_PAYLOAD_ROOT_SHA256,
    "freeze_fixtures": "b4d9ccba1428040b0c32a6867696db4b6824c19883618f079bc23c1a7fb4f29f",
    "freeze_validator": "b1e29e17191d03b2984a1c4fbcd7484c17d98ad136348c880226e7527df2850c",
    "freeze_roster": IMMUTABLE_ROSTER_SHA256,
    "predecessor_nonpass_json": "b3eeba525e72c7b138ec668685c450764706d0e0b4ac73d0020490a99bdbc01f",
    "predecessor_nonpass_text": "0908449fc14e310c19e791ec8e20cfda74c20055a9e985e25426143d30fbaf1d",
    "repair_audit_json": "a2dc8e788a0e6cecf8685556524ffbe3dde8cc32099440ff2f38f20360bed79d",
    "repair_audit_text": "f738758fc3f2c2b75658f1d1b91148892ffbdeb5112e8a3745ea7b9a7a102791",
    "repair_archive": "d0d58c01580810efbdaa5441edf58f4c6a5a19511c1ea69ed45feed11244d69c",
    "repair_payload_root": "00edd648c1b64c29bea7d4113bad373b3f05372ffc8a14eb23494a19fa22b5ab",
}

FILES = {
    "current_audit_json": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_AUTHORIZATION_SAFETY_FREEZE_INDEPENDENT_AUDIT_RESULT.json",
    "current_audit_text": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_AUTHORIZATION_SAFETY_FREEZE_INDEPENDENT_AUDIT_RESULT.txt",
    "predecessor_nonpass_json": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_PACKAGE_DRY_RUN_INDEPENDENT_AUDIT_RESULT.json",
    "predecessor_nonpass_text": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_PACKAGE_DRY_RUN_INDEPENDENT_AUDIT_RESULT.txt",
    "repair_audit_json": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT_RESULT.json",
    "repair_audit_text": DOWNLOADS
    / "JANUS_A18_44_WINDOW_01_FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT_RESULT.txt",
    "freeze_archive": FREEZE_ROOT
    / "JANUS_A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_FREEZE_AUDIT_EXPORT.zip",
    "freeze_manifest": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_FREEZE_MANIFEST.json",
    "freeze_sums": FREEZE_ROOT / "SHA256SUMS.txt",
    "freeze_fixtures": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_NEGATIVE_VALIDATION_FIXTURES.json",
    "freeze_validator": FREEZE_ROOT / "src" / "window01_safety_freeze" / "validators.py",
    "freeze_roster": FREEZE_ROOT
    / "predecessor_bindings"
    / "PREVIOUS_WINDOW_01_IDENTITY_ROSTER.json",
    "repair_archive": REPAIR_ROOT
    / "JANUS_A18_44_V0_1_WINDOW_01_PACKAGE_DRY_RUN_FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip",
}

FREEZE_BINDINGS = {
    "freeze_artifact": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_AND_FRESH_SAFETY_ATTESTATION_FREEZE.json",
    "whole_window_contract": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_WHOLE_WINDOW_AUTHORIZATION_CONTRACT.json",
    "per_attempt_consent_contract": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_PER_ATTEMPT_CONSENT_CONTRACT.json",
    "fresh_safety_contract": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_FRESH_PHYSICAL_SAFETY_ATTESTATION_CONTRACT.json",
    "execution_block_contract": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_EXECUTION_BLOCK_CONTRACT.json",
    "interruption_policy": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_INTERRUPTION_AND_CONTINUATION_POLICY.json",
    "freeze_validation": FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_FREEZE_VALIDATION_REPORT.json",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def duplicate_key_guard(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    return json.loads(
        path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key_guard
    )


def write_json(path: Path, value: Any) -> None:
    path.write_bytes(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        + b"\n"
    )


def inventory(root: Path, excluded: set[str] | None = None) -> list[dict[str, Any]]:
    excluded = excluded or set()
    records: list[dict[str, Any]] = []
    for path in sorted(
        (candidate for candidate in root.rglob("*") if candidate.is_file()),
        key=lambda candidate: candidate.relative_to(root).as_posix().encode("utf-8"),
    ):
        relative = path.relative_to(root).as_posix()
        if relative in excluded:
            continue
        records.append(
            {
                "relative_path": relative,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return records


def payload_root(records: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
        digest.update(record["relative_path"].encode("utf-8"))
        digest.update(b"\x00")
        digest.update(str(record["size_bytes"]).encode("ascii"))
        digest.update(b"\x00")
        digest.update(bytes.fromhex(record["sha256"]))
        digest.update(b"\n")
    return digest.hexdigest()


def verify_sums(root: Path, sums_path: Path) -> tuple[int, int]:
    passed = 0
    total = 0
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        total += 1
        expected, relative = line.split("  ", 1)
        target = root / PurePosixPath(relative)
        if target.is_file() and sha256_file(target) == expected:
            passed += 1
    return passed, total


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"MODULE_LOAD_FAILED:{path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_source_ast(path: Path, validator: bool) -> dict[str, Any]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    forbidden_imports = {"socket", "subprocess", "requests", "urllib", "http", "ftplib"}
    imported: set[str] = set()
    calls: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module.split(".", 1)[0])
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                calls.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                calls.append(node.func.attr)
    bad_imports = sorted(imported & forbidden_imports)
    if bad_imports:
        raise RuntimeError(f"FORBIDDEN_IMPORTS:{path}:{bad_imports}")
    forbidden_calls = {"Popen", "run", "call", "check_call", "check_output", "system"}
    if validator:
        forbidden_calls |= {
            "open",
            "write_bytes",
            "write_text",
            "mkdir",
            "unlink",
            "rename",
            "replace",
            "rmdir",
        }
    bad_calls = sorted(set(calls) & forbidden_calls)
    if bad_calls:
        raise RuntimeError(f"FORBIDDEN_CALLS:{path}:{bad_calls}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": sha256_file(path),
        "forbidden_imports": bad_imports,
        "forbidden_calls": bad_calls,
        "compiled": True,
    }


def verify_freeze_package() -> dict[str, Any]:
    for name, path in FILES.items():
        if not path.is_file():
            raise RuntimeError(f"PREDECESSOR_FILE_MISSING:{name}")
        if name in EXPECTED and sha256_file(path) != EXPECTED[name]:
            raise RuntimeError(f"PREDECESSOR_HASH_MISMATCH:{name}")

    current_audit = load_json(FILES["current_audit_json"])
    if current_audit.get("audit_status") != "PASS":
        raise RuntimeError("INDEPENDENT_FREEZE_AUDIT_NOT_PASS")
    if current_audit.get("first_blocking_invariant") != "NONE":
        raise RuntimeError("INDEPENDENT_FREEZE_AUDIT_HAS_BLOCKER")
    if current_audit["audited_archive"].get("sha256") != EXPECTED["freeze_archive"]:
        raise RuntimeError("INDEPENDENT_FREEZE_AUDIT_ARCHIVE_MISMATCH")

    manifest = load_json(FILES["freeze_manifest"])
    if manifest.get("freeze_payload_root_sha256") != EXPECTED["freeze_payload_root"]:
        raise RuntimeError("FREEZE_PAYLOAD_ROOT_MISMATCH")
    if manifest.get("file_count") != 23 or len(manifest.get("files", [])) != 23:
        raise RuntimeError("FREEZE_MANIFEST_FILE_COUNT_MISMATCH")
    passed_sums, total_sums = verify_sums(FREEZE_ROOT, FILES["freeze_sums"])
    if (passed_sums, total_sums) != (24, 24):
        raise RuntimeError("FREEZE_SHA256SUMS_MISMATCH")

    payload_records = inventory(
        FREEZE_ROOT,
        {
            FILES["freeze_manifest"].name,
            FILES["freeze_sums"].name,
            FILES["freeze_archive"].name,
        },
    )
    if len(payload_records) != 23 or payload_root(payload_records) != EXPECTED["freeze_payload_root"]:
        raise RuntimeError("FREEZE_PAYLOAD_REPRODUCTION_MISMATCH")
    expected_manifest = {
        item["relative_path"]: (item["size_bytes"], item["sha256"])
        for item in manifest["files"]
    }
    if any(
        expected_manifest.get(item["relative_path"])
        != (item["size_bytes"], item["sha256"])
        for item in payload_records
    ):
        raise RuntimeError("FREEZE_MANIFEST_MEMBER_MISMATCH")

    json_files = sorted(FREEZE_ROOT.rglob("*.json"))
    for path in json_files:
        load_json(path)
    if len(json_files) != 18:
        raise RuntimeError("FREEZE_STRICT_JSON_COUNT_MISMATCH")

    source_index = {
        item["relative_path"]: (item["size_bytes"], item["sha256"])
        for item in inventory(FREEZE_ROOT, {FILES["freeze_archive"].name})
    }
    with zipfile.ZipFile(FILES["freeze_archive"], "r") as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(infos) != 25 or len(set(names)) != 25 or archive.testzip() is not None:
            raise RuntimeError("FREEZE_ARCHIVE_STRUCTURE_MISMATCH")
        if set(names) != set(source_index):
            raise RuntimeError("FREEZE_ARCHIVE_INVENTORY_MISMATCH")
        for info in infos:
            if info.flag_bits & 1:
                raise RuntimeError("FREEZE_ARCHIVE_ENCRYPTED_MEMBER")
            parts = PurePosixPath(info.filename).parts
            if PurePosixPath(info.filename).is_absolute() or ".." in parts or "\\" in info.filename:
                raise RuntimeError("FREEZE_ARCHIVE_UNSAFE_PATH")
            if ((info.external_attr >> 16) & 0o170000) == stat.S_IFLNK:
                raise RuntimeError("FREEZE_ARCHIVE_SYMLINK_MEMBER")
            data = archive.read(info.filename)
            if (len(data), sha256_bytes(data)) != source_index[info.filename]:
                raise RuntimeError("FREEZE_ARCHIVE_MEMBER_HASH_MISMATCH")

    freeze_module = load_module(FILES["freeze_validator"], "frozen_safety_validators")
    fixture_document = load_json(FILES["freeze_fixtures"])
    fixtures = fixture_document["fixtures"]
    ids: set[str] = set()
    pairs: set[tuple[str, str]] = set()
    inputs = returns = decisions = 0
    for fixture in fixtures:
        ids.add(fixture["fixture_id"])
        pairs.add((fixture["validator_callable"], fixture["input_sha256"]))
        if sha256_bytes(canonical_bytes(fixture["input"])) != fixture["input_sha256"]:
            raise RuntimeError("FREEZE_FIXTURE_INPUT_HASH_MISMATCH")
        returned = freeze_module.invoke_validator(
            fixture["validator_callable"], fixture["input"]
        )
        inputs += 1
        if sha256_bytes(canonical_bytes(returned)) != fixture["return_sha256"]:
            raise RuntimeError("FREEZE_FIXTURE_RETURN_HASH_MISMATCH")
        returns += 1
        if returned.get("decision") != fixture["expected_decision"]:
            raise RuntimeError("FREEZE_FIXTURE_DECISION_MISMATCH")
        decisions += 1
    if (len(fixtures), len(ids), len(pairs), inputs, returns, decisions) != (
        81,
        81,
        81,
        81,
        81,
        81,
    ):
        raise RuntimeError("FREEZE_FIXTURE_COVERAGE_MISMATCH")
    if sum(item["execution_count_delta"] for item in fixtures) != 0:
        raise RuntimeError("FREEZE_FIXTURE_EXECUTION_OCCURRED")
    if sum(item["authorization_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("FREEZE_FIXTURE_AUTHORIZATION_CONSUMED")
    if sum(item["identity_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("FREEZE_FIXTURE_IDENTITY_CONSUMED")

    roster = load_json(FILES["freeze_roster"])
    attempts = roster.get("attempts", [])
    if len(attempts) != 10:
        raise RuntimeError("WINDOW_01_ROSTER_COUNT_MISMATCH")
    if [item.get("campaign_attempt_ordinal") for item in attempts] != list(range(1, 11)):
        raise RuntimeError("WINDOW_01_ROSTER_ORDER_MISMATCH")
    if any(
        item.get("identity_consumed") is not False
        or item.get("attempt_started") is not False
        or item.get("attempt_authorized") is not False
        for item in attempts
    ):
        raise RuntimeError("WINDOW_01_IDENTITY_STATE_NOT_ZERO")
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_ALREADY_EXISTS")

    return {
        "attachment_bytes_locally_mounted": True,
        "independent_authorization_safety_freeze_audit_ingested": True,
        "independent_audit_status": "PASS",
        "local_authorization_safety_freeze_byte_revalidation": "PASS",
        "archive_members": "25/25",
        "zip_crc": "PASS",
        "strict_json": "18/18",
        "sha256sums": "24/24",
        "manifest_files": "23/23",
        "governance_negative_fixtures": "81/81",
        "unique_fixture_ids": "81/81",
        "input_hashes_reproduced": "81/81",
        "return_hashes_reproduced": "81/81",
        "fixture_execution_count": 0,
        "fixture_authorization_consumption_count": 0,
        "fixture_identity_consumption_count": 0,
        "window_01_identities_unconsumed": "10/10",
        "window_01_attempts_unstarted": "10/10",
        "window_01_attempts_unauthorized": "10/10",
    }


def safe_remove_generated() -> None:
    generated_directories = [ROOT / "independent_audit", ROOT / "predecessor_bindings"]
    generated_files = [
        ROOT / "README.md",
        ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_ENABLEMENT_BINDING_RECEIPT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_SYNTHETIC_DRY_RUN_SAMPLES.json",
        ROOT / "A18_44_V0_1_WINDOW_01_WHOLE_WINDOW_AUTHORIZATION_VALIDATOR_CONTRACT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_PER_ATTEMPT_CONSENT_VALIDATOR_CONTRACT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_FRESH_SAFETY_VALIDATOR_CONTRACT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_EXECUTION_BLOCK_VALIDATOR_CONTRACT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_EXECUTABLE_NEGATIVE_FIXTURES.json",
        ROOT / "A18_44_V0_1_WINDOW_01_SECURITY_AND_PRIVACY_REPORT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_VALIDATION_REPORT.json",
        ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_PACKAGE_MANIFEST.json",
        ROOT / "SHA256SUMS.txt",
        ROOT / ZIP_NAME,
    ]
    for directory in generated_directories:
        if directory.exists():
            if directory.is_symlink() or directory.resolve().parent != ROOT.resolve():
                raise RuntimeError(f"UNSAFE_GENERATED_DIRECTORY:{directory}")
            shutil.rmtree(directory)
    for path in generated_files:
        if path.exists():
            if path.is_symlink() or path.resolve().parent != ROOT.resolve():
                raise RuntimeError(f"UNSAFE_GENERATED_FILE:{path}")
            path.unlink()


def copy_bindings() -> dict[str, str]:
    independent = ROOT / "independent_audit"
    predecessor = ROOT / "predecessor_bindings"
    independent.mkdir(parents=True, exist_ok=True)
    predecessor.mkdir(parents=True, exist_ok=True)
    copies = [
        (FILES["current_audit_json"], independent / FILES["current_audit_json"].name),
        (FILES["current_audit_text"], independent / FILES["current_audit_text"].name),
        (
            FILES["predecessor_nonpass_json"],
            predecessor / "PRESERVED_PACKAGE_DRY_RUN_AUDIT_EVIDENCE_INSUFFICIENT.json",
        ),
        (
            FILES["predecessor_nonpass_text"],
            predecessor / "PRESERVED_PACKAGE_DRY_RUN_AUDIT_EVIDENCE_INSUFFICIENT.txt",
        ),
        (
            FILES["repair_audit_json"],
            predecessor / "FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT_PASS.json",
        ),
        (
            FILES["repair_audit_text"],
            predecessor / "FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT_PASS.txt",
        ),
        (FILES["repair_archive"], predecessor / "FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip"),
        (FILES["freeze_archive"], predecessor / "AUTHORIZATION_SAFETY_FREEZE_AUDIT_EXPORT.zip"),
        (FILES["freeze_manifest"], predecessor / "AUTHORIZATION_SAFETY_FREEZE_MANIFEST.json"),
        (FILES["freeze_sums"], predecessor / "AUTHORIZATION_SAFETY_FREEZE_SHA256SUMS.txt"),
        (FILES["freeze_fixtures"], predecessor / "AUTHORIZATION_SAFETY_FREEZE_GOVERNANCE_FIXTURES.json"),
        (FILES["freeze_roster"], predecessor / "WINDOW_01_IMMUTABLE_IDENTITY_ROSTER.json"),
    ]
    for key, source in FREEZE_BINDINGS.items():
        copies.append((source, predecessor / f"FROZEN_{key.upper()}.json"))
    copied: dict[str, str] = {}
    for source, target in copies:
        if not source.is_file():
            raise RuntimeError(f"BINDING_SOURCE_MISSING:{source}")
        shutil.copyfile(source, target)
        if source.read_bytes() != target.read_bytes():
            raise RuntimeError(f"BINDING_COPY_BYTE_MISMATCH:{target}")
        copied[target.relative_to(ROOT).as_posix()] = sha256_file(target)
    return copied


def make_samples(attempt: dict[str, Any]) -> dict[str, Any]:
    safety_payload: dict[str, Any] = {
        "window_number": 1,
        "campaign_ordinal": attempt["campaign_attempt_ordinal"],
        "session_id": attempt["session_id"],
        "independent_reset_instance_id": attempt["independent_reset_instance_id"],
        "captured_monotonic_ns": 1_000_000,
        "expires_monotonic_ns": 1_100_000,
        "approved_miner_sha256": APPROVED_MINER_SHA256,
    }
    for field, expected, _ in SAFETY_EXPECTATIONS:
        safety_payload[field] = expected
    safety_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_FRESH_SAFETY_SNAPSHOT",
        "synthetic_fixture_only": True,
        "real_safety_attestation_created": False,
        "evidence_class": HISTORICAL_OBSERVATION_LABEL,
        "historical_observation_label": HISTORICAL_OBSERVATION_LABEL,
        "physical_readiness_assessed": False,
        "snapshot_payload": safety_payload,
        "snapshot_payload_sha256": canonical_sha256(safety_payload),
        "observed_monotonic_ns": 1_050_000,
        "expected_session_id": attempt["session_id"],
        "expected_reset_id": attempt["independent_reset_instance_id"],
        "expected_ordinal": attempt["campaign_attempt_ordinal"],
        "snapshot_consumed": False,
    }

    authorization_payload = {
        "freeze_payload_root_sha256": FREEZE_PAYLOAD_ROOT_SHA256,
        "freeze_manifest_sha256": FREEZE_MANIFEST_SHA256,
        "immutable_roster_sha256": IMMUTABLE_ROSTER_SHA256,
        "window_number": 1,
        "ordinals": list(range(1, 11)),
        "first_ordinal": 1,
        "last_ordinal": 10,
        "attempt_count": 10,
        "issued_monotonic_ns": 2_000_000,
        "expires_monotonic_ns": 2_100_000,
        "synthetic_operator_authorization_utf8": SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT,
        "synthetic_operator_authorization_sha256": sha256_bytes(
            SYNTHETIC_OPERATOR_AUTHORIZATION_TEXT.encode("utf-8")
        ),
        "fresh_pre_authorization_safety_snapshot_sha256": safety_sample[
            "snapshot_payload_sha256"
        ],
    }
    authorization_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_WHOLE_WINDOW_AUTHORIZATION",
        "synthetic_fixture_only": True,
        "real_authorization_artifact_created": False,
        "execution_authority": False,
        "authorization_consumed": False,
        "binding_payload": authorization_payload,
        "binding_payload_sha256": canonical_sha256(authorization_payload),
        "observed_monotonic_ns": 2_050_000,
        "current_fresh_safety_snapshot_sha256": safety_sample[
            "snapshot_payload_sha256"
        ],
        "attempt_start_phrase_created": False,
        "attempts_authorized": 0,
    }

    consent_payload = {
        "session_id": attempt["session_id"],
        "independent_reset_instance_id": attempt["independent_reset_instance_id"],
        "campaign_ordinal": attempt["campaign_attempt_ordinal"],
        "whole_window_authorization_sha256": authorization_sample[
            "binding_payload_sha256"
        ],
        "fresh_physical_safety_snapshot_sha256": safety_sample[
            "snapshot_payload_sha256"
        ],
        "issued_monotonic_ns": 3_000_000,
        "expires_monotonic_ns": 3_010_000,
        "one_time_use": True,
    }
    consent_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_PER_ATTEMPT_CONSENT",
        "synthetic_fixture_only": True,
        "real_consent_artifact_created": False,
        "consent_is_execution_authority": False,
        "consent_payload": consent_payload,
        "consent_payload_sha256": canonical_sha256(consent_payload),
        "expected_session_id": attempt["session_id"],
        "expected_reset_id": attempt["independent_reset_instance_id"],
        "expected_ordinal": attempt["campaign_attempt_ordinal"],
        "current_whole_window_authorization_sha256": authorization_sample[
            "binding_payload_sha256"
        ],
        "current_fresh_safety_snapshot_sha256": safety_sample[
            "snapshot_payload_sha256"
        ],
        "observed_monotonic_ns": 3_005_000,
        "consent_consumed": False,
        "consent_reused": False,
        "any_safety_gate_changed_after_consent": False,
        "safety_snapshot_generation": 1,
        "current_safety_snapshot_generation": 1,
        "attempt_authorized": False,
        "start_requested": False,
    }

    execution_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_GOVERNANCE_ACTION",
        "synthetic_fixture_only": True,
        "action": ALLOWED_GOVERNANCE_ACTION,
        "execution_count_delta": 0,
        "authorization_consumption_delta": 0,
        "identity_consumption_delta": 0,
    }
    path_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_PATH_REFERENCE",
        "synthetic_fixture_only": True,
        "relative_path": "fixtures/synthetic/window_01.json",
        "symlink_component_present": False,
        "reparse_component_present": False,
        "target_class": "DRY_RUN_PACKAGE_ONLY",
        "create_path_requested": False,
    }
    secret_sample = {
        "sample_class": "SYNTHETIC_DRY_RUN_SECRET_SCAN",
        "synthetic_fixture_only": True,
        "high_confidence_secret_findings": 0,
        "credential_material_present": False,
        "private_key_material_present": False,
        "unrelated_personal_data_present": False,
    }
    return {
        "safety": safety_sample,
        "authorization": authorization_sample,
        "consent": consent_sample,
        "execution": execution_sample,
        "path": path_sample,
        "secret": secret_sample,
    }


def set_nested(value: dict[str, Any], path: tuple[str, ...], replacement: Any) -> dict[str, Any]:
    changed = copy.deepcopy(value)
    cursor: dict[str, Any] = changed
    for key in path[:-1]:
        child = cursor.get(key)
        if not isinstance(child, dict):
            child = {}
            cursor[key] = child
        cursor = child
    cursor[path[-1]] = replacement
    return changed


def refresh_hash(value: dict[str, Any], payload_key: str, hash_key: str) -> dict[str, Any]:
    changed = copy.deepcopy(value)
    payload_value = changed.get(payload_key)
    if isinstance(payload_value, dict):
        changed[hash_key] = canonical_sha256(payload_value)
    return changed


def build_fixture_specs(samples: dict[str, Any]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []

    def add(
        fixture_id: str,
        category: str,
        validator: str,
        value: dict[str, Any],
    ) -> None:
        specs.append(
            {
                "fixture_id": fixture_id,
                "category": category,
                "validator_callable": validator,
                "input": value,
                "expected_decision": "REJECT",
            }
        )

    authorization = samples["authorization"]
    auth_top = [
        ("AUTH_SAMPLE_CLASS", ("sample_class",), "WRONG"),
        ("AUTH_SYNTHETIC_FALSE", ("synthetic_fixture_only",), False),
        ("AUTH_SYNTHETIC_INDETERMINATE", ("synthetic_fixture_only",), None),
        ("AUTH_REAL_ARTIFACT_TRUE", ("real_authorization_artifact_created",), True),
        ("AUTH_REAL_ARTIFACT_INDETERMINATE", ("real_authorization_artifact_created",), None),
        ("AUTH_EXECUTION_AUTHORITY_TRUE", ("execution_authority",), True),
        ("AUTH_EXECUTION_AUTHORITY_INDETERMINATE", ("execution_authority",), None),
        ("AUTH_CONSUMED_TRUE", ("authorization_consumed",), True),
        ("AUTH_CONSUMED_INDETERMINATE", ("authorization_consumed",), None),
        ("AUTH_PAYLOAD_MISSING", ("binding_payload",), None),
        ("AUTH_PAYLOAD_MALFORMED", ("binding_payload",), []),
        ("AUTH_PAYLOAD_HASH_WRONG", ("binding_payload_sha256",), "0" * 64),
        ("AUTH_PAYLOAD_HASH_MISSING", ("binding_payload_sha256",), None),
        ("AUTH_OBSERVED_TIME_BEFORE", ("observed_monotonic_ns",), 1_999_999),
        ("AUTH_OBSERVED_TIME_EXPIRED", ("observed_monotonic_ns",), 2_100_000),
        ("AUTH_OBSERVED_TIME_MALFORMED", ("observed_monotonic_ns",), "2050000"),
        ("AUTH_CURRENT_SAFETY_HASH_WRONG", ("current_fresh_safety_snapshot_sha256",), "1" * 64),
        ("AUTH_CURRENT_SAFETY_HASH_MISSING", ("current_fresh_safety_snapshot_sha256",), None),
        ("AUTH_ATTEMPT_START_PHRASE_TRUE", ("attempt_start_phrase_created",), True),
        ("AUTH_ATTEMPT_START_PHRASE_INDETERMINATE", ("attempt_start_phrase_created",), None),
        ("AUTH_ATTEMPTS_PREAUTHORIZED", ("attempts_authorized",), 1),
        ("AUTH_ATTEMPTS_AUTHORIZED_INDETERMINATE", ("attempts_authorized",), None),
    ]
    for fixture_id, path, replacement in auth_top:
        add(fixture_id, "WHOLE_WINDOW_AUTHORIZATION", "validate_whole_window_authorization_sample", set_nested(authorization, path, replacement))

    auth_payload_mutations = [
        ("AUTH_FREEZE_ROOT_WRONG", "freeze_payload_root_sha256", "2" * 64),
        ("AUTH_FREEZE_ROOT_MISSING", "freeze_payload_root_sha256", None),
        ("AUTH_FREEZE_MANIFEST_WRONG", "freeze_manifest_sha256", "3" * 64),
        ("AUTH_FREEZE_MANIFEST_MISSING", "freeze_manifest_sha256", None),
        ("AUTH_ROSTER_WRONG", "immutable_roster_sha256", "4" * 64),
        ("AUTH_ROSTER_MISSING", "immutable_roster_sha256", None),
        ("AUTH_WINDOW_NUMBER_WRONG", "window_number", 2),
        ("AUTH_WINDOW_NUMBER_MISSING", "window_number", None),
        ("AUTH_ORDINALS_REORDERED", "ordinals", [2, 1, *range(3, 11)]),
        ("AUTH_ORDINALS_MISSING", "ordinals", None),
        ("AUTH_FIRST_ORDINAL_WRONG", "first_ordinal", 0),
        ("AUTH_LAST_ORDINAL_WRONG", "last_ordinal", 11),
        ("AUTH_COUNT_WRONG", "attempt_count", 9),
        ("AUTH_ISSUED_NEGATIVE", "issued_monotonic_ns", -1),
        ("AUTH_ISSUED_MALFORMED", "issued_monotonic_ns", "2000000"),
        ("AUTH_EXPIRY_EQUAL_ISSUED", "expires_monotonic_ns", 2_000_000),
        ("AUTH_EXPIRY_BEFORE_ISSUED", "expires_monotonic_ns", 1_999_999),
        ("AUTH_EXPIRY_MALFORMED", "expires_monotonic_ns", None),
        ("AUTH_OPERATOR_BYTES_WRONG", "synthetic_operator_authorization_utf8", "WRONG"),
        ("AUTH_OPERATOR_BYTES_MISSING", "synthetic_operator_authorization_utf8", None),
        ("AUTH_OPERATOR_HASH_WRONG", "synthetic_operator_authorization_sha256", "5" * 64),
        ("AUTH_OPERATOR_HASH_MISSING", "synthetic_operator_authorization_sha256", None),
        ("AUTH_SAFETY_HASH_WRONG", "fresh_pre_authorization_safety_snapshot_sha256", "6" * 64),
        ("AUTH_SAFETY_HASH_MISSING", "fresh_pre_authorization_safety_snapshot_sha256", None),
    ]
    for fixture_id, key, replacement in auth_payload_mutations:
        changed = set_nested(authorization, ("binding_payload", key), replacement)
        changed = refresh_hash(changed, "binding_payload", "binding_payload_sha256")
        add(fixture_id, "WHOLE_WINDOW_AUTHORIZATION", "validate_whole_window_authorization_sample", changed)

    consent = samples["consent"]
    consent_top = [
        ("CONSENT_SAMPLE_CLASS", ("sample_class",), "WRONG"),
        ("CONSENT_SYNTHETIC_FALSE", ("synthetic_fixture_only",), False),
        ("CONSENT_SYNTHETIC_INDETERMINATE", ("synthetic_fixture_only",), None),
        ("CONSENT_REAL_ARTIFACT_TRUE", ("real_consent_artifact_created",), True),
        ("CONSENT_REAL_ARTIFACT_INDETERMINATE", ("real_consent_artifact_created",), None),
        ("CONSENT_EXECUTION_AUTHORITY_TRUE", ("consent_is_execution_authority",), True),
        ("CONSENT_EXECUTION_AUTHORITY_INDETERMINATE", ("consent_is_execution_authority",), None),
        ("CONSENT_PAYLOAD_MISSING", ("consent_payload",), None),
        ("CONSENT_PAYLOAD_MALFORMED", ("consent_payload",), []),
        ("CONSENT_PAYLOAD_HASH_WRONG", ("consent_payload_sha256",), "0" * 64),
        ("CONSENT_PAYLOAD_HASH_MISSING", ("consent_payload_sha256",), None),
        ("CONSENT_EXPECTED_SESSION_WRONG", ("expected_session_id",), "wrong-session"),
        ("CONSENT_EXPECTED_RESET_WRONG", ("expected_reset_id",), "wrong-reset"),
        ("CONSENT_EXPECTED_ORDINAL_WRONG", ("expected_ordinal",), 2),
        ("CONSENT_CURRENT_AUTH_HASH_WRONG", ("current_whole_window_authorization_sha256",), "7" * 64),
        ("CONSENT_CURRENT_AUTH_HASH_MISSING", ("current_whole_window_authorization_sha256",), None),
        ("CONSENT_CURRENT_SAFETY_HASH_WRONG", ("current_fresh_safety_snapshot_sha256",), "8" * 64),
        ("CONSENT_CURRENT_SAFETY_HASH_MISSING", ("current_fresh_safety_snapshot_sha256",), None),
        ("CONSENT_OBSERVED_BEFORE", ("observed_monotonic_ns",), 2_999_999),
        ("CONSENT_OBSERVED_EXPIRED", ("observed_monotonic_ns",), 3_010_000),
        ("CONSENT_OBSERVED_MALFORMED", ("observed_monotonic_ns",), None),
        ("CONSENT_ALREADY_CONSUMED", ("consent_consumed",), True),
        ("CONSENT_CONSUMED_INDETERMINATE", ("consent_consumed",), None),
        ("CONSENT_REUSED", ("consent_reused",), True),
        ("CONSENT_REUSE_INDETERMINATE", ("consent_reused",), None),
        ("CONSENT_GATE_CHANGED", ("any_safety_gate_changed_after_consent",), True),
        ("CONSENT_GATE_CHANGE_INDETERMINATE", ("any_safety_gate_changed_after_consent",), None),
        ("CONSENT_SAFETY_GENERATION_MISMATCH", ("current_safety_snapshot_generation",), 2),
        ("CONSENT_SAFETY_GENERATION_MISSING", ("current_safety_snapshot_generation",), None),
        ("CONSENT_ATTEMPT_AUTHORIZED", ("attempt_authorized",), True),
        ("CONSENT_ATTEMPT_AUTH_INDETERMINATE", ("attempt_authorized",), None),
        ("CONSENT_START_REQUESTED", ("start_requested",), True),
        ("CONSENT_START_INDETERMINATE", ("start_requested",), None),
    ]
    for fixture_id, path, replacement in consent_top:
        add(fixture_id, "PER_ATTEMPT_CONSENT", "validate_per_attempt_consent_sample", set_nested(consent, path, replacement))

    consent_payload_mutations = [
        ("CONSENT_SESSION_WRONG", "session_id", "wrong-session"),
        ("CONSENT_SESSION_MISSING", "session_id", None),
        ("CONSENT_RESET_WRONG", "independent_reset_instance_id", "wrong-reset"),
        ("CONSENT_RESET_MISSING", "independent_reset_instance_id", None),
        ("CONSENT_ORDINAL_ZERO", "campaign_ordinal", 0),
        ("CONSENT_ORDINAL_ELEVEN", "campaign_ordinal", 11),
        ("CONSENT_WINDOW_HASH_WRONG", "whole_window_authorization_sha256", "9" * 64),
        ("CONSENT_WINDOW_HASH_MISSING", "whole_window_authorization_sha256", None),
        ("CONSENT_SAFETY_HASH_WRONG", "fresh_physical_safety_snapshot_sha256", "a" * 64),
        ("CONSENT_SAFETY_HASH_MISSING", "fresh_physical_safety_snapshot_sha256", None),
        ("CONSENT_ISSUED_NEGATIVE", "issued_monotonic_ns", -1),
        ("CONSENT_ISSUED_MALFORMED", "issued_monotonic_ns", "3000000"),
        ("CONSENT_EXPIRY_EQUAL", "expires_monotonic_ns", 3_000_000),
        ("CONSENT_EXPIRY_BEFORE", "expires_monotonic_ns", 2_999_999),
        ("CONSENT_EXPIRY_MALFORMED", "expires_monotonic_ns", None),
        ("CONSENT_ONE_TIME_FALSE", "one_time_use", False),
        ("CONSENT_ONE_TIME_INDETERMINATE", "one_time_use", None),
    ]
    for fixture_id, key, replacement in consent_payload_mutations:
        changed = set_nested(consent, ("consent_payload", key), replacement)
        changed = refresh_hash(changed, "consent_payload", "consent_payload_sha256")
        add(fixture_id, "PER_ATTEMPT_CONSENT", "validate_per_attempt_consent_sample", changed)

    safety = samples["safety"]
    safety_top = [
        ("SAFETY_SAMPLE_CLASS", ("sample_class",), "WRONG"),
        ("SAFETY_SYNTHETIC_FALSE", ("synthetic_fixture_only",), False),
        ("SAFETY_SYNTHETIC_INDETERMINATE", ("synthetic_fixture_only",), None),
        ("SAFETY_REAL_ARTIFACT_TRUE", ("real_safety_attestation_created",), True),
        ("SAFETY_REAL_ARTIFACT_INDETERMINATE", ("real_safety_attestation_created",), None),
        ("SAFETY_EVIDENCE_CLASS_WRONG", ("evidence_class",), "FUTURE_EXECUTION_EVIDENCE"),
        ("SAFETY_HISTORICAL_LABEL_MISSING", ("historical_observation_label",), None),
        ("SAFETY_READINESS_ASSERTED", ("physical_readiness_assessed",), True),
        ("SAFETY_READINESS_INDETERMINATE", ("physical_readiness_assessed",), None),
        ("SAFETY_PAYLOAD_MISSING", ("snapshot_payload",), None),
        ("SAFETY_PAYLOAD_MALFORMED", ("snapshot_payload",), []),
        ("SAFETY_PAYLOAD_HASH_WRONG", ("snapshot_payload_sha256",), "0" * 64),
        ("SAFETY_PAYLOAD_HASH_MISSING", ("snapshot_payload_sha256",), None),
        ("SAFETY_EXPECTED_SESSION_WRONG", ("expected_session_id",), "wrong-session"),
        ("SAFETY_EXPECTED_RESET_WRONG", ("expected_reset_id",), "wrong-reset"),
        ("SAFETY_EXPECTED_ORDINAL_WRONG", ("expected_ordinal",), 2),
        ("SAFETY_OBSERVED_BEFORE", ("observed_monotonic_ns",), 999_999),
        ("SAFETY_OBSERVED_EXPIRED", ("observed_monotonic_ns",), 1_100_000),
        ("SAFETY_OBSERVED_MALFORMED", ("observed_monotonic_ns",), None),
        ("SAFETY_SNAPSHOT_CONSUMED", ("snapshot_consumed",), True),
        ("SAFETY_SNAPSHOT_CONSUMED_INDETERMINATE", ("snapshot_consumed",), None),
    ]
    for fixture_id, path, replacement in safety_top:
        add(fixture_id, "FRESH_SAFETY", "validate_fresh_safety_snapshot_sample", set_nested(safety, path, replacement))

    safety_payload_mutations = [
        ("SAFETY_WINDOW_WRONG", "window_number", 2),
        ("SAFETY_WINDOW_MISSING", "window_number", None),
        ("SAFETY_ORDINAL_ZERO", "campaign_ordinal", 0),
        ("SAFETY_ORDINAL_ELEVEN", "campaign_ordinal", 11),
        ("SAFETY_SESSION_WRONG", "session_id", "wrong-session"),
        ("SAFETY_SESSION_MISSING", "session_id", None),
        ("SAFETY_RESET_WRONG", "independent_reset_instance_id", "wrong-reset"),
        ("SAFETY_RESET_MISSING", "independent_reset_instance_id", None),
        ("SAFETY_CAPTURE_NEGATIVE", "captured_monotonic_ns", -1),
        ("SAFETY_CAPTURE_MALFORMED", "captured_monotonic_ns", "1000000"),
        ("SAFETY_EXPIRY_EQUAL", "expires_monotonic_ns", 1_000_000),
        ("SAFETY_EXPIRY_BEFORE", "expires_monotonic_ns", 999_999),
        ("SAFETY_EXPIRY_MALFORMED", "expires_monotonic_ns", None),
        ("SAFETY_MINER_HASH_WRONG", "approved_miner_sha256", "b" * 64),
        ("SAFETY_MINER_HASH_MISSING", "approved_miner_sha256", None),
    ]
    for field, expected, _ in SAFETY_EXPECTATIONS:
        wrong = not expected
        safety_payload_mutations.append((f"SAFETY_FIELD_{field.upper()}_WRONG", field, wrong))
        safety_payload_mutations.append((f"SAFETY_FIELD_{field.upper()}_INDETERMINATE", field, None))
    for fixture_id, key, replacement in safety_payload_mutations:
        changed = set_nested(safety, ("snapshot_payload", key), replacement)
        changed = refresh_hash(changed, "snapshot_payload", "snapshot_payload_sha256")
        add(fixture_id, "FRESH_SAFETY", "validate_fresh_safety_snapshot_sample", changed)

    for action in sorted(
        {
            "AUTHORIZE_WINDOW_01_EXECUTION",
            "AUTHORIZE_INDIVIDUAL_ATTEMPT",
            "CONSUME_AUTHORIZATION",
            "CONSUME_IDENTITY",
            "PLANNED_TO_STARTED",
            "CREATE_CAMPAIGN_OUTPUT_ROOT",
            "CREATE_ATTEMPT_DIRECTORY",
            "CREATE_ATTEMPT_START_PHRASE",
            "CREATE_EXECUTION_PHRASE",
            "AUTO_START_ORDINAL_1",
            "AUTO_START_NEXT_ATTEMPT",
            "RETRY",
            "RESUME",
            "REPLACE_IDENTITY",
            "REUSE_IDENTITY",
            "CONTINUE_AFTER_INTERRUPTION",
            "CONTINUE_AFTER_OUTCOME_INSPECTION",
            "OPTIONAL_STOPPING",
            "TRANSITION_TO_WINDOW_02",
            "LAUNCH_MINER",
            "CONTACT_POOL",
            "START_LIVE",
            "INSPECT_OUTCOME",
            "COMPUTE_SCIENTIFIC_ENDPOINT",
        }
    ):
        changed = set_nested(samples["execution"], ("action",), action)
        add(f"ACTION_{action}", "EXECUTION_BLOCK", "validate_execution_block", changed)
    execution_mutations = [
        ("ACTION_SAMPLE_CLASS_WRONG", "sample_class", "WRONG"),
        ("ACTION_SYNTHETIC_FALSE", "synthetic_fixture_only", False),
        ("ACTION_UNKNOWN", "action", "UNDECLARED_ACTION"),
        ("ACTION_EXECUTION_DELTA", "execution_count_delta", 1),
        ("ACTION_AUTHORIZATION_DELTA", "authorization_consumption_delta", 1),
        ("ACTION_IDENTITY_DELTA", "identity_consumption_delta", 1),
    ]
    for fixture_id, key, replacement in execution_mutations:
        add(fixture_id, "EXECUTION_BLOCK", "validate_execution_block", set_nested(samples["execution"], (key,), replacement))

    path_mutations = [
        ("PATH_SAMPLE_CLASS_WRONG", "sample_class", "WRONG"),
        ("PATH_SYNTHETIC_FALSE", "synthetic_fixture_only", False),
        ("PATH_MISSING", "relative_path", None),
        ("PATH_EMPTY", "relative_path", ""),
        ("PATH_WINDOWS_ABSOLUTE", "relative_path", "C:/campaign/output.json"),
        ("PATH_POSIX_ABSOLUTE", "relative_path", "/campaign/output.json"),
        ("PATH_PARENT_TRAVERSAL", "relative_path", "fixtures/../campaign/output.json"),
        ("PATH_BACKSLASH", "relative_path", "fixtures\\synthetic.json"),
        ("PATH_DRIVE_COLON", "relative_path", "C:relative.json"),
        ("PATH_SYMLINK", "symlink_component_present", True),
        ("PATH_REPARSE", "reparse_component_present", True),
        ("PATH_TARGET_CLASS", "target_class", "CAMPAIGN_OUTPUT_ROOT"),
        ("PATH_CREATION_REQUEST", "create_path_requested", True),
    ]
    for fixture_id, key, replacement in path_mutations:
        add(fixture_id, "PATH_CONFINEMENT", "validate_path_confinement", set_nested(samples["path"], (key,), replacement))

    secret_mutations = [
        ("SECRET_SAMPLE_CLASS_WRONG", "sample_class", "WRONG"),
        ("SECRET_SYNTHETIC_FALSE", "synthetic_fixture_only", False),
        ("SECRET_FINDING", "high_confidence_secret_findings", 1),
        ("SECRET_FINDING_INDETERMINATE", "high_confidence_secret_findings", None),
        ("SECRET_CREDENTIAL", "credential_material_present", True),
        ("SECRET_PRIVATE_KEY", "private_key_material_present", True),
        ("SECRET_PERSONAL_DATA", "unrelated_personal_data_present", True),
    ]
    for fixture_id, key, replacement in secret_mutations:
        add(fixture_id, "SECRET_SCAN", "validate_secret_scan_sample", set_nested(samples["secret"], (key,), replacement))

    add(
        "UNKNOWN_VALIDATOR_FAIL_CLOSED",
        "UNKNOWN_VALIDATOR",
        "validator_that_does_not_exist",
        {"sample_class": "SYNTHETIC_DRY_RUN_UNKNOWN_VALIDATOR"},
    )
    return specs


def execute_fixtures(specs: list[dict[str, Any]], validator_hash: str) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    fixture_ids: set[str] = set()
    validator_input_pairs: set[tuple[str, str]] = set()
    for sequence, spec in enumerate(specs, start=1):
        fixture_id = spec["fixture_id"]
        if fixture_id in fixture_ids:
            raise RuntimeError(f"DUPLICATE_FIXTURE_ID:{fixture_id}")
        fixture_ids.add(fixture_id)
        input_sha256 = sha256_bytes(canonical_bytes(spec["input"]))
        pair = (spec["validator_callable"], input_sha256)
        if pair in validator_input_pairs:
            raise RuntimeError(f"DUPLICATE_VALIDATOR_INPUT_PAIR:{fixture_id}")
        validator_input_pairs.add(pair)
        returned = invoke_validator(spec["validator_callable"], spec["input"])
        result = {
            **spec,
            "invocation_sequence": sequence,
            "validator_invoked": True,
            "validator_source_sha256": validator_hash,
            "input_sha256": input_sha256,
            "returned_decision": returned.get("decision"),
            "returned_reason": returned.get("reason"),
            "return_sha256": sha256_bytes(canonical_bytes(returned)),
            "passed": returned.get("decision") == spec["expected_decision"],
            "execution_count_delta": 0,
            "authorization_consumption_delta": 0,
            "identity_consumption_delta": 0,
        }
        results.append(result)
    return results


def verify_positive_controls(samples: dict[str, Any]) -> list[dict[str, Any]]:
    controls = [
        ("WHOLE_WINDOW_AUTHORIZATION", "validate_whole_window_authorization_sample", samples["authorization"]),
        ("PER_ATTEMPT_CONSENT", "validate_per_attempt_consent_sample", samples["consent"]),
        ("FRESH_SAFETY", "validate_fresh_safety_snapshot_sample", samples["safety"]),
        ("EXECUTION_BLOCK", "validate_execution_block", samples["execution"]),
        ("PATH_CONFINEMENT", "validate_path_confinement", samples["path"]),
        ("SECRET_SCAN", "validate_secret_scan_sample", samples["secret"]),
    ]
    results = []
    for name, validator, value in controls:
        returned = invoke_validator(validator, value)
        if returned.get("decision") != "ALLOW_DRY_RUN_VALIDATION_ONLY":
            raise RuntimeError(f"POSITIVE_CONTROL_FAILED:{name}:{returned}")
        results.append(
            {
                "control_id": name,
                "validator_callable": validator,
                "input_sha256": sha256_bytes(canonical_bytes(value)),
                "returned_decision": returned["decision"],
                "returned_reason": returned["reason"],
                "return_sha256": sha256_bytes(canonical_bytes(returned)),
                "execution_count_delta": 0,
                "authorization_consumption_delta": 0,
                "identity_consumption_delta": 0,
                "passed": True,
            }
        )
    return results


def role_for(relative: str) -> str:
    if relative.startswith("independent_audit/"):
        return "BYTE_IDENTICAL_INDEPENDENT_AUDIT"
    if relative.startswith("predecessor_bindings/"):
        return "BYTE_IDENTICAL_PREDECESSOR_BINDING"
    if relative.startswith("src/"):
        return "PURE_NON_EXECUTING_VALIDATOR_SOURCE"
    if relative.startswith("tooling/"):
        return "DETERMINISTIC_PACKAGE_BUILD_AND_VALIDATION_TOOLING"
    if relative == "README.md":
        return "OPERATOR_README"
    if "FIXTURES" in relative:
        return "EXECUTED_SYNTHETIC_FIXTURE_LEDGER"
    if "VALIDATION_REPORT" in relative:
        return "DRY_RUN_VALIDATION_REPORT"
    if "SECURITY" in relative:
        return "SECURITY_AND_PRIVACY_REPORT"
    if "CONTRACT" in relative:
        return "DRY_RUN_CONTRACT"
    return "DRY_RUN_PACKAGE_ARTIFACT"


def build_zip(zip_path: Path, records: list[dict[str, Any]]) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
            info = zipfile.ZipInfo(record["relative_path"], (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            source = ROOT / PurePosixPath(record["relative_path"])
            archive.writestr(
                info,
                source.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )


def verify_zip(zip_path: Path, expected_records: list[dict[str, Any]]) -> dict[str, Any]:
    workspace = ROOT / ".zip_verification_workspace"
    if workspace.exists():
        raise RuntimeError("ZIP_VERIFICATION_WORKSPACE_PREEXISTS")
    expected = {
        record["relative_path"]: (record["size_bytes"], record["sha256"])
        for record in expected_records
    }
    workspace.mkdir()
    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos]
            if len(names) != len(set(names)) or set(names) != set(expected):
                raise RuntimeError("AUDIT_ZIP_INVENTORY_MISMATCH")
            if archive.testzip() is not None:
                raise RuntimeError("AUDIT_ZIP_CRC_FAILURE")
            for info in infos:
                path = PurePosixPath(info.filename)
                if path.is_absolute() or ".." in path.parts or "\\" in info.filename:
                    raise RuntimeError("AUDIT_ZIP_UNSAFE_PATH")
                if info.flag_bits & 1:
                    raise RuntimeError("AUDIT_ZIP_ENCRYPTED_MEMBER")
                if ((info.external_attr >> 16) & 0o170000) == stat.S_IFLNK:
                    raise RuntimeError("AUDIT_ZIP_SYMLINK_MEMBER")
                target = workspace / path
                target.parent.mkdir(parents=True, exist_ok=True)
                data = archive.read(info.filename)
                target.write_bytes(data)
                if (len(data), sha256_bytes(data)) != expected[info.filename]:
                    raise RuntimeError("AUDIT_ZIP_MEMBER_HASH_MISMATCH")
        extracted = inventory(workspace)
        if len(extracted) != len(expected):
            raise RuntimeError("AUDIT_ZIP_EXTRACTION_COUNT_MISMATCH")
        for record in extracted:
            if expected.get(record["relative_path"]) != (
                record["size_bytes"],
                record["sha256"],
            ):
                raise RuntimeError("AUDIT_ZIP_EXTRACTED_HASH_MISMATCH")
    finally:
        if workspace.exists():
            if workspace.is_symlink() or workspace.resolve().parent != ROOT.resolve():
                raise RuntimeError("UNSAFE_ZIP_VERIFICATION_WORKSPACE")
            shutil.rmtree(workspace)
    return {
        "status": "PASS",
        "members": len(expected),
        "crc": "PASS",
        "duplicate_members": 0,
        "unsafe_paths": 0,
        "encrypted_entries": 0,
        "symlink_members": 0,
        "workspace_removed": not workspace.exists(),
    }


def main() -> None:
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_ALREADY_EXISTS")
    if any(ROOT.rglob("__pycache__")):
        raise RuntimeError("PYCACHE_FORBIDDEN_IN_PACKAGE")

    freeze_tree_before = payload_root(inventory(FREEZE_ROOT))
    repair_tree_before = payload_root(inventory(REPAIR_ROOT))
    predecessor_validation = verify_freeze_package()
    old_hashes = {name: sha256_file(path) for name, path in FILES.items()}

    safe_remove_generated()
    copied_bindings = copy_bindings()
    roster = load_json(FILES["freeze_roster"])
    attempt = roster["attempts"][0]
    samples = make_samples(attempt)

    positive_controls = verify_positive_controls(samples)
    validator_path = ROOT / "src" / "window01_hash_bound_dry_run" / "validators.py"
    builder_path = Path(__file__).resolve()
    verifier_path = ROOT / "tooling" / "independent_verify_window01_hash_bound_dry_run.py"
    validator_hash = sha256_file(validator_path)
    fixtures = execute_fixtures(build_fixture_specs(samples), validator_hash)
    if len(fixtures) < 100:
        raise RuntimeError("EXECUTABLE_NEGATIVE_FIXTURE_COUNT_BELOW_100")
    if any(not item["passed"] or not item["validator_invoked"] for item in fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_NONPASS")
    if len({item["fixture_id"] for item in fixtures}) != len(fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_ID_COLLISION")
    if len({(item["validator_callable"], item["input_sha256"]) for item in fixtures}) != len(fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_INPUT_COLLISION")
    if sum(item["execution_count_delta"] for item in fixtures) != 0:
        raise RuntimeError("FIXTURE_EXECUTION_OCCURRED")
    if sum(item["authorization_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("FIXTURE_AUTHORIZATION_CONSUMPTION_OCCURRED")
    if sum(item["identity_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("FIXTURE_IDENTITY_CONSUMPTION_OCCURRED")

    source_reports = [
        verify_source_ast(validator_path, validator=True),
        verify_source_ast(builder_path, validator=False),
        verify_source_ast(verifier_path, validator=False),
    ]

    binding_receipt = {
        "schema": f"{SCHEMA_PREFIX}/binding-receipt/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "independent_authorization_safety_freeze_audit_ingested": True,
        "attachment_bytes_locally_mounted": True,
        "local_authorization_safety_freeze_byte_revalidation": "PASS",
        "independent_audit_json_sha256": EXPECTED["current_audit_json"],
        "independent_audit_text_sha256": EXPECTED["current_audit_text"],
        "freeze_payload_root_sha256": FREEZE_PAYLOAD_ROOT_SHA256,
        "freeze_manifest_sha256": FREEZE_MANIFEST_SHA256,
        "immutable_roster_sha256": IMMUTABLE_ROSTER_SHA256,
        "freeze_sha256sums_sha256": EXPECTED["freeze_sums"],
        "freeze_archive_sha256": EXPECTED["freeze_archive"],
        "predecessor_nonpass_preserved": True,
        "fixture_coverage_repair_preserved": True,
        "independent_repair_pass_audit_preserved": True,
        "authorization_safety_freeze_preserved": True,
        "predecessor_validation": predecessor_validation,
        "copied_binding_hashes": copied_bindings,
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_ENABLEMENT_BINDING_RECEIPT.json", binding_receipt)

    sample_document = {
        "schema": f"{SCHEMA_PREFIX}/synthetic-samples/v1",
        "created_at_utc": CREATED_AT_UTC,
        "sample_class": "SYNTHETIC_DRY_RUN_ONLY",
        "historical_observation_label": HISTORICAL_OBSERVATION_LABEL,
        "not_future_execution_evidence": True,
        "scientific_weight": 0,
        "execution_authority": False,
        "authorization_consumed": False,
        "identity_consumed": False,
        "attempt_start_phrase_created": False,
        "samples": samples,
        "positive_controls": positive_controls,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_SYNTHETIC_DRY_RUN_SAMPLES.json", sample_document)

    contracts = {
        "A18_44_V0_1_WINDOW_01_WHOLE_WINDOW_AUTHORIZATION_VALIDATOR_CONTRACT.json": {
            "schema": f"{SCHEMA_PREFIX}/whole-window-authorization-contract/v1",
            "created_at_utc": CREATED_AT_UTC,
            "status": "PASS",
            "synthetic_validation_only": True,
            "real_authorization_created": False,
            "execution_authority_present": False,
            "required_exact_bindings": [
                "freeze_payload_root_sha256",
                "freeze_manifest_sha256",
                "immutable_roster_sha256",
                "window_number=1",
                "ordinals=1..10",
                "issued_monotonic_ns",
                "expires_monotonic_ns",
                "synthetic_operator_authorization_utf8_and_sha256",
                "fresh_pre_authorization_safety_snapshot_sha256",
            ],
            "historical_probe_reuse_allowed": False,
        },
        "A18_44_V0_1_WINDOW_01_PER_ATTEMPT_CONSENT_VALIDATOR_CONTRACT.json": {
            "schema": f"{SCHEMA_PREFIX}/per-attempt-consent-contract/v1",
            "created_at_utc": CREATED_AT_UTC,
            "status": "PASS",
            "synthetic_validation_only": True,
            "real_consent_created": False,
            "consent_is_execution_authority": False,
            "separate_fresh_consent_before_every_attempt": True,
            "one_time_use": True,
            "automatic_invalidation_after_gate_change": True,
            "required_exact_bindings": [
                "session_id",
                "independent_reset_instance_id",
                "campaign_ordinal",
                "current_whole_window_authorization_sha256",
                "current_fresh_physical_safety_snapshot_sha256",
            ],
        },
        "A18_44_V0_1_WINDOW_01_FRESH_SAFETY_VALIDATOR_CONTRACT.json": {
            "schema": f"{SCHEMA_PREFIX}/fresh-safety-contract/v1",
            "created_at_utc": CREATED_AT_UTC,
            "status": "PASS",
            "synthetic_validation_only": True,
            "real_safety_attestation_created": False,
            "physical_readiness_assessed": False,
            "historical_and_current_observation_label": HISTORICAL_OBSERVATION_LABEL,
            "snapshot_reuse_across_attempts_allowed": False,
            "false_or_indeterminate_decision": "REJECT_AND_STOP_BEFORE_ATTEMPT",
            "required_fields": [field for field, _, _ in SAFETY_EXPECTATIONS],
            "approved_miner_sha256": APPROVED_MINER_SHA256,
        },
        "A18_44_V0_1_WINDOW_01_EXECUTION_BLOCK_VALIDATOR_CONTRACT.json": {
            "schema": f"{SCHEMA_PREFIX}/execution-block-contract/v1",
            "created_at_utc": CREATED_AT_UTC,
            "status": "PASS",
            "dry_run_only": True,
            "window_01_execution_allowed": False,
            "window_01_execution_authorized": False,
            "window_01_attempts_authorized": 0,
            "window_01_attempts_executed": "0/10",
            "campaign_attempts_executed": "0/360",
            "campaign_identities_consumed": 0,
            "campaign_output_root_created": False,
            "attempt_start_phrase_created": False,
            "automatic_ordinal_1_start_allowed": False,
            "automatic_next_attempt_allowed": False,
            "retry_resume_replacement_or_reuse_allowed": False,
            "window_02_transition_allowed": False,
            "outcome_inspection_allowed": False,
            "scientific_endpoint_computation_allowed": False,
        },
    }
    for filename, document in contracts.items():
        write_json(ROOT / filename, document)

    fixture_document = {
        "schema": f"{SCHEMA_PREFIX}/executable-negative-fixtures/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "fixtures": fixtures,
        "executable_negative_fixtures": len(fixtures),
        "declaration_only_fixtures": 0,
        "passed": len(fixtures),
        "total": len(fixtures),
        "unique_fixture_ids": len({item["fixture_id"] for item in fixtures}),
        "unique_validator_input_pairs": len(
            {(item["validator_callable"], item["input_sha256"]) for item in fixtures}
        ),
        "fixture_execution_count": 0,
        "fixture_authorization_consumption_count": 0,
        "fixture_identity_consumption_count": 0,
        "validator_source_sha256": validator_hash,
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_EXECUTABLE_NEGATIVE_FIXTURES.json", fixture_document)

    package_secret_findings = 0
    # Split scanner signatures so the scanner source does not match itself.
    high_confidence_patterns = (
        b"-----BEGIN " + b"PRIVATE KEY-----",
        b"-----BEGIN OPENSSH " + b"PRIVATE KEY-----",
        b"AK" + b"IA",
        b"gh" + b"p_",
    )
    text_scan_paths = sorted(
        (
            path
            for path in ROOT.rglob("*")
            if path.is_file() and path.suffix.lower() in {".json", ".txt", ".md", ".py"}
        ),
        key=lambda path: path.relative_to(ROOT).as_posix().encode("utf-8"),
    )
    for path in text_scan_paths:
        content = path.read_bytes()
        package_secret_findings += sum(content.count(pattern) for pattern in high_confidence_patterns)
    if package_secret_findings:
        raise RuntimeError("HIGH_CONFIDENCE_SECRET_FINDING")
    security_report = {
        "schema": f"{SCHEMA_PREFIX}/security-and-privacy-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "source_reports": source_reports,
        "network_capable_imports": 0,
        "subprocess_calls": 0,
        "process_or_miner_launch_calls": 0,
        "validator_file_write_calls": 0,
        "text_files_scanned": len(text_scan_paths),
        "high_confidence_secret_findings": 0,
        "credentials_copied": False,
        "miner_binary_copied": False,
        "campaign_output_root_created": False,
        "attempt_directory_created": False,
        "attempt_start_or_execution_phrase_created": False,
        "protected_nas_services_touched": False,
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_SECURITY_AND_PRIVACY_REPORT.json", security_report)

    validation_report = {
        "schema": f"{SCHEMA_PREFIX}/validation-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "first_blocking_invariant": "NONE",
        "independent_authorization_safety_freeze_audit": "PASS",
        "independent_authorization_safety_freeze_audit_ingested": True,
        "attachment_bytes_locally_mounted": True,
        "local_authorization_safety_freeze_byte_revalidation": "PASS",
        "freeze_bindings": "PASS",
        "positive_controls": f"{len(positive_controls)}/{len(positive_controls)}",
        "executable_negative_fixtures": len(fixtures),
        "declaration_only_fixtures": 0,
        "negative_fixtures": f"{len(fixtures)}/{len(fixtures)}",
        "unique_fixture_ids": f"{len(fixtures)}/{len(fixtures)}",
        "input_hashes_reproduced": f"{len(fixtures)}/{len(fixtures)}",
        "return_hashes_reproduced": f"{len(fixtures)}/{len(fixtures)}",
        "fixture_execution_count": 0,
        "fixture_authorization_consumption_count": 0,
        "fixture_identity_consumption_count": 0,
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_authorized": 0,
        "window_01_attempts_executed": "0/10",
        "campaign_execution_authorized": False,
        "authorization_consumed": False,
        "campaign_attempts_authorized": 0,
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "pool_contacted": False,
        "miner_launched": False,
        "live_started": False,
        "attempt_start_phrase_created": False,
        "historical_observation_label": HISTORICAL_OBSERVATION_LABEL,
        "exact_next_allowed_stage": NEXT_STAGE,
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_VALIDATION_REPORT.json", validation_report)

    readme = """# JANUS A18.44 V0.1 Window 01 Hash-Bound Dry Run

This additive package validates only synthetic, non-executing bindings for a
future Window 01 authorization, per-attempt consent, and fresh physical-safety
snapshot. It creates no real authorization or consent and contains no execution
phrase. It cannot start ordinal 1, launch a miner, contact a pool, create the
campaign output root, consume an identity, inspect an outcome, or compute a
scientific endpoint.

All environment observations in this package are labelled
`NOT_FUTURE_EXECUTION_EVIDENCE` and cannot be reused as future safety evidence.
The next stage requires separate authorization and remains non-executing.
"""
    (ROOT / "README.md").write_bytes(readme.encode("utf-8"))

    payload_exclusions = {
        "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_PACKAGE_MANIFEST.json",
        "SHA256SUMS.txt",
        ZIP_NAME,
    }
    payload_records = inventory(ROOT, payload_exclusions)
    manifest = {
        "schema": f"{SCHEMA_PREFIX}/package-manifest/v1",
        "created_at_utc": CREATED_AT_UTC,
        "artifact_type": "WINDOW_01_HASH_BOUND_ENABLEMENT_AND_DRY_RUN_VALIDATION_PACKAGE",
        "status": "PASS",
        "payload_root_algorithm": "Sort UTF-8 relative paths by bytes; append path, NUL, decimal size, NUL, raw SHA-256, LF; hash with SHA-256.",
        "package_payload_root_sha256": payload_root(payload_records),
        "file_count": len(payload_records),
        "files": [{**item, "role": role_for(item["relative_path"])} for item in payload_records],
        "dry_run_only": True,
        "execution_authorized": False,
        "authorization_consumed": False,
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "attempt_start_phrase_created": False,
        "exact_next_allowed_stage": NEXT_STAGE,
    }
    manifest_path = ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_PACKAGE_MANIFEST.json"
    write_json(manifest_path, manifest)

    sums_records = inventory(ROOT, {"SHA256SUMS.txt", ZIP_NAME})
    sums_path = ROOT / "SHA256SUMS.txt"
    sums_path.write_bytes(
        "".join(
            f"{item['sha256']}  {item['relative_path']}\n" for item in sums_records
        ).encode("utf-8")
    )
    passed_sums, total_sums = verify_sums(ROOT, sums_path)
    if passed_sums != total_sums:
        raise RuntimeError("PACKAGE_SHA256SUMS_MISMATCH")

    strict_json_files = sorted(ROOT.rglob("*.json"))
    for path in strict_json_files:
        load_json(path)

    archive_records = inventory(ROOT, {ZIP_NAME})
    zip_path = ROOT / ZIP_NAME
    build_zip(zip_path, archive_records)
    zip_result = verify_zip(zip_path, archive_records)

    if payload_root(inventory(FREEZE_ROOT)) != freeze_tree_before:
        raise RuntimeError("SEALED_FREEZE_PACKAGE_MODIFIED")
    if payload_root(inventory(REPAIR_ROOT)) != repair_tree_before:
        raise RuntimeError("SEALED_REPAIR_PACKAGE_MODIFIED")
    if any(sha256_file(path) != old_hashes[name] for name, path in FILES.items()):
        raise RuntimeError("SEALED_PREDECESSOR_FILE_MODIFIED")
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_CREATED")
    if any(ROOT.rglob("__pycache__")):
        raise RuntimeError("PYCACHE_CREATED")

    result = {
        "status": "PASS",
        "independent_authorization_safety_freeze_audit": "PASS",
        "independent_authorization_safety_freeze_audit_ingested": True,
        "attachment_bytes_locally_mounted": True,
        "local_authorization_safety_freeze_byte_revalidation": "PASS",
        "executable_negative_fixtures": len(fixtures),
        "declaration_only_fixtures": 0,
        "negative_fixtures": f"{len(fixtures)}/{len(fixtures)}",
        "checksums": f"{passed_sums}/{total_sums}",
        "strict_json": f"{len(strict_json_files)}/{len(strict_json_files)}",
        "package_payload_root_sha256": manifest["package_payload_root_sha256"],
        "package_manifest_sha256": sha256_file(manifest_path),
        "validation_report_sha256": sha256_file(
            ROOT / "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_VALIDATION_REPORT.json"
        ),
        "sha256sums_sha256": sha256_file(sums_path),
        "audit_export_zip_sha256": sha256_file(zip_path),
        "audit_export_zip_size_bytes": zip_path.stat().st_size,
        "audit_export_zip_path": str(zip_path),
        "archive": zip_result,
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_authorized": 0,
        "window_01_attempts_executed": "0/10",
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "attempt_start_phrase_created": False,
        "first_blocking_invariant": "NONE",
        "exact_next_allowed_stage": NEXT_STAGE,
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
