"""Read-only independent verifier for the Window 01 dry-run package."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import stat
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
I0_ROOT = ROOT.parent
ZIP_NAME = "JANUS_A18_44_V0_1_WINDOW_01_AUTHORIZATION_SAFETY_HASH_BOUND_DRY_RUN_AUDIT_EXPORT.zip"
MANIFEST_NAME = "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_PACKAGE_MANIFEST.json"
FIXTURE_NAME = "A18_44_V0_1_WINDOW_01_EXECUTABLE_NEGATIVE_FIXTURES.json"
SAMPLE_NAME = "A18_44_V0_1_WINDOW_01_SYNTHETIC_DRY_RUN_SAMPLES.json"
VALIDATION_NAME = "A18_44_V0_1_WINDOW_01_HASH_BOUND_DRY_RUN_VALIDATION_REPORT.json"
CAMPAIGN_OUTPUT_ROOT = (
    I0_ROOT / "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_OUTPUT"
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def duplicate_key_guard(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    return json.loads(
        path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key_guard
    )


def inventory(excluded: set[str] | None = None) -> list[dict[str, Any]]:
    excluded = excluded or set()
    records: list[dict[str, Any]] = []
    for path in sorted(
        (candidate for candidate in ROOT.rglob("*") if candidate.is_file()),
        key=lambda candidate: candidate.relative_to(ROOT).as_posix().encode("utf-8"),
    ):
        relative = path.relative_to(ROOT).as_posix()
        if relative in excluded:
            continue
        records.append(
            {
                "relative_path": relative,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return records


def payload_root(records: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
        digest.update(record["relative_path"].encode("utf-8"))
        digest.update(b"\x00")
        digest.update(str(record["size_bytes"]).encode("ascii"))
        digest.update(b"\x00")
        digest.update(bytes.fromhex(record["sha256"]))
        digest.update(b"\n")
    return digest.hexdigest()


def load_validator() -> Any:
    path = ROOT / "src" / "window01_hash_bound_dry_run" / "validators.py"
    spec = importlib.util.spec_from_file_location("dry_run_validators_read_only", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("VALIDATOR_MODULE_LOAD_FAILED")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    manifest_path = ROOT / MANIFEST_NAME
    sums_path = ROOT / "SHA256SUMS.txt"
    archive_path = ROOT / ZIP_NAME
    manifest = load_json(manifest_path)
    validation = load_json(ROOT / VALIDATION_NAME)
    fixture_document = load_json(ROOT / FIXTURE_NAME)
    sample_document = load_json(ROOT / SAMPLE_NAME)

    payload_records = inventory({MANIFEST_NAME, "SHA256SUMS.txt", ZIP_NAME})
    if payload_root(payload_records) != manifest.get("package_payload_root_sha256"):
        raise RuntimeError("PACKAGE_PAYLOAD_ROOT_MISMATCH")
    manifest_index = {
        item["relative_path"]: (item["size_bytes"], item["sha256"])
        for item in manifest.get("files", [])
    }
    if len(manifest_index) != len(payload_records):
        raise RuntimeError("PACKAGE_MANIFEST_COUNT_MISMATCH")
    for record in payload_records:
        if manifest_index.get(record["relative_path"]) != (
            record["size_bytes"],
            record["sha256"],
        ):
            raise RuntimeError("PACKAGE_MANIFEST_MEMBER_MISMATCH")

    checksum_total = checksum_passed = 0
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        checksum_total += 1
        expected, relative = line.split("  ", 1)
        target = ROOT / PurePosixPath(relative)
        if target.is_file() and sha256_file(target) == expected:
            checksum_passed += 1
    if checksum_total != checksum_passed:
        raise RuntimeError("PACKAGE_SHA256SUMS_MISMATCH")

    json_files = sorted(ROOT.rglob("*.json"))
    for path in json_files:
        load_json(path)

    archive_source = {
        item["relative_path"]: (item["size_bytes"], item["sha256"])
        for item in inventory({ZIP_NAME})
    }
    with zipfile.ZipFile(archive_path, "r") as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)) or set(names) != set(archive_source):
            raise RuntimeError("AUDIT_ARCHIVE_INVENTORY_MISMATCH")
        if archive.testzip() is not None:
            raise RuntimeError("AUDIT_ARCHIVE_CRC_FAILURE")
        for info in infos:
            path = PurePosixPath(info.filename)
            if path.is_absolute() or ".." in path.parts or "\\" in info.filename:
                raise RuntimeError("AUDIT_ARCHIVE_UNSAFE_PATH")
            if info.flag_bits & 1:
                raise RuntimeError("AUDIT_ARCHIVE_ENCRYPTED_MEMBER")
            if ((info.external_attr >> 16) & 0o170000) == stat.S_IFLNK:
                raise RuntimeError("AUDIT_ARCHIVE_SYMLINK_MEMBER")
            data = archive.read(info.filename)
            if (len(data), sha256_bytes(data)) != archive_source[info.filename]:
                raise RuntimeError("AUDIT_ARCHIVE_MEMBER_HASH_MISMATCH")

    validator = load_validator()
    fixtures = fixture_document.get("fixtures", [])
    fixture_ids: set[str] = set()
    input_hashes = return_hashes = decisions = 0
    for fixture in fixtures:
        fixture_ids.add(fixture["fixture_id"])
        if sha256_bytes(canonical_bytes(fixture["input"])) != fixture["input_sha256"]:
            raise RuntimeError("FIXTURE_INPUT_HASH_MISMATCH")
        input_hashes += 1
        returned = validator.invoke_validator(
            fixture["validator_callable"], fixture["input"]
        )
        if sha256_bytes(canonical_bytes(returned)) != fixture["return_sha256"]:
            raise RuntimeError("FIXTURE_RETURN_HASH_MISMATCH")
        return_hashes += 1
        if returned.get("decision") != fixture["expected_decision"]:
            raise RuntimeError("FIXTURE_DECISION_MISMATCH")
        decisions += 1
        if (
            fixture["execution_count_delta"] != 0
            or fixture["authorization_consumption_delta"] != 0
            or fixture["identity_consumption_delta"] != 0
        ):
            raise RuntimeError("FIXTURE_SIDE_EFFECT_DELTA_NONZERO")
    if len(fixture_ids) != len(fixtures) or not fixtures:
        raise RuntimeError("FIXTURE_ID_COUNT_MISMATCH")

    for control in sample_document.get("positive_controls", []):
        sample_key = {
            "WHOLE_WINDOW_AUTHORIZATION": "authorization",
            "PER_ATTEMPT_CONSENT": "consent",
            "FRESH_SAFETY": "safety",
            "EXECUTION_BLOCK": "execution",
            "PATH_CONFINEMENT": "path",
            "SECRET_SCAN": "secret",
        }[control["control_id"]]
        returned = validator.invoke_validator(
            control["validator_callable"], sample_document["samples"][sample_key]
        )
        if returned.get("decision") != "ALLOW_DRY_RUN_VALIDATION_ONLY":
            raise RuntimeError("POSITIVE_CONTROL_NONPASS")

    required_false = {
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "campaign_execution_authorized": False,
        "authorization_consumed": False,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "pool_contacted": False,
        "miner_launched": False,
        "live_started": False,
        "attempt_start_phrase_created": False,
    }
    for field, expected in required_false.items():
        if validation.get(field) is not expected:
            raise RuntimeError(f"VALIDATION_STATE_MISMATCH:{field}")
    if validation.get("window_01_attempts_authorized") != 0:
        raise RuntimeError("ATTEMPTS_AUTHORIZED_NONZERO")
    if validation.get("campaign_identities_consumed") != 0:
        raise RuntimeError("IDENTITIES_CONSUMED_NONZERO")
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_EXISTS")

    print(
        json.dumps(
            {
                "status": "PASS",
                "package_payload_root_sha256": manifest[
                    "package_payload_root_sha256"
                ],
                "package_manifest_sha256": sha256_file(manifest_path),
                "validation_report_sha256": sha256_file(ROOT / VALIDATION_NAME),
                "sha256sums_sha256": sha256_file(sums_path),
                "audit_export_zip_sha256": sha256_file(archive_path),
                "archive_members": len(archive_source),
                "checksums": f"{checksum_passed}/{checksum_total}",
                "strict_json": f"{len(json_files)}/{len(json_files)}",
                "executable_negative_fixtures": len(fixtures),
                "declaration_only_fixtures": 0,
                "negative_fixtures": f"{decisions}/{len(fixtures)}",
                "input_hashes_reproduced": f"{input_hashes}/{len(fixtures)}",
                "return_hashes_reproduced": f"{return_hashes}/{len(fixtures)}",
                "fixture_execution_count": 0,
                "fixture_authorization_consumption_count": 0,
                "fixture_identity_consumption_count": 0,
                "campaign_output_root_created": False,
            },
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
