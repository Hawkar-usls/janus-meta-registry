"""Side-effect-free metadata validators for a governance freeze.

The module performs no file writes, process launches, network calls, identity
consumption, authorization consumption, or scientific calculations.
"""

from __future__ import annotations

from typing import Any, Callable, Mapping


Decision = dict[str, Any]
Validator = Callable[[Mapping[str, Any]], Decision]


def _reject(reason: str) -> Decision:
    return {"decision": "REJECT", "reason": reason}


def _allow(reason: str) -> Decision:
    return {"decision": "ALLOW_CONTRACT_VALIDATION_ONLY", "reason": reason}


SAFETY_EXPECTATIONS: tuple[tuple[str, bool, str], ...] = (
    ("power_state_known", True, "POWER_STATE_INDETERMINATE"),
    ("stable_external_power", True, "STABLE_EXTERNAL_POWER_REQUIRED"),
    ("critical_battery_warning", False, "CRITICAL_BATTERY_WARNING"),
    ("pending_restart_or_shutdown", False, "RESTART_OR_SHUTDOWN_PENDING"),
    ("free_space_known", True, "FREE_SPACE_INDETERMINATE"),
    ("free_space_sufficient", True, "FREE_SPACE_INSUFFICIENT"),
    ("all_required_files_fully_local", True, "REQUIRED_FILES_NOT_FULLY_LOCAL"),
    ("files_on_demand_placeholders_absent", True, "FILES_ON_DEMAND_PLACEHOLDER"),
    ("onedrive_sync_paused", True, "ONEDRIVE_SYNC_NOT_PAUSED"),
    ("second_device_writer_absent", True, "SECOND_DEVICE_WRITER_PRESENT"),
    ("second_process_writer_absent", True, "SECOND_PROCESS_WRITER_PRESENT"),
    ("campaign_process_inactive", True, "CAMPAIGN_PROCESS_ACTIVE"),
    ("miner_process_inactive", True, "MINER_PROCESS_ACTIVE"),
    ("approved_miner_hash_exact", True, "APPROVED_MINER_HASH_MISMATCH"),
    ("protected_nas_services_untouched", True, "PROTECTED_NAS_SERVICE_CHANGE"),
)


def validate_fresh_safety_snapshot(data: Mapping[str, Any]) -> Decision:
    if data.get("evidence_class") != "FRESH_ATTEMPT_BOUND_EXECUTION_SAFETY_EVIDENCE":
        return _reject("SAFETY_EVIDENCE_CLASS_INVALID")
    if data.get("historical_observation_label") != "NOT_FUTURE_EXECUTION_EVIDENCE":
        return _reject("HISTORICAL_OBSERVATION_LABEL_MISSING")
    if data.get("window_number") != 1:
        return _reject("SAFETY_WINDOW_MISMATCH")
    ordinal = data.get("campaign_ordinal")
    if not isinstance(ordinal, int) or ordinal < 1 or ordinal > 10:
        return _reject("SAFETY_ORDINAL_OUT_OF_SCOPE")
    if not data.get("session_id"):
        return _reject("SAFETY_SESSION_ID_MISSING")
    if not data.get("independent_reset_instance_id"):
        return _reject("SAFETY_RESET_ID_MISSING")
    if data.get("snapshot_fresh") is not True:
        return _reject("SAFETY_SNAPSHOT_STALE_OR_INDETERMINATE")
    if data.get("snapshot_hash_present") is not True:
        return _reject("SAFETY_SNAPSHOT_HASH_MISSING")
    if data.get("approved_miner_sha256") != (
        "c46feec0dd936a65bb8e6e074aaa952a0cd57b6925cfb4dd37aad2140d22e1d2"
    ):
        return _reject("APPROVED_MINER_BINDING_MISMATCH")
    for field, expected, reason in SAFETY_EXPECTATIONS:
        if data.get(field) is not expected:
            return _reject(reason)
    return _allow("FRESH_SAFETY_SNAPSHOT_CONTRACT_VALID")


def validate_whole_window_authorization(data: Mapping[str, Any]) -> Decision:
    if data.get("future_authorization_artifact_present") is not True:
        return _reject("FUTURE_WINDOW_AUTHORIZATION_MISSING")
    if data.get("window_number") != 1:
        return _reject("WINDOW_AUTHORIZATION_NUMBER_MISMATCH")
    if data.get("first_ordinal") != 1 or data.get("last_ordinal") != 10:
        return _reject("WINDOW_AUTHORIZATION_SCOPE_MISMATCH")
    if data.get("attempt_count") != 10:
        return _reject("WINDOW_AUTHORIZATION_COUNT_MISMATCH")
    if data.get("authorization_hash_present") is not True:
        return _reject("WINDOW_AUTHORIZATION_HASH_MISSING")
    if data.get("authorization_fresh") is not True:
        return _reject("WINDOW_AUTHORIZATION_STALE_OR_INDETERMINATE")
    if data.get("operator_authorization_exact") is not True:
        return _reject("WINDOW_OPERATOR_AUTHORIZATION_NOT_EXACT")
    if data.get("attempt_start_phrase_present") is not False:
        return _reject("ATTEMPT_START_PHRASE_FORBIDDEN")
    if data.get("automatic_ordinal_1_start_allowed") is not False:
        return _reject("AUTOMATIC_ORDINAL_1_START_FORBIDDEN")
    if data.get("automatic_next_attempt_allowed") is not False:
        return _reject("AUTOMATIC_NEXT_ATTEMPT_FORBIDDEN")
    if data.get("attempts_authorized") != 0:
        return _reject("INDIVIDUAL_ATTEMPT_PREAUTHORIZED")
    return _allow("FUTURE_WHOLE_WINDOW_AUTHORIZATION_CONTRACT_VALID")


def validate_per_attempt_consent(data: Mapping[str, Any]) -> Decision:
    if data.get("consent_present") is not True:
        return _reject("IMMEDIATE_CONSENT_MISSING")
    if data.get("consent_fresh") is not True:
        return _reject("IMMEDIATE_CONSENT_STALE_OR_INDETERMINATE")
    if data.get("consent_session_id") != data.get("expected_session_id"):
        return _reject("CONSENT_SESSION_ID_MISMATCH")
    if data.get("consent_reset_id") != data.get("expected_reset_id"):
        return _reject("CONSENT_RESET_ID_MISMATCH")
    if data.get("consent_ordinal") != data.get("expected_ordinal"):
        return _reject("CONSENT_ORDINAL_MISMATCH")
    if data.get("window_authorization_sha256") != data.get(
        "current_window_authorization_sha256"
    ):
        return _reject("CONSENT_WINDOW_AUTHORIZATION_MISMATCH")
    if data.get("safety_snapshot_sha256") != data.get("current_safety_snapshot_sha256"):
        return _reject("CONSENT_SAFETY_SNAPSHOT_MISMATCH")
    if data.get("any_safety_gate_changed_after_consent") is not False:
        return _reject("CONSENT_INVALIDATED_BY_SAFETY_CHANGE")
    if data.get("consent_reused") is not False:
        return _reject("CONSENT_REUSE_FORBIDDEN")
    if data.get("start_requested_by_consent") is not False:
        return _reject("CONSENT_IS_NOT_START_AUTHORITY")
    return _allow("PER_ATTEMPT_CONSENT_CONTRACT_VALID")


FORBIDDEN_ACTIONS = {
    "AUTO_START_ORDINAL_1",
    "AUTO_START_NEXT_ATTEMPT",
    "RETRY",
    "RESUME",
    "REPLACE_IDENTITY",
    "REUSE_IDENTITY",
    "CONTINUE_AFTER_OUTCOME_INSPECTION",
    "OPTIONAL_STOPPING",
    "TRANSITION_TO_WINDOW_02",
    "CREATE_EXECUTION_PHRASE",
    "CREATE_CAMPAIGN_OUTPUT_ROOT",
    "PLANNED_TO_STARTED",
    "AUTHORIZE_INDIVIDUAL_ATTEMPT",
    "CONSUME_AUTHORIZATION",
    "CONSUME_IDENTITY",
    "LAUNCH_MINER",
    "CONTACT_POOL",
    "START_LIVE",
    "COMPUTE_SCIENTIFIC_ENDPOINT",
    "INSPECT_SCIENTIFIC_ENDPOINT",
}


def validate_governance_action(data: Mapping[str, Any]) -> Decision:
    action = data.get("action")
    if action in FORBIDDEN_ACTIONS:
        return _reject(f"GOVERNANCE_ACTION_FORBIDDEN:{action}")
    return _allow("NO_FORBIDDEN_ACTION_REQUESTED")


VALIDATORS: dict[str, Validator] = {
    "validate_fresh_safety_snapshot": validate_fresh_safety_snapshot,
    "validate_whole_window_authorization": validate_whole_window_authorization,
    "validate_per_attempt_consent": validate_per_attempt_consent,
    "validate_governance_action": validate_governance_action,
}


def invoke_validator(name: str, data: Mapping[str, Any]) -> Decision:
    validator = VALIDATORS.get(name)
    if validator is None:
        return _reject("UNKNOWN_VALIDATOR")
    return validator(data)
