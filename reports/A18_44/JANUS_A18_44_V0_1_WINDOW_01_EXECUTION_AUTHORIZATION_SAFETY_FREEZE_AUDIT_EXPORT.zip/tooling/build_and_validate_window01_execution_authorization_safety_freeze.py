"""Build a non-executing Window 01 authorization and safety policy freeze."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
I0_ROOT = ROOT.parent
SRC_ROOT = ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from window01_safety_freeze.validators import (  # noqa: E402
    SAFETY_EXPECTATIONS,
    invoke_validator,
)


CREATED_AT_UTC = "2026-07-17T00:00:00Z"
SCHEMA_PREFIX = "JANUS/A18.44/v0.1/window-01-execution-authorization-safety-freeze"
NEXT_STAGE = (
    "A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_EXECUTION_"
    "AUTHORIZATION_AND_FRESH_PHYSICAL_SAFETY_ATTESTATION_HASH_BOUND_"
    "ENABLEMENT_AND_DRY_RUN_VALIDATION_ONLY"
)
REPAIR_ROOT = I0_ROOT / (
    "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_HASH_BOUND_"
    "EXECUTION_PACKAGE_DRY_RUN_FIXTURE_COVERAGE_REPAIR"
)
PREVIOUS_FREEZE_ROOT = I0_ROOT / (
    "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_"
    "EXECUTION_AUTHORIZATION_FREEZE"
)
CAMPAIGN_OUTPUT_ROOT = I0_ROOT / (
    "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_OUTPUT"
)
DOWNLOADS = Path.home() / "Downloads"
AUDIT_JSON = DOWNLOADS / (
    "JANUS_A18_44_WINDOW_01_FIXTURE_COVERAGE_REPAIR_"
    "INDEPENDENT_AUDIT_RESULT.json"
)
AUDIT_TEXT = DOWNLOADS / (
    "JANUS_A18_44_WINDOW_01_FIXTURE_COVERAGE_REPAIR_"
    "INDEPENDENT_AUDIT_RESULT.txt"
)
ZIP_NAME = (
    "JANUS_A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_"
    "SAFETY_FREEZE_AUDIT_EXPORT.zip"
)

EXPECTED = {
    "audit_json": "a2dc8e788a0e6cecf8685556524ffbe3dde8cc32099440ff2f38f20360bed79d",
    "audit_text": "f738758fc3f2c2b75658f1d1b91148892ffbdeb5112e8a3745ea7b9a7a102791",
    "repair_archive": "d0d58c01580810efbdaa5441edf58f4c6a5a19511c1ea69ed45feed11244d69c",
    "repair_manifest": "649bcec38e1346894a995096edb7991d9251624d20753b4b37e4536f81ea3285",
    "repair_sums": "e2cfdfc54cef616d2ab5bb54590386b07b9326aa37c5c0904f916b90b12b5aee",
    "repair_validation": "589398a280616a6073173f0afdd8ec39551b6cc91a95942f82c10f98f673562b",
    "repair_fixtures": "ba38cdb40238f6f9fceb9ba31a08adef24d9d0a5463f19b30677f3e728486ad1",
    "repair_validator": "2028d5b0738c0df0f7c6c6721d5c8170e6d0f6767c4b329d6cd25ad71561a591",
    "repair_revalidator": "c0f2bd75b363cf40e5f832141fcb23a2af920039638e4cf36e7457e92f425741",
    "repair_payload_root": "00edd648c1b64c29bea7d4113bad373b3f05372ffc8a14eb23494a19fa22b5ab",
    "previous_authorization": "ea5ca1fd73b1f1378a6924a230f8c9b8a15d7bd18b03fe537bfc4521a3347a6d",
    "previous_operational": "a2e868ada0dd1fd26337f0a9621f498bb273ebcd40b0b6149df318fa2e4c04b9",
    "previous_roster": "fc56462e156c9814d433e66a4c761eb7f11444260a14953c19c25669837e0aed",
    "previous_safety": "a1130ed14c986b4870df840d106fe1cf914ac86950fa936aa8e24643fdd0d340",
    "previous_validation": "a3615a11a2a7ed138b120427b5737a17d3da26422e6bbb659d768085eb46edd3",
    "previous_manifest": "7e137f959cf8b2b8db195bc4a9f7952f66b2a1d2d5770be427ef8b8b554d47ae",
    "previous_sums": "4d734dd9ae76b9cf0d5e828464de1c799408f2437ef18c767058d3b3c6838641",
    "previous_builder": "f0f877c1a36e2b33ff5e1afd5f7751d63590ecc074cba4e1e793d5c3ac12c3f2",
    "previous_payload_root": "dd831c888271face8ee7bd99aec03ea19aecf836c8f4c1576ff74cfbe215c433",
}

REPAIR_FILES = {
    "repair_archive": REPAIR_ROOT
    / "JANUS_A18_44_V0_1_WINDOW_01_PACKAGE_DRY_RUN_FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip",
    "repair_manifest": REPAIR_ROOT
    / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json",
    "repair_sums": REPAIR_ROOT / "SHA256SUMS.txt",
    "repair_validation": REPAIR_ROOT
    / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_VALIDATION_REPORT.json",
    "repair_fixtures": REPAIR_ROOT
    / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_NEGATIVE_FIXTURES.json",
    "repair_validator": REPAIR_ROOT / "src" / "window01_fixture_repair" / "validators.py",
    "repair_revalidator": REPAIR_ROOT
    / "tooling"
    / "independent_verify_fixture_coverage_repair.py",
}

PREVIOUS_FILES = {
    "previous_authorization": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_FREEZE.json",
    "previous_operational": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_OPERATIONAL_CONTRACT.json",
    "previous_roster": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_IDENTITY_ROSTER.json",
    "previous_safety": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_SAFETY_GATE_CONTRACT.json",
    "previous_validation": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_VALIDATION_REPORT.json",
    "previous_manifest": PREVIOUS_FREEZE_ROOT
    / "A18_44_V0_1_WINDOW_01_AUTHORIZATION_FREEZE_MANIFEST.json",
    "previous_sums": PREVIOUS_FREEZE_ROOT / "SHA256SUMS.txt",
    "previous_builder": PREVIOUS_FREEZE_ROOT
    / "tooling"
    / "build_and_validate_window_01_authorization_freeze.py",
}

GENERATED = {
    "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_AND_FRESH_SAFETY_ATTESTATION_FREEZE.json",
    "A18_44_V0_1_WINDOW_01_WHOLE_WINDOW_AUTHORIZATION_CONTRACT.json",
    "A18_44_V0_1_WINDOW_01_PER_ATTEMPT_CONSENT_CONTRACT.json",
    "A18_44_V0_1_WINDOW_01_FRESH_PHYSICAL_SAFETY_ATTESTATION_CONTRACT.json",
    "A18_44_V0_1_WINDOW_01_INTERRUPTION_AND_CONTINUATION_POLICY.json",
    "A18_44_V0_1_WINDOW_01_EXECUTION_BLOCK_CONTRACT.json",
    "A18_44_V0_1_WINDOW_01_NEGATIVE_VALIDATION_FIXTURES.json",
    "A18_44_V0_1_WINDOW_01_INDEPENDENT_FIXTURE_REPAIR_AUDIT_INGESTION_RECEIPT.json",
    "A18_44_V0_1_WINDOW_01_SECURITY_AND_BOUNDARY_REPORT.json",
    "A18_44_V0_1_WINDOW_01_FREEZE_VALIDATION_REPORT.json",
    "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_FREEZE_MANIFEST.json",
    "README.md",
    "SHA256SUMS.txt",
    ZIP_NAME,
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def write_json(path: Path, value: Any) -> None:
    path.write_bytes(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        + b"\n"
    )


def duplicate_key_guard(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    return json.loads(
        path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key_guard
    )


def rel(path: Path, root: Path = ROOT) -> str:
    return path.relative_to(root).as_posix()


def inventory(root: Path, excluded: set[str] | None = None) -> list[dict[str, Any]]:
    excluded = excluded or set()
    files = []
    for path in sorted(
        (candidate for candidate in root.rglob("*") if candidate.is_file()),
        key=lambda candidate: candidate.relative_to(root).as_posix().encode("utf-8"),
    ):
        relative = path.relative_to(root).as_posix()
        if relative in excluded:
            continue
        files.append(
            {
                "relative_path": relative,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return files


def payload_root(records: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
        digest.update(record["relative_path"].encode("utf-8"))
        digest.update(b"\x00")
        digest.update(str(record["size_bytes"]).encode("ascii"))
        digest.update(b"\x00")
        digest.update(bytes.fromhex(record["sha256"]))
        digest.update(b"\n")
    return digest.hexdigest()


def verify_sums(root: Path, sums: Path) -> tuple[int, int]:
    passed = 0
    total = 0
    for line in sums.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        total += 1
        expected, relative = line.split("  ", 1)
        target = root / Path(relative)
        if target.is_file() and sha256_file(target) == expected:
            passed += 1
    return passed, total


def clear_generated() -> None:
    for name in GENERATED:
        path = ROOT / name
        if not path.exists():
            continue
        if not path.is_file() or path.is_symlink() or path.resolve().parent != ROOT.resolve():
            raise RuntimeError(f"UNSAFE_GENERATED_ARTIFACT:{name}")
        path.unlink()


def verify_selected(files: dict[str, Path]) -> dict[str, Any]:
    result = {}
    for key, path in files.items():
        if not path.is_file():
            raise RuntimeError(f"PREDECESSOR_FILE_MISSING:{key}")
        observed = sha256_file(path)
        if observed != EXPECTED[key]:
            raise RuntimeError(f"PREDECESSOR_HASH_MISMATCH:{key}")
        result[key] = {"sha256": observed, "size_bytes": path.stat().st_size}
    return result


def verify_audit_attachments() -> dict[str, Any]:
    for path, key in ((AUDIT_JSON, "audit_json"), (AUDIT_TEXT, "audit_text")):
        if not path.is_file() or sha256_file(path) != EXPECTED[key]:
            raise RuntimeError(f"INDEPENDENT_AUDIT_ATTACHMENT_MISMATCH:{key}")
    audit = load_json(AUDIT_JSON)
    text = AUDIT_TEXT.read_text(encoding="utf-8")
    if audit.get("audit_status") != "PASS":
        raise RuntimeError("INDEPENDENT_AUDIT_NOT_PASS")
    if audit.get("first_blocking_invariant") != "NONE":
        raise RuntimeError("INDEPENDENT_AUDIT_BLOCKER_PRESENT")
    required_text = (
        "A18_44_WINDOW_01_FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT=PASS",
        "EXECUTABLE_NEGATIVE_FIXTURES_REEXECUTED=160/160",
        "DECLARATION_ONLY_FIXTURES=0",
        "INPUT_HASHES_REPRODUCED=160/160",
        "RETURN_HASHES_REPRODUCED=160/160",
        "CAMPAIGN_EXECUTED=no",
    )
    if any(value not in text for value in required_text):
        raise RuntimeError("INDEPENDENT_AUDIT_TEXT_INCONSISTENT")
    archive = audit["audited_archive"]
    hashes = audit["strict_parsing_and_hashes"]
    fixture = audit["fixture_reexecution"]
    expected_values = (
        (archive.get("sha256"), EXPECTED["repair_archive"]),
        (archive.get("size_bytes"), 55182),
        (archive.get("members"), 17),
        (archive.get("crc"), "PASS"),
        (hashes.get("strict_json"), "10/10"),
        (hashes.get("sha256sums"), "16/16"),
        (hashes.get("manifest_files"), "15/15"),
        (hashes.get("package_payload_root_sha256"), EXPECTED["repair_payload_root"]),
        (fixture.get("fixtures_reexecuted"), "160/160"),
        (fixture.get("declaration_only_fixtures"), 0),
        (fixture.get("input_hashes_reproduced"), "160/160"),
        (fixture.get("return_hashes_reproduced"), "160/160"),
        (fixture.get("fixture_execution_count"), 0),
        (fixture.get("fixture_identity_consumption_count"), 0),
    )
    if any(observed != expected for observed, expected in expected_values):
        raise RuntimeError("INDEPENDENT_AUDIT_VALUE_MISMATCH")
    return {
        "status": "PASS",
        "json_sha256": EXPECTED["audit_json"],
        "json_size_bytes": AUDIT_JSON.stat().st_size,
        "text_sha256": EXPECTED["audit_text"],
        "text_size_bytes": AUDIT_TEXT.stat().st_size,
        "attachment_bytes_locally_mounted": True,
    }


def load_module(path: Path) -> Any:
    spec = importlib.util.spec_from_file_location("a18_44_repair_validators", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("REPAIR_VALIDATOR_IMPORT_FAILED")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_repair_package() -> dict[str, Any]:
    bindings = verify_selected(REPAIR_FILES)
    manifest = load_json(REPAIR_FILES["repair_manifest"])
    if manifest.get("package_payload_root_sha256") != EXPECTED["repair_payload_root"]:
        raise RuntimeError("REPAIR_PAYLOAD_ROOT_MISMATCH")
    sums_passed, sums_total = verify_sums(REPAIR_ROOT, REPAIR_FILES["repair_sums"])
    if (sums_passed, sums_total) != (16, 16):
        raise RuntimeError("REPAIR_SHA256SUMS_MISMATCH")
    json_files = sorted(REPAIR_ROOT.rglob("*.json"))
    for path in json_files:
        load_json(path)
    if len(json_files) != 10:
        raise RuntimeError("REPAIR_STRICT_JSON_COUNT_MISMATCH")
    fixtures = load_json(REPAIR_FILES["repair_fixtures"])["fixtures"]
    module = load_module(REPAIR_FILES["repair_validator"])
    ids: set[str] = set()
    inputs = 0
    returns = 0
    passed = 0
    for fixture in fixtures:
        ids.add(fixture["fixture_id"])
        if sha256_bytes(canonical_bytes(fixture["input"])) == fixture["input_sha256"]:
            inputs += 1
        returned = module.invoke_validator(fixture["validator_callable"], fixture["input"])
        if sha256_bytes(canonical_bytes(returned)) == fixture["return_sha256"]:
            returns += 1
        if returned.get("decision") == fixture["expected_decision"]:
            passed += 1
    if (len(fixtures), len(ids), inputs, returns, passed) != (160, 160, 160, 160, 160):
        raise RuntimeError("REPAIR_FIXTURE_REEXECUTION_MISMATCH")
    if sum(item["execution_count_delta"] for item in fixtures) != 0:
        raise RuntimeError("REPAIR_FIXTURE_EXECUTION_COUNT_NONZERO")
    if sum(item["identity_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("REPAIR_FIXTURE_IDENTITY_COUNT_NONZERO")
    expected_archive = {
        path.relative_to(REPAIR_ROOT).as_posix(): (path.stat().st_size, sha256_file(path))
        for path in REPAIR_ROOT.rglob("*")
        if path.is_file() and path != REPAIR_FILES["repair_archive"]
    }
    with zipfile.ZipFile(REPAIR_FILES["repair_archive"], "r") as archive:
        names = archive.namelist()
        if len(names) != 17 or len(names) != len(set(names)) or set(names) != set(expected_archive):
            raise RuntimeError("REPAIR_ARCHIVE_MEMBER_SET_MISMATCH")
        if archive.testzip() is not None:
            raise RuntimeError("REPAIR_ARCHIVE_CRC_FAILURE")
        for name in names:
            data = archive.read(name)
            size, digest = expected_archive[name]
            if len(data) != size or sha256_bytes(data) != digest:
                raise RuntimeError(f"REPAIR_ARCHIVE_MEMBER_MISMATCH:{name}")
    return {
        "status": "PASS",
        "bindings": bindings,
        "archive_members": "17/17",
        "strict_json": "10/10",
        "sha256sums": "16/16",
        "manifest_files": "15/15",
        "fixtures_reexecuted": "160/160",
        "unique_fixture_ids": "160/160",
        "input_hashes_reproduced": "160/160",
        "return_hashes_reproduced": "160/160",
        "fixture_execution_count": 0,
        "fixture_identity_consumption_count": 0,
    }


def verify_previous_freeze() -> dict[str, Any]:
    bindings = verify_selected(PREVIOUS_FILES)
    sums_passed, sums_total = verify_sums(PREVIOUS_FREEZE_ROOT, PREVIOUS_FILES["previous_sums"])
    if (sums_passed, sums_total) != (18, 18):
        raise RuntimeError("PREVIOUS_FREEZE_SHA256SUMS_MISMATCH")
    manifest = load_json(PREVIOUS_FILES["previous_manifest"])
    if manifest.get("window_01_freeze_payload_root_sha256") != EXPECTED["previous_payload_root"]:
        raise RuntimeError("PREVIOUS_FREEZE_PAYLOAD_ROOT_MISMATCH")
    roster = load_json(PREVIOUS_FILES["previous_roster"])
    attempts = roster.get("attempts")
    if not isinstance(attempts, list) or len(attempts) != 10:
        raise RuntimeError("PREVIOUS_ROSTER_COUNT_MISMATCH")
    if [item["campaign_attempt_ordinal"] for item in attempts] != list(range(1, 11)):
        raise RuntimeError("PREVIOUS_ROSTER_ORDER_MISMATCH")
    if any(item["identity_consumed"] or item["attempt_started"] or item["attempt_authorized"] for item in attempts):
        raise RuntimeError("PREVIOUS_ROSTER_STATE_NOT_ZERO")
    return {
        "status": "PASS",
        "bindings": bindings,
        "sha256sums": "18/18",
        "payload_root_sha256": EXPECTED["previous_payload_root"],
        "attempts": "10/10",
        "ordinals": "1..10",
        "identities_unconsumed": "10/10",
    }


def baseline_safety(attempt: dict[str, Any]) -> dict[str, Any]:
    data = {
        "evidence_class": "FRESH_ATTEMPT_BOUND_EXECUTION_SAFETY_EVIDENCE",
        "historical_observation_label": "NOT_FUTURE_EXECUTION_EVIDENCE",
        "window_number": 1,
        "campaign_ordinal": attempt["campaign_attempt_ordinal"],
        "session_id": attempt["session_id"],
        "independent_reset_instance_id": attempt["independent_reset_instance_id"],
        "snapshot_fresh": True,
        "snapshot_hash_present": True,
        "approved_miner_sha256": "c46feec0dd936a65bb8e6e074aaa952a0cd57b6925cfb4dd37aad2140d22e1d2",
    }
    data.update({field: expected for field, expected, _ in SAFETY_EXPECTATIONS})
    return data


def baseline_window_authorization() -> dict[str, Any]:
    return {
        "future_authorization_artifact_present": True,
        "window_number": 1,
        "first_ordinal": 1,
        "last_ordinal": 10,
        "attempt_count": 10,
        "authorization_hash_present": True,
        "authorization_fresh": True,
        "operator_authorization_exact": True,
        "attempt_start_phrase_present": False,
        "automatic_ordinal_1_start_allowed": False,
        "automatic_next_attempt_allowed": False,
        "attempts_authorized": 0,
    }


def baseline_consent(attempt: dict[str, Any]) -> dict[str, Any]:
    return {
        "consent_present": True,
        "consent_fresh": True,
        "consent_session_id": attempt["session_id"],
        "expected_session_id": attempt["session_id"],
        "consent_reset_id": attempt["independent_reset_instance_id"],
        "expected_reset_id": attempt["independent_reset_instance_id"],
        "consent_ordinal": attempt["campaign_attempt_ordinal"],
        "expected_ordinal": attempt["campaign_attempt_ordinal"],
        "window_authorization_sha256": "1" * 64,
        "current_window_authorization_sha256": "1" * 64,
        "safety_snapshot_sha256": "2" * 64,
        "current_safety_snapshot_sha256": "2" * 64,
        "any_safety_gate_changed_after_consent": False,
        "consent_reused": False,
        "start_requested_by_consent": False,
    }


def build_fixture_specs(attempt: dict[str, Any]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []

    def add(fixture_id: str, category: str, validator: str, data: dict[str, Any]) -> None:
        specs.append(
            {
                "fixture_id": fixture_id,
                "category": category,
                "validator_callable": validator,
                "input": data,
                "expected_decision": "REJECT",
            }
        )

    for field, expected, _ in SAFETY_EXPECTATIONS:
        wrong = baseline_safety(attempt)
        wrong[field] = not expected
        add(
            f"SAFETY_{field.upper()}_WRONG",
            "FRESH_SAFETY",
            "validate_fresh_safety_snapshot",
            wrong,
        )
        unknown = baseline_safety(attempt)
        unknown[field] = None
        add(
            f"SAFETY_{field.upper()}_INDETERMINATE",
            "FRESH_SAFETY",
            "validate_fresh_safety_snapshot",
            unknown,
        )
    safety_mutations = (
        ("WRONG_EVIDENCE_CLASS", "evidence_class", "NOT_FUTURE_EXECUTION_EVIDENCE"),
        ("MISSING_HISTORY_LABEL", "historical_observation_label", None),
        ("WRONG_WINDOW", "window_number", 2),
        ("WRONG_ORDINAL", "campaign_ordinal", 11),
        ("MISSING_SESSION", "session_id", ""),
        ("MISSING_RESET", "independent_reset_instance_id", ""),
        ("STALE", "snapshot_fresh", False),
        ("MISSING_HASH", "snapshot_hash_present", False),
        ("WRONG_MINER_HASH", "approved_miner_sha256", "0" * 64),
    )
    for label, field, value in safety_mutations:
        data = baseline_safety(attempt)
        data[field] = value
        add(
            f"SAFETY_{label}",
            "FRESH_SAFETY",
            "validate_fresh_safety_snapshot",
            data,
        )

    window_mutations = (
        ("MISSING", "future_authorization_artifact_present", False),
        ("WRONG_WINDOW", "window_number", 2),
        ("WRONG_FIRST", "first_ordinal", 2),
        ("WRONG_LAST", "last_ordinal", 11),
        ("WRONG_COUNT", "attempt_count", 9),
        ("HASH_MISSING", "authorization_hash_present", False),
        ("STALE", "authorization_fresh", False),
        ("NOT_EXACT", "operator_authorization_exact", False),
        ("START_PHRASE_PRESENT", "attempt_start_phrase_present", True),
        ("AUTO_ORDINAL_1", "automatic_ordinal_1_start_allowed", True),
        ("AUTO_NEXT", "automatic_next_attempt_allowed", True),
        ("ATTEMPT_PREAUTHORIZED", "attempts_authorized", 1),
    )
    for label, field, value in window_mutations:
        data = baseline_window_authorization()
        data[field] = value
        add(
            f"WINDOW_AUTH_{label}",
            "WHOLE_WINDOW_AUTHORIZATION",
            "validate_whole_window_authorization",
            data,
        )

    consent_mutations = (
        ("MISSING", "consent_present", False),
        ("STALE", "consent_fresh", False),
        ("WRONG_SESSION", "consent_session_id", "wrong-session"),
        ("WRONG_RESET", "consent_reset_id", "wrong-reset"),
        ("WRONG_ORDINAL", "consent_ordinal", 99),
        ("WRONG_WINDOW_HASH", "window_authorization_sha256", "3" * 64),
        ("WRONG_SAFETY_HASH", "safety_snapshot_sha256", "4" * 64),
        ("GATE_CHANGED", "any_safety_gate_changed_after_consent", True),
        ("REUSED", "consent_reused", True),
        ("START_REQUESTED", "start_requested_by_consent", True),
    )
    for label, field, value in consent_mutations:
        data = baseline_consent(attempt)
        data[field] = value
        add(
            f"CONSENT_{label}",
            "PER_ATTEMPT_CONSENT",
            "validate_per_attempt_consent",
            data,
        )

    forbidden_actions = (
        "AUTO_START_ORDINAL_1",
        "AUTO_START_NEXT_ATTEMPT",
        "RETRY",
        "RESUME",
        "REPLACE_IDENTITY",
        "REUSE_IDENTITY",
        "CONTINUE_AFTER_OUTCOME_INSPECTION",
        "OPTIONAL_STOPPING",
        "TRANSITION_TO_WINDOW_02",
        "CREATE_EXECUTION_PHRASE",
        "CREATE_CAMPAIGN_OUTPUT_ROOT",
        "PLANNED_TO_STARTED",
        "AUTHORIZE_INDIVIDUAL_ATTEMPT",
        "CONSUME_AUTHORIZATION",
        "CONSUME_IDENTITY",
        "LAUNCH_MINER",
        "CONTACT_POOL",
        "START_LIVE",
        "COMPUTE_SCIENTIFIC_ENDPOINT",
        "INSPECT_SCIENTIFIC_ENDPOINT",
    )
    for action in forbidden_actions:
        add(
            f"ACTION_{action}",
            "EXECUTION_BLOCK",
            "validate_governance_action",
            {"action": action},
        )
    return specs


def execute_fixtures(specs: list[dict[str, Any]], validator_hash: str) -> list[dict[str, Any]]:
    results = []
    ids: set[str] = set()
    for sequence, spec in enumerate(specs, start=1):
        if spec["fixture_id"] in ids:
            raise RuntimeError(f"DUPLICATE_FIXTURE_ID:{spec['fixture_id']}")
        ids.add(spec["fixture_id"])
        returned = invoke_validator(spec["validator_callable"], spec["input"])
        result = {
            **spec,
            "invocation_sequence": sequence,
            "validator_invoked": True,
            "validator_source_sha256": validator_hash,
            "input_sha256": sha256_bytes(canonical_bytes(spec["input"])),
            "returned_decision": returned.get("decision"),
            "returned_reason": returned.get("reason"),
            "return_sha256": sha256_bytes(canonical_bytes(returned)),
            "passed": returned.get("decision") == spec["expected_decision"],
            "execution_count_delta": 0,
            "authorization_consumption_delta": 0,
            "identity_consumption_delta": 0,
        }
        results.append(result)
    return results


def copy_bindings() -> None:
    independent = ROOT / "independent_audit"
    predecessor = ROOT / "predecessor_bindings"
    independent.mkdir(parents=True, exist_ok=True)
    predecessor.mkdir(parents=True, exist_ok=True)
    copies = (
        (AUDIT_JSON, independent / AUDIT_JSON.name),
        (AUDIT_TEXT, independent / AUDIT_TEXT.name),
        (REPAIR_FILES["repair_archive"], predecessor / "FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip"),
        (REPAIR_FILES["repair_manifest"], predecessor / "FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json"),
        (REPAIR_FILES["repair_validation"], predecessor / "FIXTURE_COVERAGE_REPAIR_VALIDATION_REPORT.json"),
        (PREVIOUS_FILES["previous_authorization"], predecessor / "PREVIOUS_WINDOW_01_EXECUTION_AUTHORIZATION_FREEZE.json"),
        (PREVIOUS_FILES["previous_roster"], predecessor / "PREVIOUS_WINDOW_01_IDENTITY_ROSTER.json"),
        (PREVIOUS_FILES["previous_safety"], predecessor / "PREVIOUS_WINDOW_01_SAFETY_GATE_CONTRACT.json"),
        (PREVIOUS_FILES["previous_manifest"], predecessor / "PREVIOUS_WINDOW_01_AUTHORIZATION_FREEZE_MANIFEST.json"),
    )
    for source, destination in copies:
        shutil.copyfile(source, destination)
        if sha256_file(source) != sha256_file(destination):
            raise RuntimeError(f"BINDING_COPY_MISMATCH:{destination.name}")


def role_for(relative: str) -> str:
    if relative.startswith("src/"):
        return "PURE_CONTRACT_VALIDATOR_SOURCE"
    if relative.startswith("tooling/"):
        return "BUILD_AND_READ_ONLY_VALIDATION_TOOLING"
    if relative.startswith("independent_audit/"):
        return "BYTE_IDENTICAL_INDEPENDENT_AUDIT"
    if relative.startswith("predecessor_bindings/"):
        return "BYTE_IDENTICAL_PREDECESSOR_BINDING"
    if relative == "README.md":
        return "OPERATOR_README"
    if "NEGATIVE" in relative:
        return "EXECUTED_NEGATIVE_FIXTURE_LEDGER"
    if "VALIDATION_REPORT" in relative:
        return "VALIDATION_REPORT"
    if "CONTRACT" in relative or "POLICY" in relative:
        return "FROZEN_GOVERNANCE_CONTRACT"
    return "FREEZE_ARTIFACT"


def scan_security_and_boundaries() -> dict[str, Any]:
    findings = []
    secret_markers = (
        b"-----BEGIN " + b"PRIVATE KEY-----",
        b'"' + b"password" + b'":"',
        b'"' + b"api_token" + b'":"',
    )
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.name == ZIP_NAME:
            continue
        data = path.read_bytes()
        for marker in secret_markers:
            if marker in data:
                findings.append({"relative_path": rel(path), "finding": "SECRET_PATTERN"})
    generated_text = b"".join(
        path.read_bytes()
        for path in ROOT.iterdir()
        if path.is_file() and path.suffix.lower() in {".json", ".md", ".txt", ".py"}
    )
    start_phrase_prefix = b"APPROVE " + b"JANUS A18.44 V0.1 OFFLINE ACQUISITION CAMPAIGN WINDOW 01"
    execution_phrase_findings = generated_text.count(start_phrase_prefix)
    return {
        "schema": f"{SCHEMA_PREFIX}/security-and-boundary-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "high_confidence_secret_findings": len(findings),
        "secret_findings": findings,
        "attempt_start_phrase_findings": execution_phrase_findings,
        "network_calls": 0,
        "subprocess_calls": 0,
        "miner_launches": 0,
        "pool_contacts": 0,
        "campaign_attempts_executed": 0,
        "campaign_identities_consumed": 0,
        "scientific_endpoints_computed": False,
        "status": "PASS" if not findings and execution_phrase_findings == 0 else "FAIL",
    }


def build_zip(zip_path: Path, records: list[dict[str, Any]]) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for record in records:
            source = ROOT / Path(record["relative_path"])
            info = zipfile.ZipInfo(record["relative_path"], (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_zip(zip_path: Path, expected: list[dict[str, Any]]) -> dict[str, Any]:
    workspace = ROOT / ".zip_verification_workspace"
    if workspace.exists():
        raise RuntimeError("ZIP_WORKSPACE_PREEXISTS")
    expected_map = {record["relative_path"]: record for record in expected}
    with zipfile.ZipFile(zip_path, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected_map):
            raise RuntimeError("ZIP_MEMBER_SET_MISMATCH")
        if archive.testzip() is not None:
            raise RuntimeError("ZIP_CRC_FAILURE")
        for info in archive.infolist():
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts or "\\" in info.filename:
                raise RuntimeError("ZIP_UNSAFE_PATH")
            if info.flag_bits & 1 or stat.S_ISLNK(info.external_attr >> 16):
                raise RuntimeError("ZIP_UNSAFE_MEMBER_TYPE")
        workspace.mkdir()
        for info in archive.infolist():
            destination = workspace / Path(PurePosixPath(info.filename))
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(archive.read(info.filename))
    if inventory(workspace) != expected:
        raise RuntimeError("ZIP_EXTRACTED_CONTENT_MISMATCH")
    resolved = workspace.resolve(strict=True)
    if resolved.parent != ROOT.resolve(strict=True):
        raise RuntimeError("ZIP_WORKSPACE_PARENT_MISMATCH")
    if os.lstat(resolved).st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError("ZIP_WORKSPACE_REPARSE_POINT")
    for candidate in workspace.rglob("*"):
        if candidate.is_symlink() or (
            os.lstat(candidate).st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT
        ):
            raise RuntimeError("ZIP_WORKSPACE_CONTAINS_REPARSE_POINT")
    shutil.rmtree(workspace)
    if workspace.exists():
        raise RuntimeError("ZIP_WORKSPACE_NOT_REMOVED")
    return {"status": "PASS", "members": len(expected), "crc": "PASS", "workspace_removed": True}


def write_readme() -> None:
    text = """# JANUS A18.44 Window 01 Authorization and Safety Freeze

This additive package freezes governance contracts only. It records the
independent fixture-coverage repair audit PASS and defines requirements for a
future whole-window authorization, a fresh physical-safety snapshot, and a
separate identity-bound consent before every attempt.

This package does not authorize Window 01, authorize an individual attempt,
create an attempt-start phrase, start ordinal 1, create campaign output,
consume an authorization or identity, launch a miner, contact a pool, start
live work, or compute a scientific endpoint.

Historical and current read-only observations are NOT_FUTURE_EXECUTION_EVIDENCE.
The next stage is hash-bound enablement and dry-run validation only.
"""
    (ROOT / "README.md").write_bytes(text.encode("utf-8"))


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    clear_generated()
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_ALREADY_EXISTS")

    audit = verify_audit_attachments()
    repair = verify_repair_package()
    previous = verify_previous_freeze()
    old_repair_tree = payload_root(inventory(REPAIR_ROOT))
    old_freeze_tree = payload_root(inventory(PREVIOUS_FREEZE_ROOT))
    copy_bindings()

    roster = load_json(PREVIOUS_FILES["previous_roster"])["attempts"]
    validator_hash = sha256_file(SRC_ROOT / "window01_safety_freeze" / "validators.py")
    fixtures = execute_fixtures(build_fixture_specs(roster[0]), validator_hash)
    if not fixtures or any(not item["passed"] for item in fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_FAILURE")
    if len({item["fixture_id"] for item in fixtures}) != len(fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_ID_COLLISION")
    if sum(item["execution_count_delta"] for item in fixtures) != 0:
        raise RuntimeError("NEGATIVE_FIXTURE_EXECUTION_COUNT_NONZERO")
    if sum(item["authorization_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("NEGATIVE_FIXTURE_AUTHORIZATION_COUNT_NONZERO")
    if sum(item["identity_consumption_delta"] for item in fixtures) != 0:
        raise RuntimeError("NEGATIVE_FIXTURE_IDENTITY_COUNT_NONZERO")

    write_readme()
    freeze = {
        "schema": f"{SCHEMA_PREFIX}/freeze/v1",
        "created_at_utc": CREATED_AT_UTC,
        "artifact_type": "WINDOW_01_POLICY_FREEZE_NOT_EXECUTION_AUTHORIZATION",
        "stage": "A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_EXECUTION_AUTHORIZATION_AND_FRESH_PHYSICAL_SAFETY_ATTESTATION_FREEZE_ONLY",
        "window_number": 1,
        "first_ordinal": 1,
        "last_ordinal": 10,
        "attempt_count": 10,
        "independent_fixture_coverage_repair_audit": "PASS",
        "historical_observation_class": "NOT_FUTURE_EXECUTION_EVIDENCE",
        "whole_window_authorization_required_in_future": True,
        "per_attempt_fresh_consent_required": True,
        "fresh_safety_snapshot_required_before_every_attempt": True,
        "execution_authorized_by_this_freeze": False,
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_authorized": 0,
        "window_01_attempts_executed": 0,
        "campaign_execution_authorized": False,
        "authorization_consumed": False,
        "campaign_attempts_authorized": 0,
        "campaign_attempts_executed": 0,
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "attempt_start_phrase_created": False,
        "automatic_ordinal_1_start_allowed": False,
        "automatic_next_attempt_allowed": False,
        "next_stage": NEXT_STAGE,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_AND_FRESH_SAFETY_ATTESTATION_FREEZE.json", freeze)

    whole_window = {
        "schema": f"{SCHEMA_PREFIX}/whole-window-authorization-contract/v1",
        "created_at_utc": CREATED_AT_UTC,
        "future_artifact_required": True,
        "future_artifact_not_created_by_this_freeze": True,
        "future_exact_operator_authorization_required": True,
        "attempt_start_phrase_created": False,
        "required_scope": {"window_number": 1, "first_ordinal": 1, "last_ordinal": 10, "attempt_count": 10},
        "required_bindings": [
            "current freeze payload root and manifest SHA-256",
            "exact immutable Window 01 roster SHA-256",
            "exact authorization issuance and expiry bounds",
            "operator authorization bytes and SHA-256",
            "fresh pre-authorization physical-safety snapshot SHA-256",
        ],
        "automatic_ordinal_1_start_allowed": False,
        "automatic_next_attempt_allowed": False,
        "individual_attempts_authorized_by_whole_window_artifact": 0,
        "authorization_consumed_by_this_freeze": False,
        "false_stale_or_indeterminate_decision": "REJECT_AND_STOP_BEFORE_ATTEMPT",
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_WHOLE_WINDOW_AUTHORIZATION_CONTRACT.json", whole_window)

    consent = {
        "schema": f"{SCHEMA_PREFIX}/per-attempt-consent-contract/v1",
        "created_at_utc": CREATED_AT_UTC,
        "separate_fresh_immediate_consent_before_every_attempt": True,
        "required_exact_bindings": [
            "session_id",
            "independent_reset_instance_id",
            "campaign_ordinal",
            "current_window_01_authorization_sha256",
            "current_fresh_physical_safety_snapshot_sha256",
        ],
        "freshness_required": True,
        "one_time_use_only": True,
        "reuse_allowed": False,
        "gate_change_after_consent": "INVALIDATE_CONSENT_AND_STOP_BEFORE_ATTEMPT",
        "consent_is_start_authority": False,
        "consent_created_by_this_freeze": False,
        "attempts_authorized_by_this_freeze": 0,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_PER_ATTEMPT_CONSENT_CONTRACT.json", consent)

    safety = {
        "schema": f"{SCHEMA_PREFIX}/fresh-physical-safety-attestation-contract/v1",
        "created_at_utc": CREATED_AT_UTC,
        "historical_and_current_read_only_observation_label": "NOT_FUTURE_EXECUTION_EVIDENCE",
        "fresh_snapshot_required_before_future_window_authorization": True,
        "fresh_snapshot_required_immediately_before_every_attempt": True,
        "snapshot_reuse_across_attempts_allowed": False,
        "false_or_indeterminate_decision": "STOP_BEFORE_ATTEMPT",
        "identity_bindings": ["window_number", "campaign_ordinal", "session_id", "independent_reset_instance_id"],
        "freshness_bindings": ["captured_at_utc", "captured_monotonic_ns", "clock_domain_id", "expires_at_monotonic_ns"],
        "integrity_bindings": ["snapshot_payload_sha256", "operator_attestation_sha256", "source_evidence_sha256s"],
        "required_fields": [
            {"field": field, "required_value": expected, "false_or_indeterminate_reason": reason}
            for field, expected, reason in SAFETY_EXPECTATIONS
        ],
        "capacity_bindings": {
            "required_free_space_before_campaign_bytes": 76101451776,
            "maximum_bytes_per_attempt": 134217728,
            "maximum_bytes_per_window": 1342177280,
            "minimum_remaining_margin_before_each_attempt_bytes": 134217728,
        },
        "approved_miner_sha256": "c46feec0dd936a65bb8e6e074aaa952a0cd57b6925cfb4dd37aad2140d22e1d2",
        "onedrive_control_by_this_freeze": False,
        "protected_nas_service_control_by_this_freeze": False,
        "physical_readiness_assessed_by_this_freeze": False,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_FRESH_PHYSICAL_SAFETY_ATTESTATION_CONTRACT.json", safety)

    interruption = {
        "schema": f"{SCHEMA_PREFIX}/interruption-and-continuation-policy/v1",
        "created_at_utc": CREATED_AT_UTC,
        "stop_window_on_failed_or_indeterminate_gate": True,
        "stop_window_on_interruption_or_quarantine": True,
        "preserve_interrupted_evidence": True,
        "quarantine_interrupted_identity": True,
        "identity_consumed_only_after_durable_planned_to_started": True,
        "retry_allowed": False,
        "resume_allowed": False,
        "replacement_allowed": False,
        "identity_reuse_allowed": False,
        "outcome_based_continuation_allowed": False,
        "optional_stopping_allowed": False,
        "window_02_transition_allowed": False,
        "new_separate_future_authorization_required_after_stop": True,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_INTERRUPTION_AND_CONTINUATION_POLICY.json", interruption)

    execution_block = {
        "schema": f"{SCHEMA_PREFIX}/execution-block-contract/v1",
        "created_at_utc": CREATED_AT_UTC,
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_authorized": 0,
        "window_01_attempts_executed": "0/10",
        "campaign_execution_authorized": False,
        "authorization_consumed": False,
        "campaign_attempts_authorized": 0,
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "attempt_start_phrase_created": False,
        "scientific_endpoints_computed": False,
        "pool_contacted": False,
        "miner_launched": False,
        "live_started": False,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_EXECUTION_BLOCK_CONTRACT.json", execution_block)

    ingestion = {
        "schema": f"{SCHEMA_PREFIX}/independent-audit-ingestion-receipt/v1",
        "created_at_utc": CREATED_AT_UTC,
        "independent_fixture_coverage_repair_audit_ingested": True,
        "attachment_bytes_locally_mounted": True,
        "local_fixture_coverage_repair_byte_revalidation": "PASS",
        "audit": audit,
        "repair_revalidation": repair,
        "preserved_predecessor_audit_status": "EVIDENCE_INSUFFICIENT",
        "preserved_predecessor_blocker": "NEGATIVE_FIXTURE_EXECUTION_COVERAGE_BELOW_REQUIRED_MINIMUM",
        "predecessor_rewritten": False,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_INDEPENDENT_FIXTURE_REPAIR_AUDIT_INGESTION_RECEIPT.json", ingestion)

    fixture_document = {
        "schema": f"{SCHEMA_PREFIX}/negative-validation-fixtures/v1",
        "created_at_utc": CREATED_AT_UTC,
        "validator_source_sha256": validator_hash,
        "fixtures": fixtures,
        "passed": len(fixtures),
        "total": len(fixtures),
        "unique_fixture_ids": len({item["fixture_id"] for item in fixtures}),
        "fixture_execution_count": 0,
        "authorization_consumption_count": 0,
        "identity_consumption_count": 0,
        "status": "PASS",
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_NEGATIVE_VALIDATION_FIXTURES.json", fixture_document)

    security = scan_security_and_boundaries()
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_SECURITY_AND_BOUNDARY_REPORT.json", security)
    if security["status"] != "PASS":
        raise RuntimeError("SECURITY_OR_EXECUTION_PHRASE_SCAN_FAILED")

    validation = {
        "schema": f"{SCHEMA_PREFIX}/validation-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "independent_fixture_coverage_repair_audit": "PASS",
        "attachment_bytes_locally_mounted": True,
        "local_fixture_coverage_repair_byte_revalidation": "PASS",
        "fresh_safety_attestation_contract": "PASS",
        "whole_window_authorization_contract": "PASS",
        "per_attempt_consent_contract": "PASS",
        "negative_fixtures": f"{len(fixtures)}/{len(fixtures)}",
        "attempt_start_phrase_created": False,
        "automatic_ordinal_1_start_allowed": False,
        "automatic_next_attempt_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_executed": "0/10",
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "first_blocking_invariant": "NONE",
        "exact_next_allowed_stage": NEXT_STAGE,
    }
    write_json(ROOT / "A18_44_V0_1_WINDOW_01_FREEZE_VALIDATION_REPORT.json", validation)

    payload_exclusions = {
        "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_FREEZE_MANIFEST.json",
        "SHA256SUMS.txt",
        ZIP_NAME,
    }
    payload_files = inventory(ROOT, payload_exclusions)
    manifest = {
        "schema": f"{SCHEMA_PREFIX}/manifest/v1",
        "created_at_utc": CREATED_AT_UTC,
        "artifact_type": "WINDOW_01_AUTHORIZATION_AND_FRESH_SAFETY_POLICY_FREEZE",
        "payload_root_algorithm": "Sort UTF-8 relative paths by bytes; append path, NUL, decimal size, NUL, raw SHA-256, LF; hash with SHA-256.",
        "freeze_payload_root_sha256": payload_root(payload_files),
        "file_count": len(payload_files),
        "files": [{**item, "role": role_for(item["relative_path"])} for item in payload_files],
        "execution_authorized": False,
        "attempt_start_phrase_created": False,
        "status": "PASS",
    }
    manifest_path = ROOT / "A18_44_V0_1_WINDOW_01_EXECUTION_AUTHORIZATION_SAFETY_FREEZE_MANIFEST.json"
    write_json(manifest_path, manifest)

    sums_records = inventory(ROOT, {"SHA256SUMS.txt", ZIP_NAME})
    sums_path = ROOT / "SHA256SUMS.txt"
    sums_path.write_bytes(
        "".join(f"{item['sha256']}  {item['relative_path']}\n" for item in sums_records).encode("utf-8")
    )
    sums_passed, sums_total = verify_sums(ROOT, sums_path)
    if sums_passed != sums_total:
        raise RuntimeError("FREEZE_SHA256SUMS_MISMATCH")

    archive_records = inventory(ROOT, {ZIP_NAME})
    zip_path = ROOT / ZIP_NAME
    build_zip(zip_path, archive_records)
    zip_result = verify_zip(zip_path, archive_records)

    if payload_root(inventory(REPAIR_ROOT)) != old_repair_tree:
        raise RuntimeError("REPAIR_PREDECESSOR_MODIFIED")
    if payload_root(inventory(PREVIOUS_FREEZE_ROOT)) != old_freeze_tree:
        raise RuntimeError("PREVIOUS_FREEZE_MODIFIED")
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_CREATED")

    result = {
        "status": "PASS",
        "independent_fixture_coverage_repair_audit": "PASS",
        "local_fixture_coverage_repair_byte_revalidation": "PASS",
        "fresh_safety_attestation_contract": "PASS",
        "whole_window_authorization_contract": "PASS",
        "per_attempt_consent_contract": "PASS",
        "negative_fixtures": f"{len(fixtures)}/{len(fixtures)}",
        "checksums": f"{sums_passed}/{sums_total}",
        "archive": zip_result,
        "freeze_payload_root_sha256": manifest["freeze_payload_root_sha256"],
        "freeze_manifest_sha256": sha256_file(manifest_path),
        "sha256sums_sha256": sha256_file(sums_path),
        "audit_export_zip_sha256": sha256_file(zip_path),
        "audit_export_zip_size_bytes": zip_path.stat().st_size,
        "audit_export_zip_path": str(zip_path),
        "window_01_execution_allowed": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_authorized": 0,
        "window_01_attempts_executed": "0/10",
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "attempt_start_phrase_created": False,
        "first_blocking_invariant": "NONE",
        "exact_next_allowed_stage": NEXT_STAGE,
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
