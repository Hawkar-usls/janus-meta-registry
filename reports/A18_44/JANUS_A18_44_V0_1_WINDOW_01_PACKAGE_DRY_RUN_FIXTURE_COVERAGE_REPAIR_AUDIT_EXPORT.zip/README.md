# JANUS A18.44 Window 01 Fixture Coverage Repair

This additive package repairs only the executable coverage of the prior
Window 01 dry-run negative fixtures. Every counted fixture invokes a named,
pure validator and compares the returned decision with the frozen expected
decision.

The predecessor package remains immutable negative methodological evidence.
This package grants no execution authority, contains no attempt-start phrase,
creates no campaign output, consumes no identity, launches no process, contacts
no pool, and computes no scientific endpoint.

After a local PASS, the only next stage is an independent audit of this repair
package. Campaign execution remains blocked.
