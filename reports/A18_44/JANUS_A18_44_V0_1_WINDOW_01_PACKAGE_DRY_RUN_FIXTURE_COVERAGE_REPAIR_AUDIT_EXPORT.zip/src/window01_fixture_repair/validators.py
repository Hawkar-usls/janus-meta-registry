"""Side-effect-free validators used by every counted negative fixture.

These functions inspect supplied metadata only. They cannot create campaign
directories, start processes, contact a network, consume an identity, or
compute a scientific endpoint.
"""

from __future__ import annotations

from typing import Any, Callable, Mapping


Decision = dict[str, Any]
Validator = Callable[[Mapping[str, Any]], Decision]


def _reject(reason: str) -> Decision:
    return {"decision": "REJECT", "reason": reason}


def _allow(reason: str) -> Decision:
    return {"decision": "ALLOW_DRY_RUN_CHECK_ONLY", "reason": reason}


def validate_roster_binding(data: Mapping[str, Any]) -> Decision:
    expected = data.get("expected")
    observed = data.get("observed")
    if not isinstance(expected, Mapping) or not isinstance(observed, Mapping):
        return _reject("ROSTER_BINDING_OBJECT_MISSING")
    fields = (
        "campaign_attempt_ordinal",
        "planned_execution_order",
        "session_id",
        "independent_reset_instance_id",
        "role",
        "domain_key",
        "session_seed",
        "schedule_entries_sha256",
        "planned_nonce_identity_sha256",
        "planned_manifest_path",
        "planned_state_ledger_path",
        "identity_record_sha256",
    )
    for field in fields:
        if observed.get(field) != expected.get(field):
            return _reject(f"ROSTER_FIELD_MISMATCH:{field}")
    return _allow("ROSTER_BINDING_EXACT")


def validate_identity_state(data: Mapping[str, Any]) -> Decision:
    if data.get("identity_consumed") is not False:
        return _reject("IDENTITY_ALREADY_CONSUMED")
    if data.get("attempt_started") is not False:
        return _reject("IDENTITY_ALREADY_STARTED")
    if data.get("terminal_state") is not None:
        return _reject("IDENTITY_ALREADY_TERMINAL")
    if data.get("quarantine_state") is not None:
        return _reject("IDENTITY_ALREADY_QUARANTINED")
    return _allow("IDENTITY_UNCONSUMED_AND_UNSTARTED")


def validate_whole_window_authorization(data: Mapping[str, Any]) -> Decision:
    if data.get("dry_run_only") is not True:
        return _reject("DRY_RUN_ONLY_REQUIRED")
    if data.get("window_number") != 1:
        return _reject("WINDOW_NUMBER_MISMATCH")
    if data.get("first_ordinal") != 1 or data.get("last_ordinal") != 10:
        return _reject("WINDOW_SCOPE_MISMATCH")
    if data.get("attempt_count") != 10:
        return _reject("WINDOW_ATTEMPT_COUNT_MISMATCH")
    if data.get("scope") != "WINDOW_01_DRY_RUN_STAGE_ONLY":
        return _reject("WINDOW_AUTHORIZATION_SCOPE_MISMATCH")
    if data.get("execution_authority_requested") is not False:
        return _reject("EXECUTION_AUTHORITY_FORBIDDEN")
    issued = data.get("issued_tick")
    observed = data.get("observed_tick")
    maximum_age = data.get("maximum_age_ticks")
    if not all(isinstance(value, int) for value in (issued, observed, maximum_age)):
        return _reject("WINDOW_AUTHORIZATION_FRESHNESS_INDETERMINATE")
    if observed < issued or observed - issued > maximum_age:
        return _reject("WINDOW_AUTHORIZATION_STALE")
    return _allow("WINDOW_01_DRY_RUN_STAGE_ONLY")


def validate_per_attempt_consent(data: Mapping[str, Any]) -> Decision:
    if data.get("consent_present") is not True:
        return _reject("IMMEDIATE_CONSENT_MISSING")
    if data.get("consent_fresh") is not True:
        return _reject("IMMEDIATE_CONSENT_STALE")
    if data.get("consent_session_id") != data.get("expected_session_id"):
        return _reject("CONSENT_SESSION_ID_MISMATCH")
    if data.get("consent_reset_id") != data.get("expected_reset_id"):
        return _reject("CONSENT_RESET_ID_MISMATCH")
    if data.get("consent_ordinal") != data.get("expected_ordinal"):
        return _reject("CONSENT_ORDINAL_MISMATCH")
    if data.get("consent_safety_snapshot_sha256") != data.get(
        "current_safety_snapshot_sha256"
    ):
        return _reject("CONSENT_SAFETY_SNAPSHOT_MISMATCH")
    if data.get("consent_window_authorization_sha256") != data.get(
        "current_window_authorization_sha256"
    ):
        return _reject("CONSENT_WINDOW_AUTHORIZATION_MISMATCH")
    if data.get("any_gate_changed_after_consent") is not False:
        return _reject("CONSENT_INVALIDATED_BY_GATE_CHANGE")
    return _allow("CONSENT_STRUCTURALLY_VALID_FOR_DRY_RUN_CHECK")


def validate_lifecycle_request(data: Mapping[str, Any]) -> Decision:
    if data.get("dry_run_only") is not True:
        return _reject("LIFECYCLE_DRY_RUN_ONLY_REQUIRED")
    forbidden = {
        "AUTO_START_ORDINAL_1",
        "AUTO_START_NEXT_ATTEMPT",
        "PLANNED_TO_STARTED",
        "AUTHORIZE_ATTEMPT",
        "CONSUME_AUTHORIZATION",
        "CONSUME_IDENTITY",
        "TRANSITION_TO_WINDOW_02",
    }
    action = data.get("action")
    if action in forbidden:
        return _reject(f"LIFECYCLE_ACTION_FORBIDDEN:{action}")
    if data.get("requested_transition") == "PLANNED->STARTED":
        return _reject("PLANNED_TO_STARTED_FORBIDDEN")
    return _allow("NO_LIFECYCLE_MUTATION_REQUESTED")


def validate_filesystem_request(data: Mapping[str, Any]) -> Decision:
    if data.get("create_campaign_output_root") is True:
        return _reject("CAMPAIGN_OUTPUT_ROOT_CREATION_FORBIDDEN")
    if data.get("create_attempt_directory") is True:
        return _reject("ATTEMPT_DIRECTORY_CREATION_FORBIDDEN")
    if data.get("campaign_output_root_exists") is True:
        return _reject("CAMPAIGN_OUTPUT_ROOT_PREEXISTS")
    if data.get("attempt_directory_exists") is True:
        return _reject("ATTEMPT_DIRECTORY_PREEXISTS")
    if data.get("absolute_path") is True:
        return _reject("ABSOLUTE_PATH_FORBIDDEN")
    if data.get("parent_traversal") is True:
        return _reject("PARENT_TRAVERSAL_FORBIDDEN")
    if data.get("symlink_escape") is True:
        return _reject("SYMLINK_ESCAPE_FORBIDDEN")
    if data.get("reparse_escape") is True:
        return _reject("REPARSE_ESCAPE_FORBIDDEN")
    return _allow("FILESYSTEM_REQUEST_IS_NONMUTATING_AND_CONFINED")


def validate_process_and_miner_state(data: Mapping[str, Any]) -> Decision:
    if data.get("process_state_known") is not True:
        return _reject("PROCESS_STATE_INDETERMINATE")
    if data.get("campaign_process_active") is True:
        return _reject("CAMPAIGN_PROCESS_ALREADY_ACTIVE")
    if data.get("miner_process_active") is True:
        return _reject("MINER_PROCESS_ALREADY_ACTIVE")
    if data.get("approved_miner_hash_matches") is not True:
        return _reject("APPROVED_MINER_HASH_MISMATCH")
    if data.get("launch_requested") is True:
        return _reject("PROCESS_LAUNCH_FORBIDDEN")
    return _allow("PROCESS_AND_MINER_STATE_DRY_RUN_SAFE")


def validate_physical_safety_snapshot(data: Mapping[str, Any]) -> Decision:
    checks = (
        ("power_state_known", True, "POWER_STATE_INDETERMINATE"),
        ("stable_external_power", True, "STABLE_EXTERNAL_POWER_REQUIRED"),
        ("critical_battery_warning", False, "CRITICAL_BATTERY_WARNING"),
        ("pending_restart_or_shutdown", False, "RESTART_OR_SHUTDOWN_PENDING"),
        ("free_space_known", True, "FREE_SPACE_INDETERMINATE"),
        ("free_space_sufficient", True, "FREE_SPACE_INSUFFICIENT"),
        ("all_required_files_local", True, "REQUIRED_FILE_NOT_FULLY_LOCAL"),
        ("files_on_demand_placeholder", False, "FILES_ON_DEMAND_PLACEHOLDER"),
        ("sync_state_known", True, "SYNC_STATE_INDETERMINATE"),
        ("onedrive_sync_paused", True, "ONEDRIVE_SYNC_NOT_PAUSED"),
        ("second_device_writer", False, "SECOND_DEVICE_WRITER_PRESENT"),
        ("second_process_writer", False, "SECOND_PROCESS_WRITER_PRESENT"),
    )
    for field, expected, reason in checks:
        if data.get(field) is not expected:
            return _reject(reason)
    return _allow("PHYSICAL_SAFETY_SNAPSHOT_STRUCTURALLY_READY")


def validate_interruption_action(data: Mapping[str, Any]) -> Decision:
    forbidden = {
        "RETRY",
        "RESUME",
        "REPLACE_IDENTITY",
        "REUSE_IDENTITY",
        "CONTINUE_AFTER_INTERRUPTION",
        "CONTINUE_AFTER_QUARANTINE",
    }
    action = data.get("action")
    if action in forbidden:
        return _reject(f"INTERRUPTION_ACTION_FORBIDDEN:{action}")
    return _allow("INTERRUPTION_PRESERVED_WITHOUT_CONTINUATION")


def validate_prohibited_activity(data: Mapping[str, Any]) -> Decision:
    forbidden = {
        "COMPUTE_SCIENTIFIC_ENDPOINT",
        "INSPECT_OUTCOME",
        "OPTIONAL_STOPPING",
        "CONTACT_POOL",
        "LAUNCH_MINER",
        "START_LIVE",
        "EXECUTE_CAMPAIGN",
        "AUTHORIZE_WINDOW_EXECUTION",
        "AUTHORIZE_ATTEMPT",
        "CREATE_EXECUTION_PHRASE",
    }
    action = data.get("action")
    if action in forbidden:
        return _reject(f"PROHIBITED_ACTIVITY:{action}")
    return _allow("NO_PROHIBITED_ACTIVITY_REQUESTED")


def validate_secret_scan(data: Mapping[str, Any]) -> Decision:
    findings = data.get("high_confidence_secret_findings")
    if not isinstance(findings, int):
        return _reject("SECRET_SCAN_INDETERMINATE")
    if findings != 0:
        return _reject("SECRET_OR_CREDENTIAL_FINDING")
    return _allow("ZERO_HIGH_CONFIDENCE_SECRET_FINDINGS")


def validate_phrase_authority(data: Mapping[str, Any]) -> Decision:
    if data.get("execution_phrase_creation_requested") is True:
        return _reject("EXECUTION_PHRASE_CREATION_FORBIDDEN")
    if data.get("dry_run_phrase_used_as_execution_authority") is True:
        return _reject("DRY_RUN_PHRASE_IS_NOT_EXECUTION_AUTHORITY")
    if data.get("phrase_scope") != "WINDOW_01_DRY_RUN_STAGE_ONLY":
        return _reject("PHRASE_SCOPE_MISMATCH")
    return _allow("DRY_RUN_STAGE_ONLY")


VALIDATORS: dict[str, Validator] = {
    "validate_roster_binding": validate_roster_binding,
    "validate_identity_state": validate_identity_state,
    "validate_whole_window_authorization": validate_whole_window_authorization,
    "validate_per_attempt_consent": validate_per_attempt_consent,
    "validate_lifecycle_request": validate_lifecycle_request,
    "validate_filesystem_request": validate_filesystem_request,
    "validate_process_and_miner_state": validate_process_and_miner_state,
    "validate_physical_safety_snapshot": validate_physical_safety_snapshot,
    "validate_interruption_action": validate_interruption_action,
    "validate_prohibited_activity": validate_prohibited_activity,
    "validate_secret_scan": validate_secret_scan,
    "validate_phrase_authority": validate_phrase_authority,
}


def invoke_validator(name: str, data: Mapping[str, Any]) -> Decision:
    """Invoke a named pure validator; unknown names fail closed."""

    validator = VALIDATORS.get(name)
    if validator is None:
        return _reject("UNKNOWN_VALIDATOR")
    return validator(data)
