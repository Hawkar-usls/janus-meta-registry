"""Build the additive Window 01 executable-fixture coverage repair package.

The builder invokes pure validators against synthetic metadata only. It does
not create campaign output, start a process, consume an identity, inspect an
outcome, or calculate a scientific endpoint.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
I0_ROOT = PACKAGE_ROOT.parent
SRC_ROOT = PACKAGE_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from window01_fixture_repair.validators import invoke_validator  # noqa: E402


SCHEMA_PREFIX = "JANUS/A18.44/v0.1/window-01-fixture-coverage-repair"
CREATED_AT_UTC = "2026-07-17T00:00:00Z"
OLD_PACKAGE = I0_ROOT / (
    "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_"
    "HASH_BOUND_EXECUTION_PACKAGE_DRY_RUN"
)
CAMPAIGN_OUTPUT_ROOT = I0_ROOT / (
    "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_OUTPUT"
)
DOWNLOADS = Path.home() / "Downloads"
AUDIT_JSON = DOWNLOADS / (
    "JANUS_A18_44_WINDOW_01_PACKAGE_DRY_RUN_INDEPENDENT_AUDIT_RESULT.json"
)
AUDIT_TEXT = DOWNLOADS / (
    "JANUS_A18_44_WINDOW_01_PACKAGE_DRY_RUN_INDEPENDENT_AUDIT_RESULT.txt"
)
ZIP_NAME = (
    "JANUS_A18_44_V0_1_WINDOW_01_PACKAGE_DRY_RUN_"
    "FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip"
)

EXPECTED = {
    "audit_json": "b3eeba525e72c7b138ec668685c450764706d0e0b4ac73d0020490a99bdbc01f",
    "audit_text": "0908449fc14e310c19e791ec8e20cfda74c20055a9e985e25426143d30fbaf1d",
    "old_manifest": "29ebb676e6a3e9499bd7cb9296dcfdbac50e8520c2a9eb134fff30dde263316d",
    "old_validation": "ea145703e9b52ea6e1f28c6a7677e43f4f8af92ba30d391af31a9fa690458e3e",
    "old_fixtures": "13ed6d00b0d0efb323f142f13a39c164cc840214b56316b321e9932a180249c4",
    "old_roster": "2e1be042b31c83104ad3e2d418861ff931a48e38160f20d836e6b5808eb3280f",
    "old_sums": "ba3cc3b173f932edb3239dc93a38bbed7a4cd80df63f68d47cb97e9aa0574890",
    "old_builder": "0fc1b6a3e02e6872610b237b00f2ed7ffd972c823ded0f3815b12b6d91b6df62",
    "old_zip": "373a42f1c38d674455c5af82fd1a5e84ce5c9ef35c0f87d0ffecf6fa41162963",
    "old_payload_root": "9d6aed4c344a1b18b67557ba3263db255d96c6e901d8260d3c9e67ec10fb7ba3",
}

OLD_FILES = {
    "old_manifest": OLD_PACKAGE
    / "A18_44_V0_1_WINDOW_01_EXECUTION_PACKAGE_MANIFEST.json",
    "old_validation": OLD_PACKAGE
    / "A18_44_V0_1_WINDOW_01_PACKAGE_DRY_RUN_VALIDATION_REPORT.json",
    "old_fixtures": OLD_PACKAGE
    / "A18_44_V0_1_WINDOW_01_PACKAGE_NEGATIVE_FIXTURES.json",
    "old_roster": OLD_PACKAGE
    / "A18_44_V0_1_WINDOW_01_IMMUTABLE_ROSTER_BINDING.json",
    "old_sums": OLD_PACKAGE / "SHA256SUMS.txt",
    "old_builder": OLD_PACKAGE
    / "tooling"
    / "build_and_validate_window_01_hash_bound_dry_run.py",
    "old_zip": OLD_PACKAGE
    / "JANUS_A18_44_V0_1_WINDOW_01_HASH_BOUND_EXECUTION_PACKAGE_DRY_RUN_AUDIT_EXPORT.zip",
}

GENERATED_NAMES = {
    "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PREDECESSOR_BINDING_RECEIPT.json",
    "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_NEGATIVE_FIXTURES.json",
    "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_SECURITY_AND_BOUNDARY_REPORT.json",
    "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_VALIDATION_REPORT.json",
    "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json",
    "README.md",
    "SHA256SUMS.txt",
    ZIP_NAME,
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def write_json(path: Path, value: Any) -> None:
    data = json.dumps(
        value, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    path.write_bytes(data)


def clear_generated_artifacts() -> None:
    """Remove only known, unsealed outputs from an earlier failed build."""

    for name in GENERATED_NAMES:
        path = PACKAGE_ROOT / name
        if not path.exists():
            continue
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"UNSAFE_GENERATED_ARTIFACT:{name}")
        if path.resolve().parent != PACKAGE_ROOT.resolve():
            raise RuntimeError(f"GENERATED_ARTIFACT_PARENT_MISMATCH:{name}")
        path.unlink()


def duplicate_key_guard(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json_strict(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key_guard)


def normalized_relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def inventory(root: Path, exclude: set[str] | None = None) -> list[dict[str, Any]]:
    excluded = exclude or set()
    records = []
    for path in sorted(
        (candidate for candidate in root.rglob("*") if candidate.is_file()),
        key=lambda candidate: normalized_relative(candidate, root).encode("utf-8"),
    ):
        rel = normalized_relative(path, root)
        if rel in excluded:
            continue
        records.append(
            {
                "relative_path": rel,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return records


def payload_root(records: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
        digest.update(record["relative_path"].encode("utf-8"))
        digest.update(b"\x00")
        digest.update(str(record["size_bytes"]).encode("ascii"))
        digest.update(b"\x00")
        digest.update(bytes.fromhex(record["sha256"]))
        digest.update(b"\n")
    return digest.hexdigest()


def verify_sha256sums(root: Path, sums_path: Path) -> tuple[int, int]:
    passed = 0
    total = 0
    for raw_line in sums_path.read_text(encoding="utf-8").splitlines():
        if not raw_line.strip():
            continue
        total += 1
        expected_hash, relative = raw_line.split("  ", 1)
        target = root / Path(relative)
        if target.is_file() and sha256_file(target) == expected_hash:
            passed += 1
    return passed, total


def verify_predecessors() -> dict[str, Any]:
    if not OLD_PACKAGE.is_dir():
        raise RuntimeError("PREDECESSOR_PACKAGE_MISSING")
    bindings = {}
    for name, path in OLD_FILES.items():
        if not path.is_file():
            raise RuntimeError(f"PREDECESSOR_FILE_MISSING:{name}")
        observed = sha256_file(path)
        if observed != EXPECTED[name]:
            raise RuntimeError(f"PREDECESSOR_HASH_MISMATCH:{name}")
        bindings[name] = {"path": str(path), "sha256": observed, "status": "PASS"}
    sums_passed, sums_total = verify_sha256sums(OLD_PACKAGE, OLD_FILES["old_sums"])
    if (sums_passed, sums_total) != (26, 26):
        raise RuntimeError("PREDECESSOR_SHA256SUMS_MISMATCH")
    old_manifest = load_json_strict(OLD_FILES["old_manifest"])
    if old_manifest.get("package_payload_root_sha256") != EXPECTED["old_payload_root"]:
        raise RuntimeError("PREDECESSOR_PAYLOAD_ROOT_MISMATCH")
    old_tree = inventory(OLD_PACKAGE)
    return {
        "bindings": bindings,
        "sha256sums": f"{sums_passed}/{sums_total}",
        "tree_file_count": len(old_tree),
        "tree_root_sha256": payload_root(old_tree),
        "tree_inventory": old_tree,
    }


def verify_independent_audit() -> dict[str, Any]:
    for path, expected in (
        (AUDIT_JSON, EXPECTED["audit_json"]),
        (AUDIT_TEXT, EXPECTED["audit_text"]),
    ):
        if not path.is_file() or sha256_file(path) != expected:
            raise RuntimeError(f"INDEPENDENT_AUDIT_ATTACHMENT_MISMATCH:{path.name}")
    audit = load_json_strict(AUDIT_JSON)
    finding = audit.get("negative_fixture_finding", {})
    if audit.get("audit_status") != "EVIDENCE_INSUFFICIENT":
        raise RuntimeError("INDEPENDENT_AUDIT_STATUS_MISMATCH")
    if audit.get("first_blocking_invariant") != (
        "NEGATIVE_FIXTURE_EXECUTION_COVERAGE_BELOW_REQUIRED_MINIMUM"
    ):
        raise RuntimeError("INDEPENDENT_AUDIT_BLOCKER_MISMATCH")
    if finding.get("validator_backed_fixtures") != 55:
        raise RuntimeError("INDEPENDENT_AUDIT_VALIDATOR_COUNT_MISMATCH")
    if finding.get("declaration_only_fixtures") != 87:
        raise RuntimeError("INDEPENDENT_AUDIT_DECLARATION_COUNT_MISMATCH")
    text = AUDIT_TEXT.read_text(encoding="utf-8")
    required_lines = (
        "VALIDATOR_BACKED_FIXTURES=55",
        "DECLARATION_ONLY_FIXTURES=87",
        "REQUIRED_EXECUTABLE_FIXTURES=100",
    )
    if any(line not in text for line in required_lines):
        raise RuntimeError("INDEPENDENT_AUDIT_TEXT_MISMATCH")
    return {
        "json_sha256": EXPECTED["audit_json"],
        "text_sha256": EXPECTED["audit_text"],
        "status": "PASS",
        "reported_validator_backed": 55,
        "reported_declaration_only": 87,
    }


def baseline_whole_window() -> dict[str, Any]:
    return {
        "dry_run_only": True,
        "window_number": 1,
        "first_ordinal": 1,
        "last_ordinal": 10,
        "attempt_count": 10,
        "scope": "WINDOW_01_DRY_RUN_STAGE_ONLY",
        "execution_authority_requested": False,
        "issued_tick": 100,
        "observed_tick": 110,
        "maximum_age_ticks": 20,
    }


def baseline_consent(attempt: dict[str, Any]) -> dict[str, Any]:
    return {
        "consent_present": True,
        "consent_fresh": True,
        "consent_session_id": attempt["session_id"],
        "expected_session_id": attempt["session_id"],
        "consent_reset_id": attempt["independent_reset_instance_id"],
        "expected_reset_id": attempt["independent_reset_instance_id"],
        "consent_ordinal": attempt["campaign_attempt_ordinal"],
        "expected_ordinal": attempt["campaign_attempt_ordinal"],
        "consent_safety_snapshot_sha256": "1" * 64,
        "current_safety_snapshot_sha256": "1" * 64,
        "consent_window_authorization_sha256": "2" * 64,
        "current_window_authorization_sha256": "2" * 64,
        "any_gate_changed_after_consent": False,
    }


def baseline_physical() -> dict[str, Any]:
    return {
        "power_state_known": True,
        "stable_external_power": True,
        "critical_battery_warning": False,
        "pending_restart_or_shutdown": False,
        "free_space_known": True,
        "free_space_sufficient": True,
        "all_required_files_local": True,
        "files_on_demand_placeholder": False,
        "sync_state_known": True,
        "onedrive_sync_paused": True,
        "second_device_writer": False,
        "second_process_writer": False,
    }


def fixture_specs(roster: list[dict[str, Any]]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []

    def add(fixture_id: str, category: str, validator: str, data: dict[str, Any]) -> None:
        specs.append(
            {
                "fixture_id": fixture_id,
                "category": category,
                "validator_callable": validator,
                "input": data,
                "expected_decision": "REJECT",
            }
        )

    roster_mutations = (
        ("SESSION", "session_id", lambda value: f"{value}_tampered"),
        ("RESET", "independent_reset_instance_id", lambda value: f"{value}_tampered"),
        ("ORDINAL", "campaign_attempt_ordinal", lambda value: value + 1000),
        ("ORDER", "planned_execution_order", lambda value: value + 1000),
        (
            "ROLE",
            "role",
            lambda value: (
                "EVALUATION_CAPABLE_ROLE"
                if value == "CALIBRATION_CAPABLE_ROLE"
                else "CALIBRATION_CAPABLE_ROLE"
            ),
        ),
    )
    for attempt in roster:
        ordinal = attempt["campaign_attempt_ordinal"]
        for label, field, mutate in roster_mutations:
            observed = copy.deepcopy(attempt)
            observed[field] = mutate(observed[field])
            add(
                f"ROSTER_{ordinal:03d}_{label}_MISMATCH",
                "ROSTER_BINDING",
                "validate_roster_binding",
                {"expected": copy.deepcopy(attempt), "observed": observed},
            )

    identity_mutations = (
        ("CONSUMED", "identity_consumed", True),
        ("STARTED", "attempt_started", True),
        ("SEALED", "terminal_state", "SEALED_VALID"),
        ("QUARANTINED", "quarantine_state", "INTERRUPTED_QUARANTINED"),
    )
    for attempt in roster:
        ordinal = attempt["campaign_attempt_ordinal"]
        for label, field, value in identity_mutations:
            data = {
                "campaign_attempt_ordinal": ordinal,
                "identity_consumed": False,
                "attempt_started": False,
                "terminal_state": None,
                "quarantine_state": None,
            }
            data[field] = value
            add(
                f"IDENTITY_{ordinal:03d}_{label}",
                "IDENTITY_STATE",
                "validate_identity_state",
                data,
            )

    whole_window_mutations = (
        ("DRY_RUN_FALSE", "dry_run_only", False),
        ("WRONG_WINDOW", "window_number", 2),
        ("WRONG_FIRST", "first_ordinal", 2),
        ("WRONG_LAST", "last_ordinal", 11),
        ("WRONG_COUNT", "attempt_count", 9),
        ("WRONG_SCOPE", "scope", "WINDOW_01_EXECUTION"),
        ("EXECUTION_REQUESTED", "execution_authority_requested", True),
        ("STALE", "observed_tick", 200),
    )
    for label, field, value in whole_window_mutations:
        data = baseline_whole_window()
        data[field] = value
        add(
            f"WHOLE_WINDOW_{label}",
            "WHOLE_WINDOW_AUTHORIZATION",
            "validate_whole_window_authorization",
            data,
        )

    consent_mutations = (
        ("MISSING", "consent_present", False),
        ("STALE", "consent_fresh", False),
        ("WRONG_SESSION", "consent_session_id", "wrong-session"),
        ("WRONG_RESET", "consent_reset_id", "wrong-reset"),
        ("WRONG_ORDINAL", "consent_ordinal", 999),
        ("WRONG_SNAPSHOT", "consent_safety_snapshot_sha256", "3" * 64),
        ("WRONG_WINDOW_AUTH", "consent_window_authorization_sha256", "4" * 64),
        ("GATE_CHANGED", "any_gate_changed_after_consent", True),
    )
    for label, field, value in consent_mutations:
        data = baseline_consent(roster[0])
        data[field] = value
        add(
            f"CONSENT_{label}",
            "PER_ATTEMPT_CONSENT",
            "validate_per_attempt_consent",
            data,
        )

    for action in (
        "AUTO_START_ORDINAL_1",
        "AUTO_START_NEXT_ATTEMPT",
        "PLANNED_TO_STARTED",
        "AUTHORIZE_ATTEMPT",
        "CONSUME_AUTHORIZATION",
        "CONSUME_IDENTITY",
        "TRANSITION_TO_WINDOW_02",
    ):
        add(
            f"LIFECYCLE_{action}",
            "LIFECYCLE",
            "validate_lifecycle_request",
            {"dry_run_only": True, "action": action, "requested_transition": None},
        )
    add(
        "LIFECYCLE_EXPLICIT_PLANNED_TO_STARTED",
        "LIFECYCLE",
        "validate_lifecycle_request",
        {"dry_run_only": True, "action": "NONE", "requested_transition": "PLANNED->STARTED"},
    )

    filesystem_mutations = (
        ("CREATE_CAMPAIGN_ROOT", "create_campaign_output_root", True),
        ("CREATE_ATTEMPT_DIR", "create_attempt_directory", True),
        ("CAMPAIGN_ROOT_EXISTS", "campaign_output_root_exists", True),
        ("ATTEMPT_DIR_EXISTS", "attempt_directory_exists", True),
        ("ABSOLUTE_PATH", "absolute_path", True),
        ("PARENT_TRAVERSAL", "parent_traversal", True),
        ("SYMLINK_ESCAPE", "symlink_escape", True),
        ("REPARSE_ESCAPE", "reparse_escape", True),
    )
    filesystem_base = {
        "create_campaign_output_root": False,
        "create_attempt_directory": False,
        "campaign_output_root_exists": False,
        "attempt_directory_exists": False,
        "absolute_path": False,
        "parent_traversal": False,
        "symlink_escape": False,
        "reparse_escape": False,
    }
    for label, field, value in filesystem_mutations:
        data = dict(filesystem_base)
        data[field] = value
        add(
            f"FILESYSTEM_{label}",
            "FILESYSTEM",
            "validate_filesystem_request",
            data,
        )

    process_mutations = (
        ("INDETERMINATE", "process_state_known", False),
        ("CAMPAIGN_ACTIVE", "campaign_process_active", True),
        ("MINER_ACTIVE", "miner_process_active", True),
        ("MINER_HASH_MISMATCH", "approved_miner_hash_matches", False),
        ("LAUNCH_REQUESTED", "launch_requested", True),
    )
    process_base = {
        "process_state_known": True,
        "campaign_process_active": False,
        "miner_process_active": False,
        "approved_miner_hash_matches": True,
        "launch_requested": False,
    }
    for label, field, value in process_mutations:
        data = dict(process_base)
        data[field] = value
        add(
            f"PROCESS_{label}",
            "PROCESS_AND_MINER",
            "validate_process_and_miner_state",
            data,
        )

    physical_mutations = (
        ("POWER_UNKNOWN", "power_state_known", False),
        ("EXTERNAL_POWER_ABSENT", "stable_external_power", False),
        ("CRITICAL_BATTERY", "critical_battery_warning", True),
        ("RESTART_PENDING", "pending_restart_or_shutdown", True),
        ("DISK_UNKNOWN", "free_space_known", False),
        ("DISK_INSUFFICIENT", "free_space_sufficient", False),
        ("FILES_NOT_LOCAL", "all_required_files_local", False),
        ("PLACEHOLDER", "files_on_demand_placeholder", True),
        ("SYNC_UNKNOWN", "sync_state_known", False),
        ("SYNC_NOT_PAUSED", "onedrive_sync_paused", False),
        ("SECOND_DEVICE_WRITER", "second_device_writer", True),
        ("SECOND_PROCESS_WRITER", "second_process_writer", True),
    )
    for label, field, value in physical_mutations:
        data = baseline_physical()
        data[field] = value
        add(
            f"PHYSICAL_{label}",
            "PHYSICAL_SAFETY",
            "validate_physical_safety_snapshot",
            data,
        )

    for action in (
        "RETRY",
        "RESUME",
        "REPLACE_IDENTITY",
        "REUSE_IDENTITY",
        "CONTINUE_AFTER_INTERRUPTION",
        "CONTINUE_AFTER_QUARANTINE",
    ):
        add(
            f"INTERRUPTION_{action}",
            "INTERRUPTION",
            "validate_interruption_action",
            {"action": action},
        )

    for action in (
        "COMPUTE_SCIENTIFIC_ENDPOINT",
        "INSPECT_OUTCOME",
        "OPTIONAL_STOPPING",
        "CONTACT_POOL",
        "LAUNCH_MINER",
        "START_LIVE",
        "EXECUTE_CAMPAIGN",
        "AUTHORIZE_WINDOW_EXECUTION",
        "AUTHORIZE_ATTEMPT",
        "CREATE_EXECUTION_PHRASE",
    ):
        add(
            f"PROHIBITED_{action}",
            "PROHIBITED_ACTIVITY",
            "validate_prohibited_activity",
            {"action": action},
        )

    add(
        "SECRET_FINDING_PRESENT",
        "SECURITY",
        "validate_secret_scan",
        {"high_confidence_secret_findings": 1},
    )
    add(
        "SECRET_SCAN_INDETERMINATE",
        "SECURITY",
        "validate_secret_scan",
        {"high_confidence_secret_findings": "unknown"},
    )
    add(
        "PHRASE_EXECUTION_CREATION_REQUEST",
        "PHRASE_AUTHORITY",
        "validate_phrase_authority",
        {
            "execution_phrase_creation_requested": True,
            "dry_run_phrase_used_as_execution_authority": False,
            "phrase_scope": "WINDOW_01_DRY_RUN_STAGE_ONLY",
        },
    )
    add(
        "PHRASE_DRY_RUN_USED_AS_EXECUTION_AUTHORITY",
        "PHRASE_AUTHORITY",
        "validate_phrase_authority",
        {
            "execution_phrase_creation_requested": False,
            "dry_run_phrase_used_as_execution_authority": True,
            "phrase_scope": "WINDOW_01_DRY_RUN_STAGE_ONLY",
        },
    )
    add(
        "PHRASE_SCOPE_MISMATCH",
        "PHRASE_AUTHORITY",
        "validate_phrase_authority",
        {
            "execution_phrase_creation_requested": False,
            "dry_run_phrase_used_as_execution_authority": False,
            "phrase_scope": "WINDOW_01_EXECUTION",
        },
    )
    return specs


def execute_fixtures(specs: list[dict[str, Any]], validator_hash: str) -> list[dict[str, Any]]:
    results = []
    seen: set[str] = set()
    for sequence, spec in enumerate(specs, start=1):
        fixture_id = spec["fixture_id"]
        if fixture_id in seen:
            raise RuntimeError(f"DUPLICATE_FIXTURE_ID:{fixture_id}")
        seen.add(fixture_id)
        input_hash = sha256_bytes(canonical_bytes(spec["input"]))
        returned = invoke_validator(spec["validator_callable"], spec["input"])
        return_hash = sha256_bytes(canonical_bytes(returned))
        passed = returned.get("decision") == spec["expected_decision"]
        results.append(
            {
                **spec,
                "invocation_sequence": sequence,
                "validator_invoked": True,
                "validator_source_sha256": validator_hash,
                "input_sha256": input_hash,
                "returned_decision": returned.get("decision"),
                "returned_reason": returned.get("reason"),
                "return_sha256": return_hash,
                "passed": passed,
                "declaration_only": False,
                "execution_count_delta": 0,
                "identity_consumption_delta": 0,
            }
        )
    return results


def copy_predecessor_evidence() -> None:
    target = PACKAGE_ROOT / "predecessor_bindings"
    target.mkdir(parents=True, exist_ok=True)
    copies = (
        (AUDIT_JSON, target / AUDIT_JSON.name),
        (AUDIT_TEXT, target / AUDIT_TEXT.name),
        (
            OLD_FILES["old_manifest"],
            target / "PREDECESSOR_EXECUTION_PACKAGE_MANIFEST.json",
        ),
        (
            OLD_FILES["old_validation"],
            target / "PREDECESSOR_DRY_RUN_VALIDATION_REPORT.json",
        ),
        (
            OLD_FILES["old_fixtures"],
            target / "PREDECESSOR_NEGATIVE_FIXTURES.json",
        ),
        (
            OLD_FILES["old_roster"],
            target / "PREDECESSOR_IMMUTABLE_ROSTER_BINDING.json",
        ),
    )
    for source, destination in copies:
        shutil.copyfile(source, destination)
        if sha256_file(source) != sha256_file(destination):
            raise RuntimeError(f"PREDECESSOR_COPY_HASH_MISMATCH:{destination.name}")


def security_scan() -> dict[str, Any]:
    findings = []
    # Assemble signatures so the scanner source does not match its own probes.
    forbidden_markers = (
        b"-----BEGIN " + b"PRIVATE KEY-----",
        b"-----BEGIN " + b"RSA PRIVATE KEY-----",
        b'"' + b"password" + b'":"',
        b'"' + b"api_token" + b'":"',
        b'"' + b"private_key" + b'":"',
    )
    for path in PACKAGE_ROOT.rglob("*"):
        if not path.is_file() or path.name == ZIP_NAME:
            continue
        data = path.read_bytes()
        for marker in forbidden_markers:
            if marker in data:
                findings.append(
                    {
                        "relative_path": normalized_relative(path, PACKAGE_ROOT),
                        "finding_class": marker.decode("ascii", errors="replace"),
                    }
                )
    return {
        "schema": f"{SCHEMA_PREFIX}/security-and-boundary-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "high_confidence_secret_findings": len(findings),
        "findings": findings,
        "network_calls": 0,
        "subprocess_calls": 0,
        "miner_launches": 0,
        "pool_contacts": 0,
        "campaign_attempts_executed": 0,
        "campaign_identities_consumed": 0,
        "scientific_endpoints_computed": False,
        "status": "PASS" if not findings else "FAIL",
    }


def write_readme() -> None:
    text = """# JANUS A18.44 Window 01 Fixture Coverage Repair

This additive package repairs only the executable coverage of the prior
Window 01 dry-run negative fixtures. Every counted fixture invokes a named,
pure validator and compares the returned decision with the frozen expected
decision.

The predecessor package remains immutable negative methodological evidence.
This package grants no execution authority, contains no attempt-start phrase,
creates no campaign output, consumes no identity, launches no process, contacts
no pool, and computes no scientific endpoint.

After a local PASS, the only next stage is an independent audit of this repair
package. Campaign execution remains blocked.
"""
    (PACKAGE_ROOT / "README.md").write_bytes(text.encode("utf-8"))


def role_for_path(relative_path: str) -> str:
    if relative_path.startswith("src/"):
        return "PURE_VALIDATOR_SOURCE"
    if relative_path.startswith("tooling/"):
        return "BUILD_AND_VALIDATION_TOOLING"
    if relative_path.startswith("predecessor_bindings/"):
        return "IMMUTABLE_PREDECESSOR_COPY"
    if relative_path == "README.md":
        return "OPERATOR_README"
    if "NEGATIVE_FIXTURES" in relative_path:
        return "EXECUTED_FIXTURE_LEDGER"
    if "VALIDATION_REPORT" in relative_path:
        return "VALIDATION_REPORT"
    if "SECURITY_AND_BOUNDARY" in relative_path:
        return "SECURITY_AND_BOUNDARY_REPORT"
    if "PREDECESSOR_BINDING" in relative_path:
        return "PREDECESSOR_BINDING_RECEIPT"
    return "PACKAGE_ARTIFACT"


def build_zip(zip_path: Path, records: list[dict[str, Any]]) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(
        zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for record in records:
            source = PACKAGE_ROOT / Path(record["relative_path"])
            info = zipfile.ZipInfo(record["relative_path"], date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_zip_and_remove_workspace(zip_path: Path, expected: list[dict[str, Any]]) -> dict[str, Any]:
    workspace = PACKAGE_ROOT / ".zip_verification_workspace"
    if workspace.exists():
        raise RuntimeError("ZIP_VERIFICATION_WORKSPACE_PREEXISTS")
    expected_map = {record["relative_path"]: record for record in expected}
    with zipfile.ZipFile(zip_path, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("ZIP_DUPLICATE_MEMBER")
        if set(names) != set(expected_map):
            raise RuntimeError("ZIP_MEMBER_SET_MISMATCH")
        for info in archive.infolist():
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts or "\\" in info.filename:
                raise RuntimeError("ZIP_UNSAFE_PATH")
            if info.flag_bits & 0x1:
                raise RuntimeError("ZIP_ENCRYPTED_MEMBER")
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise RuntimeError("ZIP_SYMLINK_MEMBER")
        if archive.testzip() is not None:
            raise RuntimeError("ZIP_CRC_FAILURE")
        workspace.mkdir()
        for info in archive.infolist():
            destination = workspace / Path(PurePosixPath(info.filename))
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(archive.read(info.filename))
    extracted = inventory(workspace)
    if extracted != expected:
        raise RuntimeError("ZIP_EXTRACTED_HASH_MISMATCH")
    resolved_workspace = workspace.resolve(strict=True)
    if resolved_workspace.parent != PACKAGE_ROOT.resolve(strict=True):
        raise RuntimeError("ZIP_WORKSPACE_PARENT_MISMATCH")
    attributes = os.lstat(resolved_workspace).st_file_attributes
    if attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError("ZIP_WORKSPACE_REPARSE_POINT")
    for candidate in workspace.rglob("*"):
        attributes = os.lstat(candidate).st_file_attributes
        if candidate.is_symlink() or attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError("ZIP_WORKSPACE_CONTAINS_REPARSE_POINT")
    shutil.rmtree(workspace)
    if workspace.exists():
        raise RuntimeError("ZIP_WORKSPACE_REMOVAL_FAILED")
    return {
        "status": "PASS",
        "member_count": len(expected),
        "crc": "PASS",
        "duplicate_members": 0,
        "unsafe_paths": 0,
        "encrypted_entries": 0,
        "symlink_members": 0,
        "workspace_removed": True,
    }


def main() -> None:
    PACKAGE_ROOT.mkdir(parents=True, exist_ok=True)
    clear_generated_artifacts()
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_ALREADY_EXISTS")

    predecessor_before = verify_predecessors()
    audit_binding = verify_independent_audit()
    copy_predecessor_evidence()

    roster_document = load_json_strict(OLD_FILES["old_roster"])
    roster = roster_document.get("attempts")
    if not isinstance(roster, list) or len(roster) != 10:
        raise RuntimeError("ROSTER_COUNT_MISMATCH")

    validator_path = SRC_ROOT / "window01_fixture_repair" / "validators.py"
    validator_hash = sha256_file(validator_path)
    specs = fixture_specs(roster)
    results = execute_fixtures(specs, validator_hash)
    executable = sum(record["validator_invoked"] is True for record in results)
    declaration_only = sum(record["declaration_only"] is True for record in results)
    passed = sum(record["passed"] is True for record in results)
    execution_count = sum(record["execution_count_delta"] for record in results)
    identity_consumption = sum(
        record["identity_consumption_delta"] for record in results
    )
    if executable < 100 or declaration_only != 0 or passed != len(results):
        raise RuntimeError("NEGATIVE_FIXTURE_EXECUTION_COVERAGE_INCOMPLETE")
    if execution_count != 0 or identity_consumption != 0:
        raise RuntimeError("FIXTURE_SIDE_EFFECT_COUNT_NONZERO")

    write_readme()
    predecessor_receipt = {
        "schema": f"{SCHEMA_PREFIX}/predecessor-binding-receipt/v1",
        "created_at_utc": CREATED_AT_UTC,
        "independent_audit": audit_binding,
        "predecessor": {
            "package_payload_root_sha256": EXPECTED["old_payload_root"],
            "tree_file_count": predecessor_before["tree_file_count"],
            "tree_root_sha256": predecessor_before["tree_root_sha256"],
            "sha256sums": predecessor_before["sha256sums"],
            "bindings": predecessor_before["bindings"],
        },
        "preserved_blocking_invariant": (
            "NEGATIVE_FIXTURE_EXECUTION_COVERAGE_BELOW_REQUIRED_MINIMUM"
        ),
        "repair_scope": "NEGATIVE_FIXTURE_EXECUTION_COVERAGE_ONLY",
        "predecessor_modified": False,
        "status": "PASS",
    }
    write_json(
        PACKAGE_ROOT
        / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PREDECESSOR_BINDING_RECEIPT.json",
        predecessor_receipt,
    )

    fixture_document = {
        "schema": f"{SCHEMA_PREFIX}/negative-fixture-ledger/v1",
        "created_at_utc": CREATED_AT_UTC,
        "repair_scope": "NEGATIVE_FIXTURE_EXECUTION_COVERAGE_ONLY",
        "validator_source_sha256": validator_hash,
        "executable_negative_fixtures": executable,
        "declaration_only_fixtures": declaration_only,
        "passed": passed,
        "total": len(results),
        "fixture_execution_count": execution_count,
        "fixture_identity_consumption_count": identity_consumption,
        "all_counted_fixtures_invoked_validator_logic": True,
        "fixtures": results,
        "status": "PASS",
    }
    write_json(
        PACKAGE_ROOT
        / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_NEGATIVE_FIXTURES.json",
        fixture_document,
    )

    security = security_scan()
    write_json(
        PACKAGE_ROOT
        / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_SECURITY_AND_BOUNDARY_REPORT.json",
        security,
    )
    if security["status"] != "PASS":
        raise RuntimeError("SECURITY_AND_BOUNDARY_SCAN_FAILED")

    validation = {
        "schema": f"{SCHEMA_PREFIX}/validation-report/v1",
        "created_at_utc": CREATED_AT_UTC,
        "status": "PASS",
        "executable_negative_fixtures": executable,
        "required_executable_negative_fixtures": 100,
        "declaration_only_fixtures": declaration_only,
        "negative_fixtures": f"{passed}/{len(results)}",
        "fixture_execution_count": execution_count,
        "fixture_identity_consumption_count": identity_consumption,
        "predecessor_modified": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_executed": "0/10",
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
        "pool_contacted": False,
        "miner_launched": False,
        "live_started": False,
        "first_blocking_invariant": "NONE",
        "exact_next_allowed_stage": (
            "A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_WINDOW_01_PACKAGE_"
            "DRY_RUN_FIXTURE_COVERAGE_REPAIR_INDEPENDENT_AUDIT_ONLY"
        ),
    }
    write_json(
        PACKAGE_ROOT
        / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_VALIDATION_REPORT.json",
        validation,
    )

    payload_exclusions = {
        "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json",
        "SHA256SUMS.txt",
        ZIP_NAME,
    }
    payload_records = inventory(PACKAGE_ROOT, payload_exclusions)
    manifest = {
        "schema": f"{SCHEMA_PREFIX}/package-manifest/v1",
        "created_at_utc": CREATED_AT_UTC,
        "artifact_type": "ADDITIVE_NEGATIVE_FIXTURE_EXECUTION_COVERAGE_REPAIR",
        "package_payload_root_algorithm": (
            "For UTF-8 bytewise-sorted relative paths, append path UTF-8, NUL, "
            "decimal size, NUL, raw 32-byte SHA-256, LF; SHA-256 the concatenation."
        ),
        "package_payload_root_sha256": payload_root(payload_records),
        "file_count": len(payload_records),
        "files": [
            {**record, "role": role_for_path(record["relative_path"])}
            for record in payload_records
        ],
        "executable_negative_fixtures": executable,
        "declaration_only_fixtures": declaration_only,
        "fixture_execution_count": execution_count,
        "fixture_identity_consumption_count": identity_consumption,
        "execution_authorized": False,
        "campaign_output_root_created": False,
        "status": "PASS",
    }
    manifest_path = (
        PACKAGE_ROOT
        / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json"
    )
    write_json(manifest_path, manifest)

    sums_records = inventory(PACKAGE_ROOT, {"SHA256SUMS.txt", ZIP_NAME})
    sums_text = "".join(
        f"{record['sha256']}  {record['relative_path']}\n" for record in sums_records
    )
    sums_path = PACKAGE_ROOT / "SHA256SUMS.txt"
    sums_path.write_bytes(sums_text.encode("utf-8"))
    checksums_passed, checksums_total = verify_sha256sums(PACKAGE_ROOT, sums_path)
    if checksums_passed != checksums_total:
        raise RuntimeError("PACKAGE_SHA256SUMS_MISMATCH")

    archive_records = inventory(PACKAGE_ROOT, {ZIP_NAME})
    zip_path = PACKAGE_ROOT / ZIP_NAME
    build_zip(zip_path, archive_records)
    zip_verification = verify_zip_and_remove_workspace(zip_path, archive_records)

    predecessor_after = verify_predecessors()
    if predecessor_after["tree_root_sha256"] != predecessor_before["tree_root_sha256"]:
        raise RuntimeError("PREDECESSOR_PACKAGE_MODIFIED")
    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_CREATED")

    result = {
        "status": "PASS",
        "executable_negative_fixtures": executable,
        "declaration_only_fixtures": declaration_only,
        "negative_fixtures": f"{passed}/{len(results)}",
        "checksums": f"{checksums_passed}/{checksums_total}",
        "package_payload_root_sha256": manifest["package_payload_root_sha256"],
        "package_manifest_sha256": sha256_file(manifest_path),
        "sha256sums_sha256": sha256_file(sums_path),
        "audit_export_zip_sha256": sha256_file(zip_path),
        "audit_export_zip_size_bytes": zip_path.stat().st_size,
        "audit_export_zip_path": str(zip_path),
        "archive_verification": zip_verification,
        "predecessor_tree_root_before": predecessor_before["tree_root_sha256"],
        "predecessor_tree_root_after": predecessor_after["tree_root_sha256"],
        "campaign_output_root_created": False,
        "window_01_execution_authorized": False,
        "window_01_attempts_executed": "0/10",
        "campaign_attempts_executed": "0/360",
        "campaign_identities_consumed": 0,
        "scientific_endpoints_computed": False,
        "first_blocking_invariant": "NONE",
        "exact_next_allowed_stage": validation["exact_next_allowed_stage"],
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
