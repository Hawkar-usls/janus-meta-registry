"""Read-only independent verifier for the fixture coverage repair package."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
I0_ROOT = ROOT.parent
sys.path.insert(0, str(ROOT / "src"))

from window01_fixture_repair.validators import invoke_validator  # noqa: E402


FIXTURES = ROOT / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_NEGATIVE_FIXTURES.json"
MANIFEST = ROOT / "A18_44_V0_1_WINDOW_01_FIXTURE_COVERAGE_REPAIR_PACKAGE_MANIFEST.json"
SUMS = ROOT / "SHA256SUMS.txt"
ARCHIVE = ROOT / "JANUS_A18_44_V0_1_WINDOW_01_PACKAGE_DRY_RUN_FIXTURE_COVERAGE_REPAIR_AUDIT_EXPORT.zip"
CAMPAIGN_OUTPUT_ROOT = I0_ROOT / "JANUS_A18_44_V0_1_OFFLINE_ACQUISITION_CAMPAIGN_OUTPUT"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def duplicate_key_guard(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key_guard)


def payload_root(records: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: item["relative_path"].encode("utf-8")):
        digest.update(record["relative_path"].encode("utf-8"))
        digest.update(b"\x00")
        digest.update(str(record["size_bytes"]).encode("ascii"))
        digest.update(b"\x00")
        digest.update(bytes.fromhex(record["sha256"]))
        digest.update(b"\n")
    return digest.hexdigest()


def verify() -> dict[str, Any]:
    fixture_document = load_json(FIXTURES)
    manifest = load_json(MANIFEST)
    fixtures = fixture_document["fixtures"]
    passed = 0
    ids: set[str] = set()
    for fixture in fixtures:
        fixture_id = fixture["fixture_id"]
        if fixture_id in ids:
            raise RuntimeError(f"DUPLICATE_FIXTURE_ID:{fixture_id}")
        ids.add(fixture_id)
        if fixture.get("validator_invoked") is not True:
            raise RuntimeError(f"VALIDATOR_NOT_INVOKED:{fixture_id}")
        if fixture.get("declaration_only") is not False:
            raise RuntimeError(f"DECLARATION_ONLY_FIXTURE:{fixture_id}")
        if sha256_bytes(canonical_bytes(fixture["input"])) != fixture["input_sha256"]:
            raise RuntimeError(f"FIXTURE_INPUT_HASH_MISMATCH:{fixture_id}")
        returned = invoke_validator(fixture["validator_callable"], fixture["input"])
        if sha256_bytes(canonical_bytes(returned)) != fixture["return_sha256"]:
            raise RuntimeError(f"FIXTURE_RETURN_HASH_MISMATCH:{fixture_id}")
        if returned.get("decision") != fixture["expected_decision"]:
            raise RuntimeError(f"FIXTURE_DECISION_MISMATCH:{fixture_id}")
        if fixture.get("execution_count_delta") != 0:
            raise RuntimeError(f"FIXTURE_EXECUTION_DELTA_NONZERO:{fixture_id}")
        if fixture.get("identity_consumption_delta") != 0:
            raise RuntimeError(f"FIXTURE_IDENTITY_DELTA_NONZERO:{fixture_id}")
        passed += 1

    if passed < 100 or fixture_document["declaration_only_fixtures"] != 0:
        raise RuntimeError("FIXTURE_COVERAGE_GATE_FAILED")

    for record in manifest["files"]:
        path = ROOT / Path(record["relative_path"])
        if not path.is_file():
            raise RuntimeError(f"MANIFEST_FILE_MISSING:{record['relative_path']}")
        if path.stat().st_size != record["size_bytes"]:
            raise RuntimeError(f"MANIFEST_SIZE_MISMATCH:{record['relative_path']}")
        if sha256_file(path) != record["sha256"]:
            raise RuntimeError(f"MANIFEST_HASH_MISMATCH:{record['relative_path']}")
    if payload_root(manifest["files"]) != manifest["package_payload_root_sha256"]:
        raise RuntimeError("PAYLOAD_ROOT_MISMATCH")

    checksums_passed = 0
    checksums_total = 0
    for line in SUMS.read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        checksums_total += 1
        expected, relative = line.split("  ", 1)
        target = ROOT / Path(relative)
        if target.is_file() and sha256_file(target) == expected:
            checksums_passed += 1
    if checksums_passed != checksums_total:
        raise RuntimeError("SHA256SUMS_MISMATCH")

    expected_archive = {
        path.relative_to(ROOT).as_posix(): {
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in ROOT.rglob("*")
        if path.is_file() and path != ARCHIVE
    }
    archive_passed = 0
    with zipfile.ZipFile(ARCHIVE, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected_archive):
            raise RuntimeError("ARCHIVE_MEMBER_SET_MISMATCH")
        if archive.testzip() is not None:
            raise RuntimeError("ARCHIVE_CRC_FAILURE")
        for info in archive.infolist():
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts or "\\" in info.filename:
                raise RuntimeError("ARCHIVE_UNSAFE_PATH")
            data = archive.read(info.filename)
            expected = expected_archive[info.filename]
            if len(data) != expected["size_bytes"] or sha256_bytes(data) != expected["sha256"]:
                raise RuntimeError(f"ARCHIVE_MEMBER_HASH_MISMATCH:{info.filename}")
            archive_passed += 1

    if CAMPAIGN_OUTPUT_ROOT.exists():
        raise RuntimeError("CAMPAIGN_OUTPUT_ROOT_CREATED")
    return {
        "status": "PASS",
        "executable_negative_fixtures": passed,
        "declaration_only_fixtures": 0,
        "negative_fixtures": f"{passed}/{len(fixtures)}",
        "checksums": f"{checksums_passed}/{checksums_total}",
        "manifest_files": f"{len(manifest['files'])}/{len(manifest['files'])}",
        "archive_members": f"{archive_passed}/{len(expected_archive)}",
        "package_payload_root_sha256": manifest["package_payload_root_sha256"],
        "package_manifest_sha256": sha256_file(MANIFEST),
        "sha256sums_sha256": sha256_file(SUMS),
        "audit_export_zip_sha256": sha256_file(ARCHIVE),
        "audit_export_zip_size_bytes": ARCHIVE.stat().st_size,
        "fixture_execution_count": 0,
        "fixture_identity_consumption_count": 0,
        "campaign_output_root_created": False,
        "scientific_endpoints_computed": False,
    }


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, sort_keys=True, indent=2))
